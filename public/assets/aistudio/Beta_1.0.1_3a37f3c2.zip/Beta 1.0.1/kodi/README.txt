==================================================
  KODI BRIDGE — addons do Kodi como fontes de vídeo
==================================================

O QUE É
-------
Um servidor Python que executa addons do Kodi e devolve o link que
eles resolveriam. Ele fala o formato de addon que o site já consome
(Stremio): o site só vê mais uma fonte de vídeo.

Por que precisa de servidor: addon do Kodi é plugin PYTHON. Ele chama
xbmcplugin.setResolvedUrl() para entregar o vídeo. Navegador nenhum roda
isso. Aqui o xbmc_stub.py finge ser o Kodi, roda o default.py do addon e
anota a URL final.

O QUE NÃO É
-----------
- Não é o Kodi: não tem janela, não tem player, não tem Addons do repositório.
- Não existe API padrão num addon Kodi. Cada um tem as suas rotas
  (?action=...), então VOCÊ configura a rota de busca no routes.json.
- Sem DRM: addons que usam inputstream.adaptive / Widevine não vão
  funcionar, o navegador não decifra.

REQUISITOS
----------
- Python 3.9+ no servidor (o mesmo host Node do proxy serve)
- pip install requests   (quase todo addon usa)
- Espaço e banda como no gateway torrent


1) INSTALAR UM ADDON
--------------------
Descompacte o zip do addon em kodi/addons/, de forma que fique:

  kodi/addons/plugin.video.seuaddon/addon.xml
  kodi/addons/plugin.video.seuaddon/default.py

Dependências (script.module.alguma coisa, resolveurl) vão como pastas
irmãs em kodi/addons/. A ponte coloca todas no sys.path.


2) DESCOBRIR A ROTA DE BUSCA (o passo que decide tudo)
------------------------------------------------------
Liste o menu raiz do addon:

  python3 kodi_bridge.py        (em outro terminal)

  curl "http://127.0.0.1:8790/debug?addon=plugin.video.seuaddon&query="

A resposta traz "items": os itens do menu com o "url" de cada um.
Vá descendo pelo menu de busca:

  curl "http://127.0.0.1:8790/debug?addon=plugin.video.seuaddon&query=action=busca"

Quando achar a rota que recebe o título (normalmente algo como
action=search / mode=search), esse é o valor de "search" no routes.json.
Os marcadores viram o valor codificado: {title} {year} {imdb} {season}
{episode} {type} {id}.

No /debug você também vê "resolved" quando o addon entrega o link direto
e "logs" com o que ele escreveu no xbmc.log — é aí que aparece o erro.


3) CONFIGURAR routes.json
-------------------------
  {
    "plugin.video.seuaddon": {
      "name": "Meu addon",
      "search": "?action=search&title={title}&year={year}",
      "settings": { "qualidade": "1080" }
    }
  }

- "settings" preenche o que o addon leria em Configurações (getSetting).
  Use para usuário/senha/token sem editar o XML do addon.
- Pode ter vários addons; todos são consultados e as fontes se somam.


4) SUBIR
--------
  cd kodi
  TMDB_API_KEY=sua_chave python3 kodi_bridge.py

Variáveis:
  KODI_PORT     padrão 8790
  KODI_ADDONS   padrão ./addons
  KODI_ROUTES   padrão ./routes.json
  KODI_TIMEOUT  segundos por execução (padrão 45)
  TMDB_API_KEY  converte o id (tt.../TMDB) em título para a busca
  ALLOW_ORIGIN  CORS (padrão *)

Teste:
  curl http://127.0.0.1:8790/health
  curl http://127.0.0.1:8790/addons
  curl "http://127.0.0.1:8790/stream/movie/tt0133093.json"


5) LIGAR NO SITE
----------------
Fontes de vídeo (☰) → cole a URL do manifesto:

  http://SEU-HOST:8790/manifest.json

Precisa ser https se o site for https (senão o navegador bloqueia).
O manifesto declara "timeout", e o site respeita esse tempo em vez dos
7s padrão — sem isso o pedido seria abortado antes do addon responder.


6) LIMITES REAIS
----------------
- Scraper demora: 10 a 40s no primeiro pedido. A ponte guarda o
  resultado por 60s por (addon + busca), então os ids alternativos que o
  site testa em seguida respondem na hora.
- Addon que pede senha em diálogo, abre janela própria (WindowXML) ou
  usa módulo nativo que não existe no Python do servidor vai falhar.
  O /debug mostra o motivo.
- Addon que exige conta/premium: coloque as credenciais em "settings".
- Link final http:// em site https:// é bloqueado pelo navegador. Se
  acontecer, publique junto o proxy Node deste projeto (STREAM_PROXY).
- MKV/HEVC continua dependendo do navegador, como no gateway torrent.


7) SEGURANÇA
------------
A ponte executa código Python de terceiros. Rode só addons que você
confia, não exponha a porta na internet aberta (use a mesma senha/rede
do proxy) e confira a licença/ToS de cada addon. Use apenas conteúdo
que você tem o direito de assistir.
