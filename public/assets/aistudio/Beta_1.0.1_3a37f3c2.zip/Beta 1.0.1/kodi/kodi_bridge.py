#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
kodi_bridge.py — transforma addons do Kodi em fontes para o site.

O site já sabe consumir addons no formato Stremio. Esta ponte responde
exatamente nesse formato, mas por dentro executa o addon Kodi (Python)
com o shim do xbmc_stub.py e devolve o link que ele resolveria.

Rotas:
  GET /health
  GET /addons
  GET /manifest.json                      (manifesto Stremio)
  GET /stream/{tipo}/{id}.json            (o site chama sozinho)
  GET /debug?addon=<id>&query=<query>     (mostra o que o addon devolveu)

Variáveis de ambiente:
  KODI_PORT      porta (padrão 8790)
  KODI_ADDONS    pasta dos addons (padrão ./addons)
  KODI_ROUTES    arquivo de rotas (padrão ./routes.json)
  KODI_TIMEOUT   segundos por execução de addon (padrão 45)
  TMDB_API_KEY   para descobrir título/ano a partir do IMDb/TMDB id
  ALLOW_ORIGIN   CORS (padrão *)

Use só com addons que você tem o direito de usar.
"""

import json
import os
import re
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
STUB = os.path.join(HERE, "xbmc_stub.py")

PORT = int(os.environ.get("KODI_PORT") or 8790)
ADDONS_DIR = os.path.abspath(os.environ.get("KODI_ADDONS") or os.path.join(HERE, "addons"))
ROUTES_PATH = os.path.abspath(os.environ.get("KODI_ROUTES") or os.path.join(HERE, "routes.json"))
TIMEOUT = float(os.environ.get("KODI_TIMEOUT") or 45)
TMDB_KEY = os.environ.get("TMDB_API_KEY") or ""
ALLOW_ORIGIN = os.environ.get("ALLOW_ORIGIN") or "*"

MAX_RUNS = 10        # execuções de addon por requisição (proteção)
MAX_DEPTH = 2        # plugin:// dentro de plugin://

_title_cache = {}
_run_cache = {}
RUN_CACHE_TTL = 60  # o site repete o pedido com outros ids; não scrape 4x


# ---------------------------------------------------------------------------
# utilidades
# ---------------------------------------------------------------------------


def load_routes():
    """Só as entradas que realmente têm rota de busca."""
    try:
        with open(ROUTES_PATH, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {
        key: value
        for key, value in data.items()
        if isinstance(value, dict) and value.get("search")
    }


def scan_addons():
    found = []
    if not os.path.isdir(ADDONS_DIR):
        return found
    for entry in sorted(os.listdir(ADDONS_DIR)):
        xml_path = os.path.join(ADDONS_DIR, entry, "addon.xml")
        if not os.path.isfile(xml_path):
            continue
        info = {"id": entry, "name": entry, "version": "?"}
        try:
            with open(xml_path, "r", encoding="utf-8", errors="replace") as fh:
                text = fh.read(4000)
            m = re.search(r'<addon[^>]*\bid="([^"]+)"', text)
            if m:
                info["id"] = m.group(1)
            m = re.search(r'<addon[^>]*\bname="([^"]+)"', text)
            if m:
                info["name"] = m.group(1)
            m = re.search(r'<addon[^>]*\bversion="([^"]+)"', text)
            if m:
                info["version"] = m.group(1)
        except OSError:
            continue
        info["path"] = os.path.join(ADDONS_DIR, entry)
        found.append(info)
    return found


def tmdb_json(path):
    if not TMDB_KEY:
        return None
    url = "https://api.themoviedb.org/3%s%sapi_key=%s&language=pt-BR" % (
        path,
        "&" if "?" in path else "?",
        urllib.parse.quote(TMDB_KEY),
    )
    try:
        with urllib.request.urlopen(url, timeout=12) as resp:
            return json.loads(resp.read().decode("utf-8", "replace"))
    except Exception:
        return None


def meta_from_id(media_type, media_id):
    """Devolve (título, ano, temporada, episódio) a partir do id do site."""
    key = (media_type, media_id)
    if key in _title_cache:
        return _title_cache[key]

    season = episode = ""
    parts = str(media_id).split(":")
    base = parts[0]
    if base == "tmdb" and len(parts) >= 2:
        base = parts[1]
        if len(parts) >= 4:
            season, episode = parts[2], parts[3]
    elif len(parts) >= 3:
        season, episode = parts[1], parts[2]

    title = year = ""
    if base.startswith("tt") and TMDB_KEY:
        kind = "tv" if media_type == "series" else "movie"
        data = tmdb_json("/find/%s?external_source=imdb_id" % urllib.parse.quote(base))
        if data:
            results = data.get("tv_results" if kind == "tv" else "movie_results") or []
            if results:
                item = results[0]
                title = item.get("name") or item.get("title") or ""
                year = (item.get("first_air_date") or item.get("release_date") or "")[:4]
    elif re.fullmatch(r"\d+", str(base)) and TMDB_KEY:
        kind = "tv" if media_type == "series" else "movie"
        data = tmdb_json("/%s/%s" % (kind, base))
        if data:
            title = data.get("name") or data.get("title") or ""
            year = (data.get("first_air_date") or data.get("release_date") or "")[:4]

    result = (title, year, season, episode)
    _title_cache[key] = result
    return result


def fill(template, variables):
    def repl(match):
        return urllib.parse.quote(str(variables.get(match.group(1), "") or ""))

    return re.sub(r"\{(\w+)\}", repl, str(template or ""))


def split_plugin_url(url):
    m = re.match(r"plugin://([^/?]+)/?\??(.*)$", str(url or ""), re.I)
    if not m:
        return None, ""
    return m.group(1), m.group(2) or ""


# ---------------------------------------------------------------------------
# execução do addon
# ---------------------------------------------------------------------------


def run_addon(addon_id, query, settings=None):
    """Roda o addon num processo separado (trava nele não trava a ponte)."""
    cache_key = (addon_id, query, json.dumps(settings or {}, sort_keys=True))
    hit = _run_cache.get(cache_key)
    if hit and time.time() - hit[0] < RUN_CACHE_TTL:
        return hit[1]

    result = _run_addon_uncached(addon_id, query, settings)
    # erro não fica em cache: a próxima tentativa pode dar certo
    if not result.get("error"):
        if len(_run_cache) > 200:
            _run_cache.clear()
        _run_cache[cache_key] = (time.time(), result)
    return result


def _run_addon_uncached(addon_id, query, settings=None):
    if not os.path.isdir(os.path.join(ADDONS_DIR, addon_id)):
        return {"error": "addon não instalado: %s" % addon_id, "resolved": [], "items": []}

    settings_path = None
    try:
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as fh:
            json.dump(settings or {}, fh, ensure_ascii=False)
            settings_path = fh.name
        with tempfile.NamedTemporaryFile("r", suffix=".json", delete=False, encoding="utf-8") as fh:
            out_path = fh.name

        cmd = [sys.executable, STUB, "--run", ADDONS_DIR, addon_id, query, out_path]
        if settings_path:
            cmd.append(settings_path)

        proc = subprocess.run(
            cmd,
            cwd=ADDONS_DIR,
            timeout=TIMEOUT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )
        try:
            with open(out_path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            detail = (proc.stderr or b"").decode("utf-8", "replace")[-600:]
            return {"error": "addon não devolveu resultado. %s" % detail, "resolved": [], "items": []}
        if proc.returncode not in (0, 1) and not data.get("resolved") and not data.get("items"):
            detail = (proc.stderr or b"").decode("utf-8", "replace")[-600:]
            data["error"] = "saída %s. %s" % (proc.returncode, detail)
        return data
    except subprocess.TimeoutExpired:
        return {"error": "addon demorou mais de %ss" % int(TIMEOUT), "resolved": [], "items": []}
    except Exception as err:  # noqa: BLE001
        return {"error": "%s: %s" % (type(err).__name__, err), "resolved": [], "items": []}
    finally:
        for path in (settings_path, locals().get("out_path")):
            try:
                if path:
                    os.unlink(path)
            except OSError:
                pass


def collect_links(addon_id, query, routes, depth, visited, budget, out):
    """Percorre diretórios do addon até achar links de vídeo."""
    if budget[0] >= MAX_RUNS or depth > MAX_DEPTH:
        return
    key = (addon_id, query)
    if key in visited:
        return
    visited.add(key)
    budget[0] += 1

    route = routes.get(addon_id) or {}
    result = run_addon(addon_id, query, route.get("settings"))

    for entry in result.get("resolved") or []:
        url = str(entry.get("url") or "").strip()
        if re.match(r"^(https?://|magnet:\?)", url, re.I):
            out.append(
                {
                    "url": url,
                    "label": entry.get("label") or route.get("name") or addon_id,
                    "headers": entry.get("headers") or {},
                }
            )

    for item in result.get("items") or []:
        url = str(item.get("url") or "").strip()
        label = item.get("label") or ""
        if re.match(r"^https?://", url, re.I) and not item.get("isFolder"):
            out.append({"url": url, "label": label or addon_id, "headers": {}})
            continue
        if url.lower().startswith("plugin://"):
            next_addon, next_query = split_plugin_url(url)
            if next_addon:
                collect_links(next_addon, next_query, routes, depth + 1, visited, budget, out)


def streams_for(media_type, media_id):
    routes = load_routes()
    if not routes:
        return [], ["nenhuma rota configurada em routes.json (veja o README)"]

    title, year, season, episode = meta_from_id(media_type, media_id)
    variables = {
        "title": title,
        "year": year,
        "season": season,
        "episode": episode,
        "id": media_id,
        "type": "tvshow" if media_type == "series" else "movie",
        "imdb": media_id if str(media_id).startswith("tt") else "",
    }

    problems = []
    if not title:
        problems.append(
            "sem título para buscar (defina TMDB_API_KEY para converter o id em nome)"
        )

    streams = []
    for addon_id, route in routes.items():
        template = route.get("search")
        if not template:
            continue
        if not title and "{title}" in template:
            continue
        query = fill(template, variables).lstrip("?")
        links = []
        collect_links(addon_id, query, routes, 0, set(), [0], links)
        addon_name = route.get("name") or addon_id
        for link in links:
            # O site monta o rótulo da fonte com "name"; juntar addon + item
            # deixa claro de onde veio cada opção no menu "Fonte".
            item_label = link["label"] or ""
            if item_label and addon_name.lower() not in item_label.lower():
                display = "%s · %s" % (addon_name, item_label)
            else:
                display = item_label or addon_name
            streams.append(
                {
                    "name": display,
                    "title": display,
                    "url": link["url"],
                    "behaviorHints": (
                        {"headers": link["headers"]} if link.get("headers") else {}
                    ),
                }
            )
    return streams, problems


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------


class Handler(BaseHTTPRequestHandler):
    server_version = "kodi-bridge/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("[kodi-bridge] %s\n" % (fmt % args))

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", ALLOW_ORIGIN)
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def _json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        query = urllib.parse.parse_qs(parsed.query)

        if path == "/health":
            addons = scan_addons()
            routes = load_routes()
            self._json(
                200,
                {
                    "ok": True,
                    "service": "kodi-bridge",
                    "python": sys.version.split()[0],
                    "addonsDir": ADDONS_DIR,
                    "routesFile": ROUTES_PATH,
                    "addons": [a["id"] for a in addons],
                    "configured": sorted(routes.keys()),
                    "tmdbKey": bool(TMDB_KEY),
                },
            )
            return

        if path == "/addons":
            routes = load_routes()
            items = []
            for addon in scan_addons():
                route = routes.get(addon["id"]) or {}
                items.append(
                    {
                        "id": addon["id"],
                        "name": addon["name"],
                        "version": addon["version"],
                        "search": route.get("search") or None,
                        "configured": addon["id"] in routes,
                    }
                )
            self._json(200, {"addons": items})
            return

        if path == "/manifest.json":
            self._json(
                200,
                {
                    "id": "org.netfilmes.kodibridge",
                    "version": "1.0.0",
                    "name": "Kodi Bridge",
                    "description": "Addons do Kodi como fontes de vídeo (ponte Python)",
                    "resources": ["stream"],
                    "types": ["movie", "series"],
                    "catalogs": [],
                    # campo extra lido pelo Meus Filmes: scraper é lento, não é 7s
                    "timeout": int(TIMEOUT),
                },
            )
            return

        if path == "/debug":
            addon_id = (query.get("addon") or [""])[0]
            raw_query = (query.get("query") or [""])[0]
            if not addon_id:
                self._json(400, {"error": "use ?addon=<id>&query=<query>"})
                return
            routes = load_routes()
            route = routes.get(addon_id) or {}
            result = run_addon(addon_id, raw_query, route.get("settings"))
            self._json(200, result)
            return

        m = re.match(r"^/stream/(movie|series)/(.+)\.json$", path)
        if m:
            media_type, media_id = m.group(1), urllib.parse.unquote(m.group(2))
            streams, problems = streams_for(media_type, media_id)
            payload = {"streams": streams}
            if problems and not streams:
                payload["error"] = "; ".join(problems)
            self._json(200, payload)
            return

        self._json(404, {"error": "rota inexistente", "paths": ["/health", "/manifest.json", "/stream/movie/<id>.json", "/debug"]})


def main():
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print("[kodi-bridge] http://0.0.0.0:%d  addons=%s" % (PORT, ADDONS_DIR))
    print("[kodi-bridge] manifesto: http://SEU-HOST:%d/manifest.json" % PORT)
    if not TMDB_KEY:
        print("[kodi-bridge] aviso: TMDB_API_KEY vazio — a busca por título não vai funcionar")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
