#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
xbmc_stub.py — roda um addon de vídeo do Kodi FORA do Kodi.

O addon importa xbmc, xbmcgui, xbmcplugin, xbmcaddon e xbmcvfs. Aqui esses
módulos são falsos: em vez de desenhar tela, eles anotam o que o addon
mandou. No fim, a URL que o addon entregaria ao player é gravada num JSON.

Uso (é a ponte que chama, você não precisa rodar à mão):
  python3 xbmc_stub.py --run <pasta_de_addons> <id_do_addon> <query> <saida.json> [settings.json]

  query = a parte depois do "?" do plugin:// (ex.: "action=search&title=Matrix")

O que NÃO funciona: addons que dependem de janela própria (WindowXML),
de DRM/inputstream.adaptive, de digitar senha em diálogo ou de módulos
nativos que não existem no Python do servidor.
"""

import json
import os
import re
import sys
import types

# ---------------------------------------------------------------------------
# contexto da execução
# ---------------------------------------------------------------------------


class Capture:
    def __init__(self, addon_dir, addon_id, settings=None):
        self.addon_dir = addon_dir
        self.addon_id = addon_id
        self.settings = dict(settings or {})
        self.resolved = []   # links finais (setResolvedUrl / Player().play)
        self.items = []      # itens de diretório (addDirectoryItem)
        self.builtins = []   # executebuiltin, só para diagnóstico
        self.logs = []
        self.strings = {}
        self._setting_defaults = {}
        self._titles = {}

    def add_resolved(self, url, label="", art=None, headers=None):
        url = str(url or "").strip()
        if not url:
            return
        if any(r["url"] == url for r in self.resolved):
            return
        self.resolved.append(
            {
                "url": url,
                "label": label or "",
                "art": art or {},
                "headers": headers or {},
            }
        )

    def to_json(self):
        return {
            "addon": self.addon_id,
            "resolved": self.resolved,
            "items": self.items,
            "builtins": self.builtins,
            "logs": self.logs[-60:],
        }


# ---------------------------------------------------------------------------
# recursos do addon (settings.xml / strings.po)
# ---------------------------------------------------------------------------


def load_setting_defaults(addon_dir):
    path = os.path.join(addon_dir, "resources", "settings.xml")
    out = {}
    if not os.path.isfile(path):
        return out
    try:
        from xml.etree import ElementTree as ET

        root = ET.parse(path).getroot()
        for node in root.findall(".//setting"):
            key = node.get("id")
            if not key:
                continue
            out[key] = node.get("default", "")
    except Exception:
        pass
    return out


def load_strings(addon_dir):
    out = {}
    base = os.path.join(addon_dir, "resources", "language")
    if not os.path.isdir(base):
        return out
    for lang in sorted(os.listdir(base)):
        po = os.path.join(base, lang, "strings.po")
        if not os.path.isfile(po):
            continue
        try:
            with open(po, "r", encoding="utf-8", errors="replace") as fh:
                text = fh.read()
        except OSError:
            continue
        for block in re.split(r"\n\s*\n", text):
            m = re.search(r'msgctxt\s+"#(\d+)"', block)
            if not m:
                continue
            mm = re.search(r'msgid\s+"((?:[^"\\]|\\.)*)"', block)
            if mm:
                out[int(m.group(1))] = mm.group(1).replace('\\"', '"').replace("\\n", "\n")
        break  # o primeiro idioma encontrado basta
    return out


# ---------------------------------------------------------------------------
# objetos falsos
# ---------------------------------------------------------------------------


class ListItem:
    def __init__(self, label="", label2="", path="", offscreen=False):
        self.label = label or ""
        self.path = path or ""
        self.art = {}
        self.info = {}
        self.props = {}
        self.ids = {}
        self.subtitles = []
        self.streaminfo = {}

    # rótulo / caminho
    def setLabel(self, value):
        self.label = value or ""

    def getLabel(self):
        return self.label

    def setPath(self, value):
        self.path = value or ""

    def getPath(self):
        return self.path

    def setArt(self, art):
        if isinstance(art, dict):
            self.art.update({k: v for k, v in art.items() if v})

    def getArt(self, key=None):
        return self.art.get(key, "") if key else self.art

    def setInfo(self, *args, **kwargs):
        if len(args) >= 2 and isinstance(args[1], dict):
            self.info.update(args[1])
        elif len(args) == 1 and isinstance(args[0], dict):
            self.info.update(args[0])
        if kwargs:
            self.info.update(kwargs)

    def getVideoInfoTag(self):
        return _Tag(self.info)

    def getMusicInfoTag(self):
        return _Tag(self.info)

    def setUniqueIDs(self, ids, type=""):
        if isinstance(ids, dict):
            self.ids.update(ids)

    def setCast(self, cast):
        pass

    def setProperty(self, key, value):
        if key is not None:
            self.props[str(key)] = value

    def getProperty(self, key):
        return self.props.get(str(key), "")

    def setSubtitles(self, subs):
        self.subtitles = list(subs or [])

    def setContentLookup(self, value=True):
        pass

    def setMimeType(self, value):
        pass

    def addStreamInfo(self, kind, values):
        if isinstance(values, dict):
            self.streaminfo.update(values)

    def setIsFolder(self, value):
        pass

    def setAvailableFanart(self, value):
        pass


class _Tag:
    """InfoTag genérica: qualquer setX existe e não faz nada."""

    def __init__(self, info):
        self._info = info

    def __getattr__(self, name):
        if name.startswith("get"):
            def _get():
                return None

            return _get

        def _set(*args, **kwargs):
            return None

        return _set


class Dialog:
    def ok(self, heading="", message=""):
        return True

    def notification(self, heading="", message="", icon="", time=5000, sound=False):
        return None

    def input(self, heading="", defaultt="", type=0, option=0, autoclose=0):
        return ""

    def numeric(self, type=0, heading="", defaultt=""):
        return ""

    def select(self, heading="", list=None, autoclose=0, preselect=-1, useDetails=False):
        items = list or []
        return 0 if items else -1

    def multiselect(self, heading="", options=None, autoclose=0, preselect=None, useDetails=False):
        return []

    def yesno(self, heading="", message="", yeslabel="", nolabel="", autoclose=0):
        return False

    def browse(self, *args, **kwargs):
        return ""

    def textviewer(self, heading="", text="", usepen=False):
        return None

    def colorpicker(self, *args, **kwargs):
        return None


class DialogProgress:
    def create(self, *args, **kwargs):
        return None

    def update(self, *args, **kwargs):
        return None

    def close(self):
        return None

    def iscanceled(self):
        return False


class DialogProgressBG(DialogProgress):
    pass


class Keyboard:
    def __init__(self, line="", heading=""):
        self._text = line or ""

    def doModal(self, autoclose=0):
        return None

    def isConfirmed(self):
        return False

    def getText(self):
        return self._text

    def setText(self, value):
        self._text = value or ""

    def setHeading(self, value):
        pass


class _Player:
    def play(self, item=None, listitem=None, windowed=False, startpos=-1):
        url = item.getPath() if isinstance(item, ListItem) else item
        if ctx:
            ctx.add_resolved(url, getattr(listitem, "label", "") if listitem else "")
            ctx.logs.append("Player().play(%s)" % url)

    def playnext(self):
        return None

    def stop(self):
        return None

    def pause(self):
        return None

    def isPlaying(self):
        return False

    def isPlayingVideo(self):
        return False

    def isPlayingAudio(self):
        return False

    def getTime(self):
        return 0.0

    def getTotalTime(self):
        return 0.0

    def getPlayingFile(self):
        return ""

    def seekTime(self, *args, **kwargs):
        return None

    def setSubtitles(self, path):
        return None

    def showtracks(self, *args, **kwargs):
        return None


class _Monitor:
    def abortRequested(self):
        return False

    def waitForAbort(self, timeout=0):
        return False

    def onSettingsChanged(self):
        return None

    def onScreensaverActivated(self):
        return None


class _PlayList:
    def __init__(self, *args, **kwargs):
        self._items = []

    def add(self, *args, **kwargs):
        return None

    def clear(self):
        self._items = []

    def size(self):
        return 0

    def __len__(self):
        return 0


# ---------------------------------------------------------------------------
# construção dos módulos falsos
# ---------------------------------------------------------------------------

ctx = None  # preenchido em execute()


def build_modules(context):
    global ctx
    ctx = context
    modules = {}

    # ---------------- xbmc ----------------
    xbmc = types.ModuleType("xbmc")
    xbmc.LOGDEBUG = 0
    xbmc.LOGINFO = 1
    xbmc.LOGWARNING = 2
    xbmc.LOGERROR = 3
    xbmc.LOGFATAL = 4
    xbmc.LOGNONE = 5

    def log(msg, level=1):
        ctx.logs.append(str(msg))

    xbmc.log = log
    xbmc.logmsg = log

    def executebuiltin(command, wait=False):
        ctx.builtins.append(str(command))

    xbmc.executebuiltin = executebuiltin
    xbmc.getCondVisibility = lambda cond: False
    xbmc.getInfoLabel = lambda label: ""
    xbmc.getInfoBooleans = lambda label: ""
    xbmc.getSkinDir = lambda: "skin.estuary"
    xbmc.getLanguage = lambda *a, **k: "Portuguese"

    def localized(sid):
        try:
            return ctx.strings.get(int(sid), str(sid))
        except (TypeError, ValueError):
            return ""

    xbmc.getLocalizedString = localized
    xbmc.getRegion = lambda key: ""
    xbmc.getIPAddress = lambda: "127.0.0.1"
    xbmc.getFreeMem = lambda: 1024
    xbmc.getScreenWidth = lambda: 1920
    xbmc.getScreenHeight = lambda: 1080
    xbmc.sleep = lambda ms: None
    xbmc.translatePath = lambda p: p
    xbmc.validatePath = lambda p: p
    xbmc.makeLegalFilename = lambda p: p
    xbmc.executeJSONRPC = lambda req: json.dumps({"result": "OK"})
    xbmc.audioResume = lambda: None
    xbmc.Player = _Player
    xbmc.Monitor = _Monitor
    xbmc.Keyboard = Keyboard
    xbmc.PlayList = _PlayList
    xbmc.PLAYLIST_MUSIC = 0
    xbmc.PLAYLIST_VIDEO = 1
    xbmc.__version__ = "19.5"
    modules["xbmc"] = xbmc

    # ---------------- xbmcgui ----------------
    gui = types.ModuleType("xbmcgui")
    gui.ListItem = ListItem
    gui.Dialog = Dialog
    gui.DialogProgress = DialogProgress
    gui.DialogProgressBG = DialogProgressBG
    gui.Keyboard = Keyboard

    class _Window:
        def __init__(self, *args, **kwargs):
            pass

        def doModal(self):
            return None

        def show(self):
            return None

        def close(self):
            return None

        def setFocusId(self, *a, **k):
            return None

        def getControl(self, *a, **k):
            return None

        def getFocusId(self):
            return 0

        def addControl(self, *a, **k):
            return None

        def addItem(self, *a, **k):
            return None

    class WindowXML(_Window):
        def __init__(self, *args, **kwargs):
            _Window.__init__(self)

    gui.Window = _Window
    gui.WindowXML = WindowXML
    gui.WindowXMLDialog = WindowXML
    gui.WindowDialog = _Window
    gui.INPUT_ALPHANUM = 0
    gui.INPUT_NUMERIC = 1
    gui.INPUT_DATE = 2
    gui.INPUT_TIME = 3
    gui.INPUT_IPADDRESS = 4
    gui.INPUT_PASSWORD = 5
    modules["xbmcgui"] = gui

    # ---------------- xbmcplugin ----------------
    plugin = types.ModuleType("xbmcplugin")

    def addDirectoryItem(handle, url, listitem, isFolder=False, totalItems=0):
        if isinstance(listitem, ListItem):
            ctx.items.append(
                {
                    "label": listitem.label,
                    "url": str(url or listitem.path or ""),
                    "isFolder": bool(isFolder),
                    "art": listitem.art,
                    "info": listitem.info,
                }
            )
        return True

    def addDirectoryItems(handle, items, totalItems=0):
        for entry in items or []:
            try:
                url, listitem, isFolder = entry[0], entry[1], entry[2]
            except (TypeError, IndexError):
                continue
            addDirectoryItem(handle, url, listitem, isFolder, totalItems)
        return True

    def setResolvedUrl(handle, succeeded, listitem):
        if succeeded and isinstance(listitem, ListItem):
            headers = {}
            ua = listitem.getProperty("User-Agent")
            if ua:
                headers["User-Agent"] = ua
            ref = listitem.getProperty("Referer") or listitem.getProperty("referer")
            if ref:
                headers["Referer"] = ref
            ctx.add_resolved(listitem.path, listitem.label, listitem.art, headers)

    plugin.addDirectoryItem = addDirectoryItem
    plugin.addDirectoryItems = addDirectoryItems
    plugin.setResolvedUrl = setResolvedUrl
    plugin.endOfDirectory = lambda *a, **k: None
    plugin.setContent = lambda *a, **k: None
    plugin.setPluginCategory = lambda *a, **k: None
    plugin.setPluginFanart = lambda *a, **k: None
    plugin.addSortMethod = lambda *a, **k: None
    plugin.setSetting = lambda *a, **k: None
    plugin.SORT_METHOD_LABEL = 1
    plugin.SORT_METHOD_VIDEO_SORT_TITLE = 2
    modules["xbmcplugin"] = plugin

    # ---------------- xbmcaddon ----------------
    addon_mod = types.ModuleType("xbmcaddon")

    class Addon:
        def __init__(self, id=None):
            self._id = id or ctx.addon_id

        def getAddonInfo(self, key):
            key = str(key or "").lower()
            info = {
                "id": self._id,
                "name": ctx.addon_dir.rstrip("/\\").split(os.sep)[-1],
                "version": "0.0.0",
                "path": ctx.addon_dir,
                "profile": ctx.addon_dir,
                "icon": os.path.join(ctx.addon_dir, "icon.png"),
                "fanart": os.path.join(ctx.addon_dir, "fanart.jpg"),
                "author": "desconhecido",
                "summary": "",
                "description": "",
            }
            return info.get(key, "")

        def getLocalizedString(self, sid):
            try:
                return ctx.strings.get(int(sid), str(sid))
            except (TypeError, ValueError):
                return ""


        def getSetting(self, key):
            if key in ctx.settings:
                return str(ctx.settings[key])
            return str(ctx._setting_defaults.get(key, ""))

        def getSettingString(self, key):
            return self.getSetting(key)

        def getSettingBool(self, key):
            return str(self.getSetting(key)).lower() in ("true", "1", "yes", "on")

        def getSettingInt(self, key):
            try:
                return int(float(self.getSetting(key)))
            except (TypeError, ValueError):
                return 0

        def getSettingFloat(self, key):
            try:
                return float(self.getSetting(key))
            except (TypeError, ValueError):
                return 0.0

        def setSetting(self, key, value):
            ctx.settings[key] = value

        def setSettingString(self, key, value):
            ctx.settings[key] = value

        def setSettingBool(self, key, value):
            ctx.settings[key] = bool(value)

        def setSettingInt(self, key, value):
            ctx.settings[key] = int(value)

        def openSettings(self):
            return None

    addon_mod.Addon = Addon
    modules["xbmcaddon"] = addon_mod

    # ---------------- xbmcvfs ----------------
    vfs = types.ModuleType("xbmcvfs")
    vfs.translatePath = lambda p: p
    vfs.exists = lambda p: os.path.exists(p)
    vfs.isfile = lambda p: os.path.isfile(p)
    vfs.isdir = lambda p: os.path.isdir(p)
    vfs.mkdir = lambda p: (os.makedirs(p, exist_ok=True) or True) if p else False
    vfs.mkdirs = lambda p: (os.makedirs(p, exist_ok=True) or True) if p else False
    vfs.rmdir = lambda p, force=False: False
    vfs.delete = lambda p: False
    vfs.rename = lambda a, b: False
    vfs.copy = lambda a, b: False
    vfs.listdir = lambda p: ("", []) if not p else ("", sorted(os.listdir(p)))
    vfs.basename = lambda p: os.path.basename(str(p or ""))
    vfs.direxists = lambda p: os.path.isdir(p)

    class _File:
        def __init__(self, path, mode="r"):
            self._fh = open(path, mode)

        def read(self, n=-1):
            return self._fh.read(n)

        def readBytes(self, n=-1):
            import io

            data = self._fh.read(n)
            return io.BytesIO(data.encode("utf-8"))

        def write(self, data):
            self._fh.write(data)
            return True

        def writeToFile(self, data):
            self._fh.write(data)
            return True

        def close(self):
            try:
                self._fh.close()
            except OSError:
                pass

    vfs.File = _File
    modules["xbmcvfs"] = vfs

    return modules


# ---------------------------------------------------------------------------
# execução
# ---------------------------------------------------------------------------


def execute(addons_root, addon_id, query, settings=None):
    addon_dir = os.path.join(addons_root, addon_id)
    if not os.path.isdir(addon_dir):
        raise SystemExit("addon não encontrado: %s" % addon_dir)

    context = Capture(addon_dir, addon_id, settings)
    context.strings = load_strings(addon_dir)
    context._setting_defaults = load_setting_defaults(addon_dir)

    for name, module in build_modules(context).items():
        sys.modules[name] = module

    # dependências (resolveurl, script.module.*) ficam como pastas irmãs
    sys.path.insert(0, addon_dir)
    for entry in sorted(os.listdir(addons_root)):
        full = os.path.join(addons_root, entry)
        if os.path.isdir(full) and full != addon_dir:
            sys.path.insert(0, full)

    entry_point = None
    for candidate in ("default.py", "main.py", "addon.py"):
        path = os.path.join(addon_dir, candidate)
        if os.path.isfile(path):
            entry_point = path
            break
    if not entry_point:
        raise SystemExit("addon sem default.py / main.py: %s" % addon_id)

    # O Kodi passa: [base_url, handle, "?querystring"]. Muitos addons usam
    # sys.argv[0] para montar links plugin:// e sys.argv[2][1:] para ler a query.
    qs = query or ""
    if qs and not qs.startswith("?"):
        qs = "?" + qs
    sys.argv = ["plugin://%s/" % addon_id, "1", qs]
    os.chdir(addon_dir)

    import runpy

    try:
        runpy.run_path(entry_point, run_name="__main__")
    except SystemExit:
        pass
    except BaseException as err:  # noqa: BLE001 — o addon pode estourar de tudo
        context.logs.append("ERRO: %s: %s" % (type(err).__name__, err))

    return context.to_json()


def main(argv):
    if len(argv) < 6 or argv[1] != "--run":
        sys.stderr.write(__doc__)
        return 2

    addons_root, addon_id, query, out_path = argv[2], argv[3], argv[4], argv[5]
    settings = {}
    if len(argv) > 6 and os.path.isfile(argv[6]):
        try:
            with open(argv[6], "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                settings = data
        except (OSError, ValueError):
            settings = {}

    result = execute(addons_root, addon_id, query, settings)
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(result, fh, ensure_ascii=False)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
