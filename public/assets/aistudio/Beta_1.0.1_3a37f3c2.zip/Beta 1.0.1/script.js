/* ============================================================
   script.js — interface do catálogo
   ============================================================ */

const els = {
  header: document.getElementById("header"),
  hero: document.getElementById("hero"),
  heroBg: document.getElementById("heroBg"),
  heroBgNext: document.getElementById("heroBgNext"),
  heroDots: document.getElementById("heroDots"),
  heroPrev: document.getElementById("heroPrev"),
  heroNext: document.getElementById("heroNext"),
  heroContent: document.getElementById("heroContent"),
  rows: document.getElementById("rows"),
  searchResults: document.getElementById("searchResults"),
  searchGrid: document.getElementById("searchGrid"),
  searchTitle: document.getElementById("searchTitle"),
  playlistPage: document.getElementById("playlistPage"),
  playlistGrid: document.getElementById("playlistGrid"),
  playlistEmpty: document.getElementById("playlistEmpty"),
  playlistSubtitle: document.getElementById("playlistSubtitle"),
  playlistAuthBtn: document.getElementById("playlistAuthBtn"),
  playlistContinue: document.getElementById("playlistContinue"),
  playlistCount: document.getElementById("playlistCount"),
  playlistNavCount: document.getElementById("playlistNavCount"),
  playlistBtn: document.getElementById("playlistBtn"),
  searchInput: document.getElementById("searchInput"),
  searchBtn: document.getElementById("searchBtn"),
  modal: document.getElementById("modal"),
  modalBody: document.getElementById("modalBody"),
  closeModal: document.getElementById("closeModal"),
  loading: document.getElementById("loading"),
  error: document.getElementById("error"),
  settingsModal: document.getElementById("settingsModal"),
  addonForm: document.getElementById("addonForm"),
  addonUrl: document.getElementById("addonUrl"),
  addonError: document.getElementById("addonError"),
  addonList: document.getElementById("addonList"),
  toast: document.getElementById("toast"),
  player: document.getElementById("player"),
  profilesScreen: document.getElementById("profilesScreen"),
  profileGrid: document.getElementById("profileGrid"),
  profilesHint: document.getElementById("profilesHint"),
  profileEditor: document.getElementById("profileEditor"),
  profileEditorTitle: document.getElementById("profileEditorTitle"),
  profileNameInput: document.getElementById("profileNameInput"),
  profileAvatarRow: document.getElementById("profileAvatarRow"),
  profilePhotoInput: document.getElementById("profilePhotoInput"),
  profileCoverInput: document.getElementById("profileCoverInput"),
  profileSave: document.getElementById("profileSave"),
  profileCancel: document.getElementById("profileCancel"),
  profileDelete: document.getElementById("profileDelete"),
  profileError: document.getElementById("profileError"),
  manageProfiles: document.getElementById("manageProfiles"),
  profileBtn: document.getElementById("profileBtn"),
  profileAvatar: document.getElementById("profileAvatar"),
  detailPage: document.getElementById("detailPage"),
};

const STATE = {
  tab: "home",
  query: "",
};

/* ---------------- fileiras ---------------- */

const ROWS = {
  home: [
    { title: "Em alta", path: "/trending/all/week" },
    { title: "Filmes populares", path: "/movie/popular", type: "movie" },
    { title: "Séries populares", path: "/tv/popular", type: "tv" },
    { title: "Séries em alta", path: "/trending/tv/week", type: "tv" },
    { title: "Filmes bem avaliados", path: "/movie/top_rated", type: "movie" },
    { title: "Séries bem avaliadas", path: "/tv/top_rated", type: "tv" },
  ],
  movie: [
    { title: "Populares", path: "/movie/popular" },
    { title: "Mais bem avaliados", path: "/movie/top_rated" },
    { title: "Em cartaz", path: "/movie/now_playing" },
    { title: "Em breve", path: "/movie/upcoming" },
    { title: "Ação", path: "/discover/movie", params: { with_genres: 28, sort_by: "popularity.desc" } },
    { title: "Comédia", path: "/discover/movie", params: { with_genres: 35, sort_by: "popularity.desc" } },
    { title: "Terror", path: "/discover/movie", params: { with_genres: 27, sort_by: "popularity.desc" } },
    { title: "Ficção científica", path: "/discover/movie", params: { with_genres: 878, sort_by: "popularity.desc" } },
  ],
  tv: [
    { title: "Séries populares", path: "/tv/popular" },
    { title: "Mais bem avaliadas", path: "/tv/top_rated" },
    { title: "Em exibição hoje", path: "/tv/airing_today" },
    { title: "No ar agora", path: "/tv/on_the_air" },
    { title: "Drama", path: "/discover/tv", params: { with_genres: 18, sort_by: "popularity.desc" } },
    { title: "Comédia", path: "/discover/tv", params: { with_genres: 35, sort_by: "popularity.desc" } },
    { title: "Sci-Fi e fantasia", path: "/discover/tv", params: { with_genres: 10765, sort_by: "popularity.desc" } },
    { title: "Documentários", path: "/discover/tv", params: { with_genres: 99, sort_by: "popularity.desc" } },
  ],
};

/* ---------------- utilidades de interface ---------------- */

let toastTimer = null;

function showToast(message, ms = 2600) {
  els.toast.textContent = message;
  els.toast.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => els.toast.classList.add("hidden"), ms);
}

document.addEventListener("app:toast", (event) => showToast(event.detail.message));

/* Logo em imagem: se logo-netfilmes.png não estiver na pasta, mostra o
   nome em texto em vez de um ícone quebrado no cabeçalho. */
(function initLogo() {
  const logo = document.getElementById("logo");
  if (!logo) return;
  const img = logo.querySelector("img");
  if (!img) return;
  const fallback = () => logo.classList.add("logo-no-image");
  img.addEventListener("error", fallback);
  if (img.complete && img.naturalWidth === 0) fallback();
})();

function showLoading(show) {
  els.loading.classList.toggle("hidden", !show);
  if (show) els.error.classList.add("hidden");
}

function showError(message) {
  els.error.textContent = message;
  els.error.classList.remove("hidden");
  els.loading.classList.add("hidden");
}

function setActiveNav(tab) {
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.classList.toggle("active", link.dataset.tab === tab);
  });
}

window.addEventListener("scroll", () => {
  els.header.classList.toggle("scrolled", window.scrollY > 50);
});

/* ---------------- cards ---------------- */

/* Capa em paisagem (16:9), como as fileiras do Netflix: usa o backdrop do
   TMDB. Sem backdrop, mostra o pôster inteiro (sem cortar) no mesmo quadro. */
function cardImageHTML(media) {
  const backdrop = media.backdrop || imgUrl(media.backdropPath, "w780");
  if (backdrop) {
    return `<img class="card-img" src="${backdrop}" alt="${esc(media.title)}" loading="lazy">`;
  }

  const poster = media.poster || imgUrl(media.posterPath, "w342");
  if (poster) {
    return `<img class="card-img is-poster" src="${poster}" alt="${esc(media.title)}" loading="lazy">`;
  }

  return `<div class="card-placeholder">${esc(media.title)}</div>`;
}

/* Trailer oficial tocando na própria capa enquanto o mouse está em cima */
let cardHoverTimer = null;

function cardPreviewUrl(key, sound) {
  const params = new URLSearchParams({
    autoplay: "1",
    mute: sound ? "0" : "1",
    controls: "0",
    modestbranding: "1",
    rel: "0",
    playsinline: "1",
    loop: "1",
    playlist: key,
    iv_load_policy: "3",
    disablekb: "1",
    fs: "0",
  });
  return `https://www.youtube-nocookie.com/embed/${key}?${params.toString()}`;
}

function stopCardPreview(card) {
  clearTimeout(cardHoverTimer);
  const preview = card.querySelector(".card-preview");
  if (preview) preview.remove();
}

async function startCardPreview(card, media) {
  if (!card.isConnected || !card.matches(":hover")) return;
  if (card.querySelector(".card-preview")) return;

  const trailer = await findTrailer(media).catch(() => null);
  if (!trailer) return;
  if (!card.isConnected || !card.matches(":hover")) return;
  if (card.querySelector(".card-preview")) return;

  const prefs = getTrailerPrefs();
  // Navegador só libera áudio automático depois de alguma interação na página
  const activate = navigator.userActivation;
  const sound = prefs.sound && (!activate || activate.hasBeenActive);

  const preview = document.createElement("div");
  preview.className = "card-preview";
  preview.innerHTML = `
    <iframe src="${cardPreviewUrl(trailer.key, sound)}" data-sound="${sound ? 1 : 0}"
      title="${esc(media.title)}" allow="autoplay; encrypted-media"
      referrerpolicy="strict-origin-when-cross-origin" tabindex="-1" aria-hidden="true"></iframe>
    <button type="button" class="card-sound" title="${sound ? "Desligar som" : "Ativar som"}"
      aria-label="Ligar ou desligar o som do trailer">${sound ? "🔊" : "🔇"}</button>`;

  const frame = preview.querySelector("iframe");
  const soundBtn = preview.querySelector(".card-sound");

  soundBtn.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    const sound = frame.dataset.sound !== "1";
    frame.dataset.sound = sound ? "1" : "0";
    frame.src = cardPreviewUrl(trailer.key, sound);
    soundBtn.textContent = sound ? "🔊" : "🔇";
    soundBtn.title = sound ? "Desligar som" : "Ativar som";
    setTrailerPrefs({ sound });
  });

  card.appendChild(preview);
}

function attachCardPreview(card, media) {
  if (!window.matchMedia("(hover: hover) and (pointer: fine)").matches) return;
  if (document.body.classList.contains("tv-mode")) return;

  card.addEventListener("mouseenter", () => {
    clearTimeout(cardHoverTimer);
    if (!getTrailerPrefs().enabled) return;
    cardHoverTimer = setTimeout(() => startCardPreview(card, media), 900);
  });

  card.addEventListener("mouseleave", () => stopCardPreview(card));
}

function createCard(media) {
  const card = document.createElement("div");
  card.className = "card";
  card.tabIndex = 0;

  card.innerHTML = `
    ${cardImageHTML(media)}
    <span class="card-badge">${media.type === "tv" ? "SÉRIE" : "FILME"}</span>
    <div class="card-info">
      <div class="card-title">${esc(media.title)}</div>
      <div class="card-rating">★ ${media.rating ? media.rating.toFixed(1) : "—"}</div>
    </div>`;

  card.addEventListener("click", () => {
    stopCardPreview(card);
    openDetail(media);
  });
  card.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      stopCardPreview(card);
      openDetail(media);
    }
  });

  attachCardPreview(card, media);
  return card;
}

function createContinueCard(entry) {
  const media = entry.media;
  const card = document.createElement("div");
  card.className = "card continue-card";
  card.tabIndex = 0;
  const percent = Math.min(100, (entry.position / entry.duration) * 100);
  const episode = media.type === "tv" ? `T${media.season}E${media.episode}` : "Filme";

  card.innerHTML = `
    ${cardImageHTML(media)}
    <div class="card-progress"><span style="width:${percent}%"></span></div>
    <div class="card-info">
      <div class="card-title">${esc(media.title)}</div>
      <div class="card-sub">${esc(
        [episode, media.episodeTitle].filter(Boolean).join(" · ")
      )}</div>
    </div>`;

  card.addEventListener("click", () => Player.open(media));
  card.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " " || event.key === "Select") {
      event.preventDefault();
      Player.open(media);
    }
  });
  return card;
}

function createRow(title, items, makeCard = createCard, extraClass = "") {
  const row = document.createElement("div");
  row.className = `row${extraClass ? ` ${extraClass}` : ""}`;

  const wrap = document.createElement("div");
  wrap.className = "row-wrap";

  const track = document.createElement("div");
  track.className = "row-track";
  items.forEach((item, index) => track.appendChild(makeCard(item, index)));

  const prev = document.createElement("button");
  prev.className = "row-nav prev";
  prev.innerHTML = "‹";
  prev.setAttribute("aria-label", "Anterior");
  prev.addEventListener("click", () => {
    track.scrollBy({ left: -track.clientWidth * 0.8, behavior: "smooth" });
  });

  const next = document.createElement("button");
  next.className = "row-nav next";
  next.innerHTML = "›";
  next.setAttribute("aria-label", "Próximo");
  next.addEventListener("click", () => {
    track.scrollBy({ left: track.clientWidth * 0.8, behavior: "smooth" });
  });

  wrap.appendChild(prev);
  wrap.appendChild(track);
  wrap.appendChild(next);

  row.innerHTML = `<h2 class="row-title">${esc(title)}</h2>`;
  row.appendChild(wrap);
  return row;
}

/* ---------------- Top 10 de hoje ----------------
   Fileira no estilo Netflix: pôster em pé com o número grande ao fundo. */

const TOP10_LIMIT = 10;

async function loadTop10(type = "movie", limit = TOP10_LIMIT) {
  const isTv = type === "tv";
  const params = { sort_by: "popularity.desc", include_adult: "false" };
  if (!isTv) params.region = "BR";

  const data = await Tmdb.cached(isTv ? "/discover/tv" : "/discover/movie", params);
  return (data.results || [])
    .filter((item) => item && item.poster_path)
    .sort((a, b) => (b.popularity || 0) - (a.popularity || 0))
    .slice(0, limit)
    .map((item) => normMedia(item, type))
    .filter(Boolean);
}

function createTopRankCard(media, rank) {
  const card = document.createElement("div");
  card.className = "card top-card";
  card.tabIndex = 0;

  const poster = imgUrl(media.posterPath, "w500");
  const posterHTML = poster
    ? `<img class="card-img" src="${poster}" alt="${esc(media.title)}" loading="lazy">`
    : `<div class="card-placeholder">${esc(media.title)}</div>`;

  card.innerHTML = `
    <span class="top-rank" aria-hidden="true">${rank}</span>
    <div class="top-poster">
      ${posterHTML}
      <div class="card-info">
        <div class="card-title">${esc(media.title)}</div>
        <div class="card-rating">★ ${media.rating ? media.rating.toFixed(1) : "—"}</div>
      </div>
    </div>`;

  card.setAttribute("aria-label", `${rank}º lugar: ${media.title}`);

  card.addEventListener("click", () => openDetail(media));
  card.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      openDetail(media);
    }
  });

  const posterEl = card.querySelector(".top-poster");
  if (posterEl) attachCardPreview(posterEl, media);
  return card;
}

/* ---------------- recomendado para você ----------------
   Usa o histórico + playlist do PERFIL ATIVO para pedir recomendações
   ao TMDB e juntar tudo numa única fileira. */

function tasteSources(limit = 5) {
  const entries = [
    ...loadProgressList().map((entry) => entry.media),
    ...getMyList().map((entry) => entry.media),
  ];

  const seen = new Set();
  const sources = [];
  entries.forEach((media) => {
    if (!media || !media.id) return;
    const type = media.type === "tv" ? "tv" : "movie";
    const key = `${type}:${media.id}`;
    if (seen.has(key)) return;
    seen.add(key);
    sources.push({ type, id: media.id });
  });
  return sources.slice(0, limit);
}

async function loadRecommended(limit = 20) {
  const sources = tasteSources(5);
  if (!sources.length) return [];

  const known = new Set(
    [...loadProgressList().map((entry) => entry.media), ...getMyList().map((entry) => entry.media)]
      .filter(Boolean)
      .map((media) => `${media.type === "tv" ? "tv" : "movie"}:${media.id}`)
  );

  const settled = await Promise.allSettled(
    sources.map(({ type, id }) => Tmdb.cached(`/${type}/${id}/recommendations`))
  );

  const pool = new Map();
  settled.forEach((result, index) => {
    if (result.status !== "fulfilled") return;
    const type = sources[index].type;
    (result.value.results || []).forEach((item, rank) => {
      if (!item || (!item.backdrop_path && !item.poster_path)) return;
      const key = `${type}:${item.id}`;
      if (known.has(key)) return;
      // Títulos que aparecem no topo das listas pesam mais
      const weight = 1 + Math.max(0, 10 - rank) / 10;
      const entry = pool.get(key);
      if (entry) entry.score += weight;
      else pool.set(key, { item, type, score: weight });
    });
  });

  return [...pool.values()]
    .sort(
      (a, b) =>
        b.score - a.score || (b.item.popularity || 0) - (a.item.popularity || 0)
    )
    .slice(0, limit)
    .map((entry) => normMedia(entry.item, entry.type))
    .filter(Boolean);
}

function createTop10Row(title, items) {
  return createRow(
    title,
    items,
    (media, index) => createTopRankCard(media, index + 1),
    "row-top10"
  );
}

function buildContinueRow() {
  const items = continueWatching();
  if (!items.length) return null;

  const row = document.createElement("div");
  row.className = "row row-continue";
  row.innerHTML = `<h2 class="row-title">Continuar assistindo</h2>`;

  const track = document.createElement("div");
  track.className = "row-track";
  items.forEach((entry) => track.appendChild(createContinueCard(entry)));
  row.appendChild(track);
  return row;
}

function renderContinueRow() {
  // Idempotente: se a fileira já está na home (o player fechou, ou a nuvem
  // restaurou os dados, enquanto a tela carregava), ela é trocada em vez de
  // virar uma segunda "Continuar assistindo".
  refreshContinueRow();
}

function refreshContinueRow() {
  const existing = els.rows.querySelector(".row-continue");
  const next = buildContinueRow();
  if (existing && next) existing.replaceWith(next);
  else if (existing) existing.remove();
  else if (next) els.rows.prepend(next);
}

/* ---------------- minha playlist ---------------- */

function updatePlaylistCount() {
  const count = getMyList().length;
  [els.playlistCount, els.playlistNavCount].forEach((badge) => {
    if (!badge) return;
    badge.textContent = count > 99 ? "99+" : String(count);
    badge.classList.toggle("hidden", !count);
  });
  if (els.playlistBtn) {
    els.playlistBtn.title = count
      ? `Minha playlist (${count})`
      : "Minha playlist";
  }
}

function createPlaylistCard(entry) {
  const card = createCard(entry.media);
  card.classList.add("playlist-card");

  const remove = document.createElement("button");
  remove.type = "button";
  remove.className = "playlist-remove";
  remove.title = "Remover da playlist";
  remove.setAttribute("aria-label", `Remover ${entry.media.title} da playlist`);
  remove.textContent = "✕";
  remove.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    removeFromMyList(entry.media);
    updatePlaylistCount();
    renderPlaylistPage();
    showToast("Removido da sua playlist.");
  });

  const play = document.createElement("button");
  play.type = "button";
  play.className = "playlist-play";
  play.title = "Assistir";
  play.setAttribute("aria-label", `Assistir ${entry.media.title}`);
  play.textContent = "▶";
  play.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    const media = playlistPlaybackMedia(entry);
    if (media) Player.open(media);
  });

  card.appendChild(remove);
  card.appendChild(play);
  return card;
}

function renderPlaylistPage() {
  const entries = getMyList();
  const profile = getActiveProfile();
  const user = typeof Auth !== "undefined" ? Auth.getUser() : null;
  const configured = typeof Auth !== "undefined" && Auth.isConfigured();

  els.hero.classList.add("hidden");
  stopHeroSlideshow();
  els.rows.innerHTML = "";
  els.searchResults.classList.add("hidden");
  els.error.classList.add("hidden");
  els.playlistPage.classList.remove("hidden");
  showLoading(false);

  els.playlistContinue.innerHTML = "";
  const continueRow = buildContinueRow();
  if (continueRow) els.playlistContinue.appendChild(continueRow);

  const meta = [];
  if (profile) meta.push(`Perfil: ${profile.name}`);
  meta.push(`${entries.length} título${entries.length === 1 ? "" : "s"}`);
  meta.push(user ? `Sincronizada com ${user.email}` : "Salva neste navegador");
  els.playlistSubtitle.textContent = meta.join(" · ");

  els.playlistGrid.innerHTML = "";
  entries.forEach((entry) => {
    els.playlistGrid.appendChild(createPlaylistCard(entry));
  });
  els.playlistEmpty.classList.toggle("hidden", entries.length > 0);

  if (els.playlistAuthBtn) {
    els.playlistAuthBtn.classList.toggle("hidden", !!user);
    els.playlistAuthBtn.textContent = configured
      ? "Entrar / Criar conta"
      : "Como ativar o login";
  }

  updatePlaylistCount();
}

/* ---------------- home / abas ---------------- */

/* ---------------- destaque em slide ---------------- */

const HERO_INTERVAL = 9000;

const heroSlide = {
  items: [],
  index: 0,
  timer: null,
  paused: false,
  fadeToken: 0,
};

async function loadHeroMediaList(limit = 6) {
  const data = await Tmdb.cached("/trending/all/week");
  const pool = (data.results || []).filter(
    (item) => item.media_type !== "person" && item.backdrop_path && item.overview
  );
  if (!pool.length) return [];

  const picks = pool.slice(0, 12);
  for (let i = picks.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [picks[i], picks[j]] = [picks[j], picks[i]];
  }
  return picks.slice(0, limit).map((item) => normMedia(item));
}

function stopHeroSlideshow() {
  if (heroSlide.timer) clearInterval(heroSlide.timer);
  heroSlide.timer = null;
}

function startHeroSlideshow() {
  stopHeroSlideshow();
  if (heroSlide.items.length < 2) return;
  heroSlide.timer = setInterval(() => {
    if (heroSlide.paused || document.hidden) return;
    updateHeroSlide(heroSlide.index + 1, true);
  }, HERO_INTERVAL);
}

function renderHeroContent(media) {
  const inList = typeof isInMyList === "function" && isInMyList(media);
  const kind = media.type === "tv" ? "Série" : "Filme";
  const tags = [
    media.rating ? `★ ${media.rating.toFixed(1)}` : null,
    media.year || null,
    kind,
  ].filter(Boolean);

  els.heroContent.innerHTML = `
    <div class="hero-billboard">
      <span class="hero-kind">${esc(kind)}</span>
      <h1 class="hero-title">${esc(media.title)}</h1>
      <p class="hero-tags">${tags.map((t) => `<span>${esc(t)}</span>`).join("")}</p>
      <p class="hero-overview">${esc(media.overview)}</p>
      <div class="hero-actions">
        <button type="button" class="hero-action ghost" id="heroList" aria-label="Minha lista">
          <span class="hero-action-icon">${inList ? "✓" : "+"}</span>
          <span class="hero-action-label">${inList ? "Na lista" : "Minha lista"}</span>
        </button>
        <button type="button" class="hero-action play" id="heroPlay">
          <span class="hero-action-icon">▶</span>
          <span class="hero-action-label">Assistir</span>
        </button>
        <button type="button" class="hero-action ghost" id="heroInfo" aria-label="Saiba mais">
          <span class="hero-action-icon">ℹ</span>
          <span class="hero-action-label">Saiba mais</span>
        </button>
      </div>
    </div>`;

  document.getElementById("heroPlay").addEventListener("click", () => startWatching(media));
  document.getElementById("heroInfo").addEventListener("click", () => openDetail(media));
  const listBtn = document.getElementById("heroList");
  if (listBtn) {
    listBtn.addEventListener("click", () => {
      if (typeof toggleMyList !== "function") return;
      if (!getActiveProfileId()) {
        showToast("Escolha um perfil para usar a playlist.");
        return;
      }
      const nowIn = toggleMyList(media);
      listBtn.querySelector(".hero-action-icon").textContent = nowIn ? "✓" : "+";
      listBtn.querySelector(".hero-action-label").textContent = nowIn
        ? "Na lista"
        : "Minha lista";
      if (typeof updatePlaylistCount === "function") updatePlaylistCount();
      showToast(nowIn ? "Adicionado à playlist." : "Removido da playlist.");
    });
  }
}

function updateHeroSlide(index, animate = true) {
  const list = heroSlide.items;
  if (!list.length) return;

  heroSlide.index = ((index % list.length) + list.length) % list.length;
  const media = list[heroSlide.index];
  const backdrop = imgUrl(media.backdropPath, "original") || imgUrl(media.posterPath, "w780");
  const image = backdrop ? `url("${backdrop}")` : "none";

  if (animate && els.heroBgNext) {
    heroSlide.fadeToken += 1;
    const token = heroSlide.fadeToken;
    els.heroBgNext.style.backgroundImage = image;
    els.heroBgNext.classList.add("show");
    setTimeout(() => {
      if (token !== heroSlide.fadeToken) return;
      if (els.heroBg) els.heroBg.style.backgroundImage = image;
      els.heroBgNext.classList.remove("show");
      els.heroBgNext.style.backgroundImage = "none";
    }, 650);
  } else if (els.heroBg) {
    els.heroBg.style.backgroundImage = image;
    if (els.heroBgNext) {
      els.heroBgNext.classList.remove("show");
      els.heroBgNext.style.backgroundImage = "none";
    }
  }

  renderHeroContent(media);

  if (els.heroDots) {
    els.heroDots.querySelectorAll(".hero-dot").forEach((dot, i) => {
      dot.classList.toggle("active", i === heroSlide.index);
    });
  }
}

function renderHero(items) {
  const list = Array.isArray(items) ? items.filter(Boolean) : [];
  heroSlide.items = list;
  heroSlide.index = 0;

  if (!list.length) {
    stopHeroSlideshow();
    els.hero.classList.add("hidden");
    return;
  }

  els.hero.classList.remove("hidden");

  if (els.heroDots) {
    els.heroDots.innerHTML = list
      .map(
        (_, i) =>
          `<button type="button" class="hero-dot" data-i="${i}" aria-label="Destaque ${i + 1}"></button>`
      )
      .join("");
    els.heroDots.classList.toggle("hidden", list.length < 2);
    els.heroDots.querySelectorAll(".hero-dot").forEach((dot, i) => {
      dot.addEventListener("click", () => goHero(i));
    });
  }

  [els.heroPrev, els.heroNext].forEach((button) => {
    if (button) button.classList.toggle("hidden", list.length < 2);
  });

  updateHeroSlide(0, false);
  startHeroSlideshow();
}

function goHero(index) {
  updateHeroSlide(index, true);
  startHeroSlideshow();
}

function startWatching(media) {
  if (media.type === "tv") {
    const latest = latestProgressForShow(media.id);
    if (latest) {
      return Player.open({
        ...media,
        season: latest.media.season,
        episode: latest.media.episode,
        episodeTitle: latest.media.episodeTitle,
      });
    }
    return Player.open({ ...media, season: 1, episode: 1 });
  }
  return Player.open(media);
}

async function fetchRow(row, tab) {
  const type = row.type || (tab === "movie" ? "movie" : tab === "tv" ? "tv" : undefined);
  const data = await Tmdb.cached(row.path, row.params);
  const items = (data.results || [])
    .filter((item) => item.media_type !== "person")
    .map((item) => normMedia(item, type))
    .filter(Boolean);
  return { title: row.title, items };
}

/* Cada carga de aba recebe um número. Se outra começar enquanto esta espera
   o TMDB (clicar em Início duas vezes, entrar na conta, trocar de perfil),
   só a mais nova pinta a tela — antes as duas pintavam e a home ficava com
   as fileiras duplicadas. */
let loadTabToken = 0;

async function loadTab(tab) {
  const token = ++loadTabToken;
  closeDetailPage();
  STATE.tab = tab;
  STATE.query = "";
  els.searchInput.value = "";
  setActiveNav(tab);
  els.searchResults.classList.add("hidden");
  els.playlistPage.classList.add("hidden");
  els.error.classList.add("hidden");
  els.rows.innerHTML = "";
  els.hero.classList.toggle("hidden", tab !== "home");
  if (tab !== "home") stopHeroSlideshow();
  showLoading(true);

  if (tab === "playlist") {
    renderPlaylistPage();
    return;
  }

  const rows = ROWS[tab];
  const [hero, topMovies, topSeries, recommended, ...results] = await Promise.allSettled([
    tab === "home" ? loadHeroMediaList() : Promise.resolve(null),
    tab === "home" ? loadTop10("movie") : Promise.resolve(null),
    tab === "home" ? loadTop10("tv") : Promise.resolve(null),
    tab === "home" ? loadRecommended() : Promise.resolve(null),
    ...rows.map((row) => fetchRow(row, tab)),
  ]);

  if (token !== loadTabToken) return;

  showLoading(false);

  const failed = results.filter((result) => result.status === "rejected");
  if (failed.length === results.length) {
    showError(failed[0]?.reason?.message || "Não foi possível carregar o catálogo.");
    return;
  }

  if (tab === "home") {
    renderHero(hero.status === "fulfilled" ? hero.value : []);
    renderContinueRow();
    if (recommended.status === "fulfilled" && recommended.value.length) {
      els.rows.appendChild(createRow("Recomendado para você", recommended.value));
    }
    const topRows = [
      ["Top 10 filmes de hoje", topMovies],
      ["Top 10 séries de hoje", topSeries],
    ];
    topRows.forEach(([title, result]) => {
      if (result.status === "fulfilled" && result.value.length) {
        els.rows.appendChild(createTop10Row(title, result.value));
      }
    });
  }

  results.forEach((result) => {
    if (result.status === "fulfilled" && result.value.items.length) {
      els.rows.appendChild(createRow(result.value.title, result.value.items));
    }
  });
}

/* ---------------- busca ---------------- */

async function doSearch(query) {
  const term = query.trim();
  if (!term) {
    loadTab(STATE.tab);
    return;
  }

  STATE.query = term;
  closeDetailPage();
  els.hero.classList.add("hidden");
  stopHeroSlideshow();
  els.rows.innerHTML = "";
  els.playlistPage.classList.add("hidden");
  els.searchResults.classList.remove("hidden");
  els.searchGrid.innerHTML = "";
  els.searchTitle.textContent = `Resultados para “${term}”`;
  showLoading(true);

  try {
    const data = await Tmdb.cached("/search/multi", {
      query: term,
      include_adult: "false",
    });
    const items = (data.results || [])
      .filter((item) => item.media_type === "movie" || item.media_type === "tv")
      .map((item) => normMedia(item));

    showLoading(false);

    if (!items.length) {
      els.searchTitle.textContent = `Nada encontrado para “${term}”`;
      return;
    }
    items.forEach((item) => els.searchGrid.appendChild(createCard(item)));
  } catch (err) {
    showError(err.message);
  }
}

/* ---------------- detalhes ---------------- */

function normalizeDetail(media, detail) {
  return {
    ...media,
    title: detail.title || detail.name || media.title,
    overview: detail.overview || media.overview,
    posterPath: detail.poster_path || media.posterPath,
    backdropPath: detail.backdrop_path || media.backdropPath,
    rating: Number(detail.vote_average) || media.rating,
    year: String(
      detail.release_date || detail.first_air_date || media.date || ""
    ).slice(0, 4),
  };
}

function detailHTML(media, info, extra = "") {
  const backdrop = imgUrl(media.backdropPath, "w780") || imgUrl(media.posterPath, "w500");

  return `
    <div class="modal-hero" style="background-image:url('${backdrop || ""}')"></div>
    <div class="modal-body">
      <h2 class="modal-title">${esc(media.title)}</h2>
      <div class="modal-meta">${info.meta}</div>
      <div class="modal-actions">
        <button class="btn btn-play" id="detailPlay">▶ Assistir</button>
        <button class="btn btn-trailer" id="detailTrailer">▶ Trailer</button>
        <button class="btn btn-ghost" id="detailList">＋ Minha playlist</button>
        <button class="btn btn-ghost" id="detailAdd">＋ Fonte</button>
        <button class="btn btn-ghost" id="detailMore">ⓘ Mais detalhes</button>
      </div>
      <p class="modal-overview">${esc(media.overview) || "Sem sinopse disponível."}</p>
      ${info.genres ? `<p class="modal-genres">${esc(info.genres)}</p>` : ""}
      ${extra}
      ${sourcePanelHTML()}
      <div class="detail-similar" id="detailSimilar"></div>
    </div>`;
}

function sourcePanelHTML() {
  return `
    <div class="source-panel hidden" id="sourcePanel">
      <div class="source-head">
        <h3>Adicionar fonte de vídeo</h3>
        <div class="source-episode hidden" id="sourceEpisodeWrap">
          <label for="srcEpisode">Episódio</label>
          <select id="srcEpisode"></select>
        </div>
      </div>
      <p class="hint" id="sourceTarget"></p>
      <p class="hint">
        Aceita MP4, HLS (.m3u8), página de embed ou YouTube. Use apenas conteúdo que você
        tem o direito de exibir.
      </p>
      <form class="source-form" autocomplete="off">
        <input name="label" placeholder="Rótulo (ex.: 1080p)" maxlength="40">
        <input name="url" placeholder="https://exemplo.com/video.mp4" required>
        <select name="kind">
          <option value="">Detectar automaticamente</option>
          <option value="mp4">MP4 / arquivo direto</option>
          <option value="hls">HLS (.m3u8)</option>
          <option value="embed">Embed (iframe)</option>
          <option value="youtube">YouTube</option>
          <option value="torrent">Torrent (magnet)</option>
        </select>
        <button class="btn btn-play" type="submit">Salvar fonte</button>
      </form>
      <div class="manual-list" id="manualList"></div>
    </div>`;
}

let sourceTargetFn = null;

function renderManualSources() {
  const list = document.getElementById("manualList");
  const label = document.getElementById("sourceTarget");
  if (!list) return;

  const target = sourceTargetFn ? sourceTargetFn() : null;
  if (!target) {
    list.innerHTML = "";
    return;
  }

  if (label) {
    label.textContent =
      target.type === "tv"
        ? `Vale para T${target.season}E${target.episode}.`
        : "Vale para este filme.";
  }

  const items = getManualSources(target);
  if (!items.length) {
    list.innerHTML = "";
    return;
  }

  list.innerHTML = `<h4>Fontes salvas (${items.length})</h4>`;
  items.forEach((source, index) => {
    const row = document.createElement("div");
    row.className = "manual-item";
    row.innerHTML = `
      <div class="manual-info">
        <strong>${esc(source.label || "Fonte")}</strong>
        <span>${esc(source.url)}</span>
      </div>
      <button type="button" class="manual-remove" title="Remover">✕</button>`;

    row.querySelector(".manual-remove").addEventListener("click", () => {
      removeManualSource(target, index);
      renderManualSources();
      showToast("Fonte removida.");
    });
    list.appendChild(row);
  });
}

function updateDetailListButton(media) {
  const button = document.getElementById("detailList");
  if (!button) return;
  const added = isInMyList(media);
  button.textContent = added ? "✓ Na playlist" : "＋ Minha playlist";
  button.classList.toggle("in-list", added);
  button.setAttribute("aria-pressed", added ? "true" : "false");
}

function bindDetail(media, opts = {}) {
  sourceTargetFn = opts.getTarget || (() => media);

  document.getElementById("detailPlay").addEventListener("click", opts.play || (() => Player.open(media)));
  document.getElementById("detailTrailer").addEventListener("click", () => Player.openTrailer(media));

  const listButton = document.getElementById("detailList");
  if (listButton) {
    updateDetailListButton(media);
    listButton.addEventListener("click", () => {
      if (!getActiveProfileId()) {
        showToast("Crie ou selecione um perfil primeiro.");
        openProfilesScreen();
        return;
      }
      const added = toggleMyList(media);
      updateDetailListButton(media);
      updatePlaylistCount();
      showToast(
        added ? "Adicionado à sua playlist." : "Removido da sua playlist."
      );
      if (STATE.tab === "playlist") renderPlaylistPage();
    });
  }

  const moreButton = document.getElementById("detailMore");
  if (moreButton) moreButton.addEventListener("click", () => openDetailPage(media));

  const panel = document.getElementById("sourcePanel");
  document.getElementById("detailAdd").addEventListener("click", () => {
    panel.classList.toggle("hidden");
    if (!panel.classList.contains("hidden")) {
      panel.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  });

  panel.querySelector("form").addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const url = String(data.get("url") || "").trim();
    const label = String(data.get("label") || "").trim();
    let kind = String(data.get("kind") || "").trim();    if (!url) return;

    if (!kind) kind = detectKind(url);
    if (kind === "torrent" && !getTorrentPrefs().enabled) {
      showToast("Torrents estão desligados. Ligue em ⚙ Configurações.");
      return;
    }

    if (kind === "youtube" && !youtubeKey(url)) {
      showToast("Link do YouTube inválido.");
      return;
    }
    if (kind === "torrent" && !/^magnet:\?/i.test(url)) {
      showToast("Cole um link magnet: válido (o navegador não abre .torrent por URL).");
      return;
    }

    const target = sourceTargetFn();
    addManualSource(target, {
      label: label || (kind === "youtube" ? "Trailer (YouTube)" : "Fonte"),
      url,
      kind,
    });
    form.reset();
    renderManualSources();
    showToast("Fonte salva.");
  });

  renderManualSources();
}

function focusSourcePanel() {
  const panel = document.getElementById("sourcePanel");
  if (!panel) return;
  panel.classList.remove("hidden");
  setTimeout(() => panel.scrollIntoView({ behavior: "smooth", block: "center" }), 100);
}

/* ---------------- títulos similares ---------------- */

async function loadSimilar(media, limit = 12) {
  const type = media.type === "tv" ? "tv" : "movie";
  const paths = [
    `/${type}/${media.id}/similar`,
    `/${type}/${media.id}/recommendations`,
  ];

  for (const path of paths) {
    const data = await Tmdb.cached(path).catch(() => null);
    const items = (data?.results || [])
      .filter(
        (item) =>
          item &&
          item.media_type !== "person" &&
          (item.backdrop_path || item.poster_path)
      )
      .slice(0, limit)
      .map((item) => normMedia(item, type))
      .filter(Boolean);
    if (items.length) return items;
  }
  return [];
}

async function loadSimilarInto(container, media, title = "Títulos similares") {
  if (!container) return;
  const items = await loadSimilar(media);
  if (!container.isConnected) return;
  container.innerHTML = "";
  if (items.length) container.appendChild(createRow(title, items));
}

/* ---------------- página de detalhes (capa grande) ---------------- */

let detailTrailerToken = 0;
let detailTrailerResize = null;
let detailTrailerObserver = null;
let detailPageScroll = null;

function stopDetailTrailer() {
  detailTrailerToken += 1;
  if (detailTrailerResize) {
    window.removeEventListener("resize", detailTrailerResize);
    detailTrailerResize = null;
  }
  if (detailTrailerObserver) {
    detailTrailerObserver.disconnect();
    detailTrailerObserver = null;
  }
}

function killDetailTrailer() {
  stopDetailTrailer();
  const box = document.getElementById("dpTrailerBox");
  if (box) {
    box.innerHTML = "";
    box.style.background = "";
  }
}

async function startDetailTrailer(media, page) {
  const token = ++detailTrailerToken;
  if (!getTrailerPrefs().enabled) return;

  const box = page.querySelector(".dp-trailer");
  const hero = page.querySelector(".dp-hero");
  if (!box || !hero) return;

  const trailer = await findTrailer(media).catch(() => null);
  if (!trailer || token !== detailTrailerToken || !box.isConnected) return;

  const activate = navigator.userActivation;
  let sound = getTrailerPrefs().sound && (!activate || activate.hasBeenActive);

  const frame = document.createElement("iframe");
  frame.src = cardPreviewUrl(trailer.key, sound);
  frame.title = `${media.title} — trailer`;
  frame.setAttribute("allow", "autoplay; encrypted-media");
  frame.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
  frame.setAttribute("aria-hidden", "true");
  frame.tabIndex = -1;
  box.style.background = "#000";
  box.appendChild(frame);

  // O iframe é 16:9; aumentamos até cobrir a capa sem distorcer
  const cover = () => {
    if (!frame.isConnected) return;
    const w = hero.clientWidth;
    const h = hero.clientHeight;
    if (!w || !h) return;
    const ratio = 16 / 9;
    const wide = w / h > ratio;
    frame.style.width = `${Math.ceil(wide ? w : h * ratio)}px`;
    frame.style.height = `${Math.ceil(wide ? w / ratio : h)}px`;
  };
  cover();
  detailTrailerResize = cover;
  window.addEventListener("resize", cover);
  if (typeof ResizeObserver !== "undefined") {
    detailTrailerObserver = new ResizeObserver(cover);
    detailTrailerObserver.observe(hero);
  }

  const soundBtn = document.getElementById("dpSound");
  if (!soundBtn) return;
  soundBtn.classList.remove("hidden");
  soundBtn.textContent = sound ? "🔊" : "🔇";
  soundBtn.title = sound ? "Desligar som" : "Ativar som";
  soundBtn.addEventListener("click", () => {
    sound = !sound;
    frame.src = cardPreviewUrl(trailer.key, sound);
    soundBtn.textContent = sound ? "🔊" : "🔇";
    soundBtn.title = sound ? "Desligar som" : "Ativar som";
    setTrailerPrefs({ sound });
    setTimeout(cover, 300);
  });
}

function closeDetailPage() {
  if (!els.detailPage) return;
  stopDetailTrailer();
  if (detailPageScroll) {
    els.detailPage.removeEventListener("scroll", detailPageScroll);
    detailPageScroll = null;
  }
  els.detailPage.classList.add("hidden");
  els.detailPage.innerHTML = "";
  els.header.classList.toggle("scrolled", window.scrollY > 50);
}

async function openDetailPage(media) {
  const page = els.detailPage;
  if (!page) return;

  stopDetailTrailer();
  els.modal.classList.add("hidden");
  page.classList.remove("hidden");
  page.scrollTop = 0;
  els.header.classList.remove("scrolled");
  page.innerHTML = `<div class="loading">Carregando...</div>`;

  try {
    const type = media.type === "tv" ? "tv" : "movie";
    const detail = await Tmdb.cached(`/${type}/${media.id}`);
    const full = normalizeDetail(media, detail);
    const backdrop = imgUrl(full.backdropPath, "original") || imgUrl(full.posterPath, "w780");
    const genres = (detail.genres || []).map((g) => g.name).join(" · ");

    const seasons = (detail.seasons || []).filter(
      (season) => season.season_number > 0 && season.episode_count > 0
    ).length;

    const meta = [
      `<span class="hero-rating">★ ${full.rating ? full.rating.toFixed(1) : "—"}</span>`,
      full.year ? `<span>${esc(full.year)}</span>` : "",
      type === "tv"
        ? seasons
          ? `<span>${seasons} temporada${seasons > 1 ? "s" : ""}</span>`
          : ""
        : detail.runtime
          ? `<span>${fmtRuntime(detail.runtime)}</span>`
          : "",
      `<span class="type-pill">${type === "tv" ? "Série" : "Filme"}</span>`,
    ]
      .filter(Boolean)
      .join("");

    page.innerHTML = `
      <div class="dp-hero" ${
        backdrop ? `style="background-image:url('${backdrop}')"` : ""
      }>
        <div class="dp-trailer" id="dpTrailerBox"></div>
        <div class="dp-hero-shade"></div>
        <div class="dp-topbar">
          <button type="button" class="dp-back" id="dpBack">‹ Voltar</button>
          <button type="button" class="dp-sound hidden" id="dpSound" title="Ativar som"
            aria-label="Ligar ou desligar o som do trailer">🔇</button>
        </div>
        <div class="dp-hero-content">
          <h1 class="hero-title">${esc(full.title)}</h1>
          <div class="hero-meta">${meta}</div>
          <div class="hero-btns">
            <button class="btn btn-play" id="dpPlay">▶ Assistir</button>
            <button class="btn btn-trailer" id="dpTrailer">▶ Trailer</button>
            <button class="btn btn-ghost" id="dpList"></button>
            <button class="btn btn-ghost" id="dpInfo">☰ Ficha completa</button>
          </div>
        </div>
      </div>
      <div class="dp-body">
        <p class="dp-overview">${esc(full.overview) || "Sem sinopse disponível."}</p>
        ${genres ? `<p class="dp-genres">${esc(genres)}</p>` : ""}
      </div>
      <div class="dp-similar" id="dpSimilar"><p class="dp-loading">Carregando títulos similares...</p></div>`;

    document.getElementById("dpBack").addEventListener("click", closeDetailPage);
    document.getElementById("dpPlay").addEventListener("click", () => {
      killDetailTrailer();
      startWatching(full);
    });
    document.getElementById("dpTrailer").addEventListener("click", () => Player.openTrailer(full));
    document.getElementById("dpInfo").addEventListener("click", () => {
      closeDetailPage();
      openDetail(full);
    });

    const listButton = document.getElementById("dpList");
    const paintList = () => {
      const added = isInMyList(full);
      listButton.textContent = added ? "✓ Na playlist" : "＋ Minha playlist";
      listButton.classList.toggle("in-list", added);
      listButton.setAttribute("aria-pressed", added ? "true" : "false");
    };
    paintList();
    listButton.addEventListener("click", () => {
      if (!getActiveProfileId()) {
        showToast("Crie ou selecione um perfil primeiro.");
        openProfilesScreen();
        return;
      }
      const added = toggleMyList(full);
      paintList();
      updatePlaylistCount();
      showToast(added ? "Adicionado à sua playlist." : "Removido da sua playlist.");
    });

    detailPageScroll = () => {
      els.header.classList.toggle("scrolled", page.scrollTop > 40);
    };
    page.addEventListener("scroll", detailPageScroll);

    loadSimilarInto(document.getElementById("dpSimilar"), full);
    startDetailTrailer(full, page);
  } catch (err) {
    page.innerHTML = `<div class="error">${esc(
      err.message || "Erro ao carregar detalhes."
    )}</div>`;
  }
}

async function openDetail(media, opts = {}) {
  els.modal.classList.remove("hidden");
  els.modalBody.innerHTML = `<div class="loading">Carregando...</div>`;

  try {
    if (media.type === "tv") await renderTvDetail(media, opts);
    else await renderMovieDetail(media, opts);
  } catch (err) {
    els.modalBody.innerHTML = `<div class="error">${esc(err.message || "Erro ao carregar detalhes.")}</div>`;
  }
}

async function renderMovieDetail(media, opts = {}) {
  const detail = await Tmdb.cached(`/movie/${media.id}`);
  const full = normalizeDetail(media, detail);

  const meta = [
    `<span class="rating">★ ${full.rating ? full.rating.toFixed(1) : "—"}</span>`,
    full.year ? `<span>${esc(full.year)}</span>` : "",
    detail.runtime ? `<span>${fmtRuntime(detail.runtime)}</span>` : "",
    `<span class="type-pill">Filme</span>`,
  ]
    .filter(Boolean)
    .join("");

  const genres = (detail.genres || []).map((g) => g.name).join(" · ");

  els.modalBody.innerHTML = detailHTML(full, { meta, genres });
  bindDetail(full);
  loadSimilarInto(document.getElementById("detailSimilar"), full);

  if (opts.focusSource) focusSourcePanel();
}

function fillSourceEpisodes(episodes, defaultEpisode) {
  const wrap = document.getElementById("sourceEpisodeWrap");
  const select = document.getElementById("srcEpisode");
  if (!wrap || !select) return;

  wrap.classList.remove("hidden");
  select.innerHTML = episodes
    .map(
      (ep) =>
        `<option value="${ep.episode_number}">Episódio ${ep.episode_number}${
          ep.name ? ` — ${esc(ep.name)}` : ""
        }</option>`
    )
    .join("");

  if (defaultEpisode && episodes.some((ep) => ep.episode_number === defaultEpisode)) {
    select.value = String(defaultEpisode);
  }
  select.onchange = renderManualSources;
  renderManualSources();
}

function renderEpisodeList(show, season, episodes) {
  const list = document.getElementById("episodeList");
  if (!list) return;

  if (!episodes.length) {
    list.innerHTML = `<p class="hint">Nenhum episódio nesta temporada.</p>`;
    return;
  }

  list.innerHTML = "";
  episodes.forEach((ep) => {
    const progress = getProgress({
      type: "tv",
      id: show.id,
      season,
      episode: ep.episode_number,
    });
    const percent = progress
      ? Math.min(100, (progress.position / progress.duration) * 100)
      : 0;

    const row = document.createElement("div");
    row.className = "episode";
    row.tabIndex = 0;
    row.innerHTML = `
      ${
        ep.still_path
          ? `<div class="ep-still"><img src="${imgUrl(ep.still_path, "w300")}" alt="" loading="lazy"></div>`
          : `<div class="ep-still empty"></div>`
      }
      <div class="ep-body">
        <div class="ep-head">
          <span class="ep-num">${ep.episode_number}</span>
          <strong>${esc(ep.name || `Episódio ${ep.episode_number}`)}</strong>
          ${ep.runtime ? `<span class="ep-runtime">${fmtRuntime(ep.runtime)}</span>` : ""}
        </div>
        <p class="ep-overview">${esc(ep.overview) || "Sem sinopse disponível."}</p>
        ${
          progress
            ? `<div class="ep-progress"><span style="width:${percent}%"></span></div>`
            : ""
        }
      </div>
      <button class="ep-play" type="button" title="Assistir">▶</button>`;

    const play = () =>
      playEpisode(show, season, ep.episode_number, ep.name || `Episódio ${ep.episode_number}`);
    row.addEventListener("click", play);
    row.addEventListener("keydown", (event) => {
      if (event.key === "Enter") play();
    });
    list.appendChild(row);
  });
}

function playEpisode(show, season, episode, episodeTitle) {
  Player.open({
    type: "tv",
    id: show.id,
    title: show.title,
    posterPath: show.posterPath,
    backdropPath: show.backdropPath,
    year: show.year,
    season,
    episode,
    episodeTitle: episodeTitle || "",
  });
}

async function renderTvDetail(media, opts = {}) {
  const detail = await Tmdb.cached(`/tv/${media.id}`);
  const show = normalizeDetail(media, detail);
  const seasons = (detail.seasons || [])
    .filter((season) => season.season_number > 0 && season.episode_count > 0)
    .sort((a, b) => a.season_number - b.season_number);

  const latest = latestProgressForShow(media.id);
  let currentSeason = Number(
    opts.season || latest?.media?.season || seasons[0]?.season_number || 1
  );

  const meta = [
    `<span class="rating">★ ${show.rating ? show.rating.toFixed(1) : "—"}</span>`,
    show.year ? `<span>${esc(show.year)}</span>` : "",
    seasons.length ? `<span>${seasons.length} temporada${seasons.length > 1 ? "s" : ""}</span>` : "",
    `<span class="type-pill">Série</span>`,
  ]
    .filter(Boolean)
    .join("");

  const genres = (detail.genres || []).map((g) => g.name).join(" · ");
  const seasonOptions = seasons
    .map(
      (season) =>
        `<option value="${season.season_number}" ${
          season.season_number === currentSeason ? "selected" : ""
        }>Temporada ${season.season_number} (${season.episode_count} eps)</option>`
    )
    .join("");

  const extra = `
    <div class="season-bar">
      <label for="seasonSelect">Temporada</label>
      <select id="seasonSelect">${seasonOptions}</select>
    </div>
    <div id="episodeList" class="episode-list"><div class="loading">Carregando episódios...</div></div>`;

  els.modalBody.innerHTML = detailHTML(show, { meta, genres }, extra);

  bindDetail(show, {
    play: () => {
      const resume = latestProgressForShow(show.id);
      if (resume) {
        playEpisode(
          show,
          resume.media.season,
          resume.media.episode,
          resume.media.episodeTitle
        );
      } else {
        playEpisode(show, currentSeason, 1, "");
      }
    },
    getTarget: () => {
      const select = document.getElementById("srcEpisode");
      const episode = select ? Number(select.value) || 1 : 1;
      return { ...show, season: currentSeason, episode };
    },
  });
  loadSimilarInto(document.getElementById("detailSimilar"), show);

  async function loadSeason(seasonNumber) {
    currentSeason = seasonNumber;
    const list = document.getElementById("episodeList");
    if (list) list.innerHTML = `<div class="loading">Carregando episódios...</div>`;

    const season = await Tmdb.cached(`/tv/${show.id}/season/${seasonNumber}`).catch(
      () => null
    );
    const episodes = (season?.episodes || []).sort(
      (a, b) => a.episode_number - b.episode_number
    );

    renderEpisodeList(show, seasonNumber, episodes);
    fillSourceEpisodes(episodes, opts.episode);
  }

  document
    .getElementById("seasonSelect")
    .addEventListener("change", (event) => loadSeason(Number(event.target.value)));

  await loadSeason(currentSeason);

  if (opts.focusSource) focusSourcePanel();
}

/* ---------------- fontes / addons ---------------- */

function syncQualityPrefsUI() {
  const prefs = getQualityPrefs();
  const sel = document.getElementById("prefQuality");
  const only = document.getElementById("prefQualityOnly");
  if (sel) sel.value = prefs.preferred || "all";
  if (only) only.checked = prefs.onlyPreferred === true;
}

function openSources() {
  els.settingsModal.classList.remove("hidden");
  els.addonError.classList.add("hidden");
  syncQualityPrefsUI();
  renderAddons();
}

function closeSources() {
  els.settingsModal.classList.add("hidden");
}

function renderAddons() {
  const addons = getAddons();
  els.addonList.innerHTML = "";

  if (!addons.length) {
    // Mesma ideia do aviso de login: quem ainda não configurou vê como fazer.
    const proxy = typeof PINGUIM_PROXY_URL === "string" ? PINGUIM_PROXY_URL.trim() : "";
    els.addonList.innerHTML = `<li class="addon-empty">Nenhum addon configurado ainda.${
      proxy
        ? ""
        : " A fonte PinguimCinema é resolvida pelo servidor da pasta proxy/ e aparece aqui quando a URL dele for preenchida em PINGUIM_PROXY_URL, no config.js."
    }</li>`;
    return;
  }

  addons.forEach((addon) => {
    const item = document.createElement("li");
    item.className = "addon-item";
    const kindLabel = addon.builtin
      ? "do config.js"
      : addon.kind === "stremio"
        ? "Stremio"
        : String(addon.url).startsWith("local:")
          ? "Arquivo"
          : "Nativo";
    const displayUrl = String(addon.url).startsWith("local:")
      ? "instalado do arquivo"
      : addon.url;
    item.innerHTML = `
      <div class="addon-info">
        <strong>${esc(addon.name)} <em class="addon-kind">${kindLabel}</em></strong>
        <span>${esc(displayUrl)}</span>
      </div>
      <label class="addon-toggle">
        <input type="checkbox" ${addon.enabled ? "checked" : ""}>
        <span>${addon.enabled ? "ativo" : "desligado"}</span>
      </label>
      ${
        // O embutido não tem ✕: ele vem do config.js, não da lista do navegador
        addon.builtin
          ? ""
          : '<button type="button" class="addon-remove" title="Remover">✕</button>'
      }`;

    item.querySelector("input").addEventListener("change", () => {
      toggleAddon(addon.url);
      renderAddons();
    });

    const removeBtn = item.querySelector(".addon-remove");
    if (removeBtn) {
      removeBtn.addEventListener("click", () => {
        removeAddon(addon.url);
        renderAddons();
        showToast("Addon removido.");
      });
    }

    els.addonList.appendChild(item);
  });
}

/* ---------------- perfis ---------------- */

let managingProfiles = false;
let editingProfileId = null;
let editorAvatar = AVATARS[0];
let editorColor = 0;

function avatarHTML(profile) {
  const color = AVATAR_COLORS[profile.color % AVATAR_COLORS.length] || AVATAR_COLORS[0];
  if (profile.photo) {
    return `<span class="avatar has-photo" style="--ac:${color}"><img src="${esc(profile.photo)}" alt=""></span>`;
  }
  return `<span class="avatar" style="--ac:${color}">${esc(profile.avatar || "👤")}</span>`;
}

function renderProfiles() {
  const profiles = getProfiles();
  const activeId = getActiveProfileId();

  els.profileGrid.innerHTML = "";
  profiles.forEach((profile) => {
    const card = document.createElement("button");
    card.type = "button";
    card.className = "profile-card";
    if (profile.id === activeId) card.classList.add("active");
    if (managingProfiles) card.classList.add("managing");
    card.innerHTML = `<span class="profile-tile${profile.cover ? " has-cover" : ""}">${avatarHTML(
      profile
    )}</span><span class="profile-name">${esc(profile.name)}</span>`;
    // background-image via JS evita ter de escapar aspas dentro do HTML
    if (profile.cover) {
      const tile = card.querySelector(".profile-tile");
      if (tile) tile.style.backgroundImage = `url("${profile.cover}")`;
    }
    // foto com link quebrado cai para o emoji do perfil
    const photoImg = card.querySelector(".avatar img");
    if (photoImg) {
      photoImg.addEventListener("error", () => {
        const holder = photoImg.parentElement;
        if (!holder) return;
        holder.classList.remove("has-photo");
        holder.textContent = profile.avatar || "👤";
      });
    }
    card.addEventListener("click", () => selectProfile(profile.id));
    els.profileGrid.appendChild(card);
  });

  const add = document.createElement("button");
  add.type = "button";
  add.className = "profile-card add";
  add.innerHTML = `<span class="profile-tile"><span class="avatar add-avatar">＋</span></span><span class="profile-name">Adicionar perfil</span>`;
  add.addEventListener("click", () => openProfileEditor(null));
  els.profileGrid.appendChild(add);

  els.profilesHint.textContent = !profiles.length
    ? "Crie seu primeiro perfil para começar."
    : managingProfiles
      ? "Escolha um perfil para editar."
      : "";

  els.manageProfiles.textContent = managingProfiles ? "Concluir" : "Gerenciar perfis";
}

function openProfilesScreen() {
  managingProfiles = false;
  editingProfileId = null;
  els.profileEditor.classList.add("hidden");
  els.profilesScreen.classList.remove("hidden");
  document.body.classList.add("profiles-open");
  renderProfiles();
}

function closeProfilesScreen() {
  els.profilesScreen.classList.add("hidden");
  document.body.classList.remove("profiles-open");
}

function updateProfileButton() {
  const profile = getActiveProfile();
  const photo = profile && profile.photo ? profile.photo : null;
  els.profileAvatar.classList.toggle("has-photo", !!photo);
  els.profileAvatar.style.backgroundImage = "";
  if (photo) {
    els.profileAvatar.innerHTML = `<img src="${esc(photo)}" alt="">`;
    const img = els.profileAvatar.querySelector("img");
    if (img) {
      // link quebrado: volta para o emoji em vez de um círculo vazio
      img.addEventListener("error", () => {
        els.profileAvatar.classList.remove("has-photo");
        els.profileAvatar.textContent = (profile && profile.avatar) || "👤";
      });
    }
  } else {
    els.profileAvatar.textContent = profile ? profile.avatar : "👤";
  }
  const color = profile
    ? AVATAR_COLORS[profile.color % AVATAR_COLORS.length]
    : "#444";
  els.profileAvatar.style.setProperty("--ac", color);
  els.profileBtn.title = profile ? `Perfil: ${profile.name}` : "Perfis";
  updatePlaylistCount();
}

function enterSite() {
  closeProfilesScreen();
  updateProfileButton();
  loadTab(STATE.tab || "home");
}

function selectProfile(id) {
  if (managingProfiles) {
    openProfileEditor(id);
    return;
  }
  setActiveProfileId(id);
  STATE.tab = "home";
  enterSite();
}

function openProfileEditor(id) {
  editingProfileId = id || null;
  const profile = editingProfileId
    ? getProfiles().find((item) => item.id === editingProfileId)
    : null;

  editorAvatar = profile ? profile.avatar : AVATARS[0];
  editorColor = profile ? profile.color : getProfiles().length % AVATAR_COLORS.length;

  els.profileEditorTitle.textContent = profile ? "Editar perfil" : "Novo perfil";
  els.profileNameInput.value = profile ? profile.name : "";
  if (els.profilePhotoInput) {
    els.profilePhotoInput.value = profile && profile.photo ? profile.photo : "";
  }
  if (els.profileCoverInput) {
    els.profileCoverInput.value = profile && profile.cover ? profile.cover : "";
  }
  els.profileDelete.classList.toggle("hidden", !profile);
  els.profileError.classList.add("hidden");
  els.profileEditor.classList.remove("hidden");
  renderAvatarOptions();
  els.profileNameInput.focus();
}

function renderAvatarOptions() {
  els.profileAvatarRow.innerHTML = "";
  AVATARS.forEach((emoji) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "avatar-option";
    button.textContent = emoji;
    if (emoji === editorAvatar) button.classList.add("selected");
    button.addEventListener("click", () => {
      editorAvatar = emoji;
      renderAvatarOptions();
    });
    els.profileAvatarRow.appendChild(button);
  });
}

function saveProfile() {
  const name = els.profileNameInput.value.trim();
  if (!name) {
    els.profileError.textContent = "Digite um nome para o perfil.";
    els.profileError.classList.remove("hidden");
    return;
  }

  const photoRaw = els.profilePhotoInput ? els.profilePhotoInput.value.trim() : "";
  const coverRaw = els.profileCoverInput ? els.profileCoverInput.value.trim() : "";
  const photo = normalizeImageUrl(photoRaw);
  const cover = normalizeImageUrl(coverRaw);

  if (photoRaw && !photo) {
    els.profileError.textContent =
      "O link da foto não é válido. Use um endereço direto da imagem, começando com https://";
    els.profileError.classList.remove("hidden");
    return;
  }
  if (coverRaw && !cover) {
    els.profileError.textContent =
      "O link da capa não é válido. Use um endereço direto da imagem, começando com https://";
    els.profileError.classList.remove("hidden");
    return;
  }

  if (editingProfileId) {
    updateProfile(editingProfileId, { name, avatar: editorAvatar, photo, cover });
    showToast("Perfil atualizado.");
  } else {
    createProfile({ name, avatar: editorAvatar, color: editorColor, photo, cover });
    showToast("Perfil criado.");
  }

  editingProfileId = null;
  els.profileEditor.classList.add("hidden");
  updateProfileButton();
  renderProfiles();
}

function removeEditingProfile() {
  const profile = getProfiles().find((item) => item.id === editingProfileId);
  if (!profile) return;
  if (
    !window.confirm(
      `Excluir o perfil "${profile.name}"? O histórico dele será apagado.`
    )
  ) {
    return;
  }

  deleteProfile(profile.id);
  editingProfileId = null;
  els.profileEditor.classList.add("hidden");
  updateProfileButton();
  renderProfiles();
  showToast("Perfil excluído.");
}

/* ---------------- eventos ---------------- */

document.querySelectorAll(".nav-link").forEach((link) => {
  link.addEventListener("click", (event) => {
    event.preventDefault();
    loadTab(link.dataset.tab);
  });
});

document.getElementById("logo").addEventListener("click", () => loadTab("home"));

els.searchBtn.addEventListener("click", () => doSearch(els.searchInput.value));
els.searchInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") doSearch(els.searchInput.value);
  if (event.key === "Escape") {
    els.searchInput.value = "";
    loadTab(STATE.tab);
  }
});

els.closeModal.addEventListener("click", () => els.modal.classList.add("hidden"));
els.modal.addEventListener("click", (event) => {
  if (
    event.target.classList.contains("modal-backdrop") ||
    event.target === els.modal
  ) {
    els.modal.classList.add("hidden");
  }
});

document.getElementById("closeSettings").addEventListener("click", closeSources);
els.settingsModal.addEventListener("click", (event) => {
  if (
    event.target.hasAttribute("data-close-settings") ||
    event.target === els.settingsModal
  ) {
    closeSources();
  }
});
document.getElementById("sourcesBtn").addEventListener("click", openSources);

if (els.heroPrev) {
  els.heroPrev.addEventListener("click", () => goHero(heroSlide.index - 1));
}
if (els.heroNext) {
  els.heroNext.addEventListener("click", () => goHero(heroSlide.index + 1));
}
els.hero.addEventListener("mouseenter", () => {
  heroSlide.paused = true;
});
els.hero.addEventListener("mouseleave", () => {
  heroSlide.paused = false;
});

/* Swipe no banner (mobile) */
(() => {
  if (!els.hero) return;
  let startX = 0;
  let startY = 0;
  let tracking = false;
  els.hero.addEventListener(
    "touchstart",
    (e) => {
      if (!e.changedTouches || !e.changedTouches[0]) return;
      tracking = true;
      startX = e.changedTouches[0].clientX;
      startY = e.changedTouches[0].clientY;
      heroSlide.paused = true;
    },
    { passive: true }
  );
  els.hero.addEventListener(
    "touchend",
    (e) => {
      if (!tracking || !e.changedTouches || !e.changedTouches[0]) return;
      tracking = false;
      const dx = e.changedTouches[0].clientX - startX;
      const dy = e.changedTouches[0].clientY - startY;
      heroSlide.paused = false;
      // horizontal dominante e gesto longo o bastante
      if (Math.abs(dx) < 48 || Math.abs(dx) < Math.abs(dy) * 1.2) return;
      if (heroSlide.items.length < 2) return;
      goHero(heroSlide.index + (dx < 0 ? 1 : -1));
    },
    { passive: true }
  );
  els.hero.addEventListener(
    "touchcancel",
    () => {
      tracking = false;
      heroSlide.paused = false;
    },
    { passive: true }
  );
})();

if (els.playlistBtn) {
  els.playlistBtn.addEventListener("click", () => loadTab("playlist"));
}

if (els.playlistAuthBtn) {
  els.playlistAuthBtn.addEventListener("click", () => {
    const configured = typeof Auth !== "undefined" && Auth.isConfigured();
    openAuthModal(configured ? "register" : "login");
  });
}

els.addonForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  els.addonError.classList.add("hidden");
  const url = (els.addonUrl.value || "").trim();
  if (!url) {
    els.addonError.textContent = "Cole a URL do manifesto ou use o botão de arquivo.";
    els.addonError.classList.remove("hidden");
    return;
  }
  const button = els.addonForm.querySelector("button");
  button.disabled = true;
  button.textContent = "Verificando...";

  try {
    await addAddon(url);
    els.addonUrl.value = "";
    renderAddons();
    showToast("Addon adicionado.");
  } catch (err) {
    els.addonError.textContent = err.message;
    els.addonError.classList.remove("hidden");
  } finally {
    button.disabled = false;
    button.textContent = "Adicionar link";
  }
});

/* Qualidade preferida (modal Fontes de vídeo) */
const prefQualitySel = document.getElementById("prefQuality");
const prefQualityOnly = document.getElementById("prefQualityOnly");
if (prefQualitySel) {
  prefQualitySel.addEventListener("change", () => {
    setQualityPrefs({ preferred: prefQualitySel.value || "all" });
    const labels = { all: "Todas", "4k": "4K", "1080": "1080p", "720": "720p", "480": "480p" };
    showToast(`Qualidade: ${labels[prefQualitySel.value] || prefQualitySel.value}`);
  });
}
if (prefQualityOnly) {
  prefQualityOnly.addEventListener("change", () => {
    setQualityPrefs({ onlyPreferred: prefQualityOnly.checked });
    showToast(
      prefQualityOnly.checked
        ? "Só a qualidade marcada será listada."
        : "Qualidade marcada tem prioridade; outras continuam disponíveis."
    );
  });
}

const addonFileInput = document.getElementById("addonFile");
if (addonFileInput) {
  addonFileInput.addEventListener("change", async () => {
    const file = addonFileInput.files && addonFileInput.files[0];
    addonFileInput.value = "";
    if (!file) return;

    els.addonError.classList.add("hidden");
    try {
      await addAddonFromFile(file);
      renderAddons();
      showToast("Addon instalado do arquivo.");
    } catch (err) {
      els.addonError.textContent = err.message;
      els.addonError.classList.remove("hidden");
    }
  });
}

document.addEventListener("player:add-source", (event) => {
  const media = event.detail.media;
  openDetail(media, {
    focusSource: true,
    season: media.season,
    episode: media.episode,
  });
});

document.addEventListener("player:open-sources", openSources);

document.addEventListener("player:closed", () => {
  if (STATE.tab === "home" && !STATE.query) refreshContinueRow();
  if (STATE.tab === "playlist") renderPlaylistPage();
});

els.profileBtn.addEventListener("click", openProfilesScreen);

els.manageProfiles.addEventListener("click", () => {
  managingProfiles = !managingProfiles;
  editingProfileId = null;
  els.profileEditor.classList.add("hidden");
  renderProfiles();
});

els.profileSave.addEventListener("click", saveProfile);
els.profileCancel.addEventListener("click", () => {
  editingProfileId = null;
  els.profileEditor.classList.add("hidden");
});
els.profileDelete.addEventListener("click", removeEditingProfile);
els.profileNameInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") saveProfile();
});

document.addEventListener("keydown", (event) => {
  if (event.key !== "Escape") return;
  if (!els.player.classList.contains("hidden")) return;

  if (!els.profilesScreen.classList.contains("hidden")) {
    if (!els.profileEditor.classList.contains("hidden")) {
      editingProfileId = null;
      els.profileEditor.classList.add("hidden");
      return;
    }
    if (getActiveProfileId()) enterSite();
    return;
  }

  els.modal.classList.add("hidden");
  closeSources();
});

/* ---------------- conta / login ---------------- */

let authMode = "login"; // login | register

const authEls = {
  modal: document.getElementById("authModal"),
  title: document.getElementById("authTitle"),
  subtitle: document.getElementById("authSubtitle"),
  form: document.getElementById("authForm"),
  email: document.getElementById("authEmail"),
  password: document.getElementById("authPassword"),
  error: document.getElementById("authError"),
  submit: document.getElementById("authSubmit"),
  switchText: document.getElementById("authSwitchText"),
  switchBtn: document.getElementById("authSwitchBtn"),
  loggedOut: document.getElementById("authLoggedOut"),
  loggedIn: document.getElementById("authLoggedIn"),
  userEmail: document.getElementById("authUserEmail"),
  setupHint: document.getElementById("authSetupHint"),
  accountBtn: document.getElementById("accountBtn"),
};

function setAuthMode(mode) {
  authMode = mode;
  const isLogin = mode === "login";
  authEls.title.textContent = isLogin ? "Entrar" : "Criar conta";
  authEls.subtitle.textContent = isLogin
    ? "Entre com e-mail e senha para salvar perfis, continuar assistindo, minha playlist e addons na nuvem."
    : "Crie uma conta para sincronizar perfis, continuar assistindo e sua playlist em qualquer dispositivo.";
  authEls.submit.textContent = isLogin ? "Entrar" : "Criar conta";
  authEls.switchText.textContent = isLogin ? "Não tem conta?" : "Já tem conta?";
  authEls.switchBtn.textContent = isLogin ? "Criar conta" : "Entrar";
  authEls.password.autocomplete = isLogin ? "current-password" : "new-password";
  authEls.error.classList.add("hidden");

  const configured = typeof Auth !== "undefined" && Auth.isConfigured();
  authEls.submit.disabled = !configured;
  if (!configured) authEls.submit.textContent = "Login não configurado";
}

function refreshAuthUI() {
  const configured = typeof Auth !== "undefined" && Auth.isConfigured();
  const user = typeof Auth !== "undefined" ? Auth.getUser() : null;

  if (authEls.setupHint) {
    authEls.setupHint.classList.toggle("hidden", configured);
  }
  if (authEls.accountBtn) {
    authEls.accountBtn.classList.toggle("logged-in", !!user);
    authEls.accountBtn.title = user ? `Conta: ${user.email}` : "Conta";
  }

  if (user) {
    authEls.loggedOut.classList.add("hidden");
    authEls.loggedIn.classList.remove("hidden");
    authEls.userEmail.textContent = user.email;
  } else {
    authEls.loggedIn.classList.add("hidden");
    authEls.loggedOut.classList.remove("hidden");
    setAuthMode(authMode);
  }

  if (!configured) {
    authEls.submit.disabled = true;
    authEls.submit.textContent = "Login não configurado";
  } else {
    authEls.submit.disabled = false;
  }
}

function openAuthModal(mode) {
  authEls.error.classList.add("hidden");
  if (mode && !Auth.isLoggedIn()) setAuthMode(mode);
  refreshAuthUI();
  authEls.modal.classList.remove("hidden");
  if (!Auth.isLoggedIn() && authEls.email) {
    setTimeout(() => authEls.email.focus(), 50);
  }
}

function closeAuthModal() {
  authEls.modal.classList.add("hidden");
}

if (authEls.accountBtn) {
  authEls.accountBtn.addEventListener("click", () => openAuthModal());
}
document.getElementById("closeAuth")?.addEventListener("click", closeAuthModal);
authEls.modal?.addEventListener("click", (event) => {
  if (event.target.hasAttribute("data-close-auth") || event.target === authEls.modal) {
    closeAuthModal();
  }
});

authEls.switchBtn?.addEventListener("click", () => {
  setAuthMode(authMode === "login" ? "register" : "login");
});

authEls.form?.addEventListener("submit", async (event) => {
  event.preventDefault();
  authEls.error.classList.add("hidden");
  if (!Auth.isConfigured()) {
    authEls.error.textContent =
      "Configure FIREBASE_CONFIG no config.js para ativar o login na nuvem.";
    authEls.error.classList.remove("hidden");
    return;
  }
  authEls.submit.disabled = true;
  const prev = authEls.submit.textContent;
  authEls.submit.textContent = "Aguarde...";
  try {
    if (authMode === "register") {
      await Auth.register(authEls.email.value, authEls.password.value);
      showToast("Conta criada.");
    } else {
      await Auth.login(authEls.email.value, authEls.password.value);
      showToast("Login feito.");
    }
    authEls.password.value = "";
    refreshAuthUI();
    updateProfileButton();
    if (getActiveProfileId()) {
      closeProfilesScreen();
      loadTab(STATE.tab || "home");
    } else {
      openProfilesScreen();
    }
  } catch (err) {
    authEls.error.textContent = err.message || "Falha na autenticação.";
    authEls.error.classList.remove("hidden");
  } finally {
    authEls.submit.disabled = false;
    authEls.submit.textContent = prev;
  }
});

document.getElementById("authLogout")?.addEventListener("click", async () => {
  try {
    await Auth.logout();
    showToast("Você saiu da conta. Os dados locais deste navegador permanecem.");
    refreshAuthUI();
  } catch (err) {
    showToast(err.message || "Não foi possível sair.");
  }
});

document.getElementById("authSyncNow")?.addEventListener("click", async (event) => {
  const btn = event.currentTarget;
  const prev = btn.textContent;
  btn.disabled = true;
  btn.textContent = "Enviando...";
  try {
    // Só confirma depois que o documento foi realmente gravado no Firestore
    const ok = await Auth.pushToCloud(true);
    if (ok) {
      showToast("Dados enviados para a nuvem.");
    } else {
      showToast("Aguarde um instante e toque em Sincronizar de novo.", 4000);
    }
  } catch (err) {
    showToast(err.message || "Falha ao sincronizar.", 6000);
  } finally {
    btn.disabled = false;
    btn.textContent = prev;
  }
});

document.addEventListener("auth:changed", () => {
  refreshAuthUI();
  updatePlaylistCount();
  if (STATE.tab === "playlist") renderPlaylistPage();
});

document.addEventListener("auth:data-restored", () => {
  updateProfileButton();
  updatePlaylistCount();
  if (getActiveProfileId()) {
    loadTab(STATE.tab || "home");
  } else {
    openProfilesScreen();
  }
  showToast("Dados da conta restaurados.");
});

/* ---------------- configurações ---------------- */

const prefEls = {
  modal: document.getElementById("prefsModal"),
  btn: document.getElementById("prefsBtn"),
  close: document.getElementById("closePrefs"),
  trailer: document.getElementById("prefTrailer"),
  sound: document.getElementById("prefSound"),
  torrent: document.getElementById("prefTorrent"),
};

function renderPrefs() {
  const prefs = getTrailerPrefs();
  if (prefEls.trailer) prefEls.trailer.checked = prefs.enabled;
  if (prefEls.sound) prefEls.sound.checked = prefs.sound;
  if (prefEls.torrent) prefEls.torrent.checked = getTorrentPrefs().enabled;
}

function openPrefs() {
  renderPrefs();
  prefEls.modal.classList.remove("hidden");
}

function closePrefs() {
  prefEls.modal.classList.add("hidden");
}

prefEls.btn?.addEventListener("click", openPrefs);
prefEls.close?.addEventListener("click", closePrefs);
prefEls.modal?.addEventListener("click", (event) => {
  if (event.target.hasAttribute("data-close-prefs") || event.target === prefEls.modal) {
    closePrefs();
  }
});

prefEls.trailer?.addEventListener("change", () => {
  setTrailerPrefs({ enabled: prefEls.trailer.checked });
  if (!prefEls.trailer.checked) {
    document.querySelectorAll(".card-preview").forEach((preview) => preview.remove());
  }
});

prefEls.sound?.addEventListener("change", () => {
  setTrailerPrefs({ sound: prefEls.sound.checked });
});

prefEls.torrent?.addEventListener("change", () => {
  setTorrentPrefs({ enabled: prefEls.torrent.checked });
  showToast(
    prefEls.torrent.checked
      ? "Torrents ligados. Fontes P2P entram no menu de fontes."
      : "Torrents desligados. O player vai usar apenas links diretos."
  );
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && prefEls.modal && !prefEls.modal.classList.contains("hidden")) {
    closePrefs();
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key !== "Escape") return;
  if (els.detailPage && !els.detailPage.classList.contains("hidden")) {
    closeDetailPage();
  }
});

/* ---------------- início ---------------- */

if (typeof Auth !== "undefined") {
  Auth.init();
}
setAuthMode("login");
refreshAuthUI();
updateProfileButton();
updatePlaylistCount();
openProfilesScreen();
