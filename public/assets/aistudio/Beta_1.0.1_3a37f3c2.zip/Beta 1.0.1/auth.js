/* ============================================================
   auth.js — Conta (e-mail/senha) + sincronização na nuvem
   Usa Firebase Auth + Firestore (opcional, via config.js)
   ============================================================ */

const Auth = (() => {
  let app = null;
  let auth = null;
  let db = null;
  let currentUser = null;
  let syncTimer = null;
  let applyingRemote = false;
  let readyResolve;
  const ready = new Promise((r) => {
    readyResolve = r;
  });

  /* O SDK do Firestore, quando a API está desligada ou sem rede, NÃO falha:
     ele fica tentando de novo em silêncio por minutos. Sem este limite a
     tela ficava travada em "Enviando..." para sempre. */
  const CLOUD_TIMEOUT = 10000;
  function withTimeout(promise, ms = CLOUD_TIMEOUT) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        const err = new Error(
          "O Firestore não respondeu em 10 segundos (banco não criado, API desativada ou sem internet)."
        );
        err.code = "deadline-exceeded";
        reject(err);
      }, ms);
      promise.then(
        (value) => {
          clearTimeout(timer);
          resolve(value);
        },
        (err) => {
          clearTimeout(timer);
          reject(err);
        }
      );
    });
  }

  function isConfigured() {
    return !!(
      typeof FIREBASE_CONFIG === "object" &&
      FIREBASE_CONFIG &&
      FIREBASE_CONFIG.apiKey &&
      FIREBASE_CONFIG.projectId
    );
  }

  function init() {
    if (!isConfigured()) {
      readyResolve(false);
      return false;
    }
    if (typeof firebase === "undefined") {
      console.warn("[auth] Firebase SDK não carregou.");
      readyResolve(false);
      return false;
    }
    try {
      app = firebase.apps.length ? firebase.app() : firebase.initializeApp(FIREBASE_CONFIG);
      auth = firebase.auth();
      db = firebase.firestore();
      auth.onAuthStateChanged(async (user) => {
        currentUser = user;
        document.dispatchEvent(
          new CustomEvent("auth:changed", { detail: { user: serializeUser(user) } })
        );
        if (user) {
          try {
            await pullFromCloud();
          } catch (err) {
            console.warn("[auth] pull:", err.message);
            notifyCloudError(err);
          }
        }
      });
      readyResolve(true);
      return true;
    } catch (err) {
      console.warn("[auth] init:", err.message);
      readyResolve(false);
      return false;
    }
  }

  function serializeUser(user) {
    if (!user) return null;
    return {
      uid: user.uid,
      email: user.email || "",
      displayName: user.displayName || "",
    };
  }

  function getUser() {
    return serializeUser(currentUser || (auth && auth.currentUser));
  }

  function isLoggedIn() {
    return !!(currentUser || (auth && auth.currentUser));
  }

  function mapAuthError(err) {
    const code = (err && err.code) || "";
    const map = {
      "auth/email-already-in-use": "Este e-mail já está em uso.",
      "auth/invalid-email": "E-mail inválido.",
      "auth/weak-password": "A senha deve ter pelo menos 6 caracteres.",
      "auth/user-not-found": "Conta não encontrada.",
      "auth/wrong-password": "Senha incorreta.",
      "auth/invalid-credential": "E-mail ou senha incorretos.",
      "auth/too-many-requests": "Muitas tentativas. Aguarde um pouco.",
      "auth/operation-not-allowed": "Login por e-mail não está habilitado no Firebase.",
      "auth/configuration-not-found":
        "O Authentication ainda não foi ativado neste projeto. No Firebase, abra Authentication → Começar (Get started) e ative E-mail/senha. Veja MANUAL-NUVEM.txt, Parte 2.",
      "auth/unauthorized-domain":
        "Este domínio não está autorizado no Firebase. Em Authentication → Settings → Authorized domains, adicione o domínio do site.",
      "auth/invalid-api-key": "A apiKey do FIREBASE_CONFIG está incorreta (confira em config.js).",
      "auth/api-key-not-valid.-please-pass-a-valid-api-key.":
        "A apiKey do FIREBASE_CONFIG está incorreta (confira em config.js).",
      "auth/network-request-failed": "Falha de rede. Se o site estiver em http (sem https), o login é bloqueado pelo navegador.",
    };
    return map[code] || (err && err.message) || "Não foi possível autenticar.";
  }

  /* Traduz os erros do Firestore para algo acionável na tela. */
  function cloudErrorMessage(err) {
    const code = String((err && err.code) || "");
    const text = String((err && err.message) || "");
    if (code === "permission-denied") {
      return "O Firestore recusou o acesso: publique as regras (users/{uid}) do MANUAL-NUVEM.txt, Parte 5.";
    }
    if (
      code === "failed-precondition" ||
      code === "not-found" ||
      /firestore.*(not been used|disabled|not enabled|does not exist)|database.*not.*found/i.test(
        text
      )
    ) {
      return "O banco Firestore ainda não foi criado (ou a API está desativada). Faça a Parte 4 do MANUAL-NUVEM.txt.";
    }
    if (code === "deadline-exceeded") {
      return "O Firestore não respondeu em 10 segundos. Confira se o banco foi criado (Parte 4 do MANUAL-NUVEM.txt) e se há internet — o SDK fica tentando em silêncio quando a API está desligada.";
    }
    if (code === "unavailable") {
      return "Sem conexão com o Firestore agora. Tente de novo em instantes.";
    }
    if (code === "unauthenticated") {
      return "Sua sessão expirou. Saia da conta e entre de novo.";
    }
    return text || "Não foi possível sincronizar.";
  }

  /* Avisa na tela (uma vez) quando a nuvem falha por falta de configuração:
     sem isso o erro só aparecia no console. */
  let setupNoticeShown = false;
  function notifyCloudError(err) {
    const code = String((err && err.code) || "");
    const text = String((err && err.message) || "");
    const setupProblem =
      code === "permission-denied" ||
      code === "failed-precondition" ||
      code === "not-found" ||
      code === "deadline-exceeded" ||
      /firestore.*(not been used|disabled|not enabled|does not exist)|database.*not.*found/i.test(
        text
      );
    if (!setupProblem || setupNoticeShown) return;
    setupNoticeShown = true;
    document.dispatchEvent(
      new CustomEvent("app:toast", { detail: { message: cloudErrorMessage(err) } })
    );
    console.warn("[auth] nuvem:", code || text);
  }

  async function register(email, password) {
    if (!auth) throw new Error("Conta na nuvem não configurada. Veja o LEIA-ME (Firebase).");
    const cleanEmail = String(email || "").trim();
    const cleanPass = String(password || "");
    if (!cleanEmail || !cleanPass) throw new Error("Preencha e-mail e senha.");
    if (cleanPass.length < 6) throw new Error("A senha deve ter pelo menos 6 caracteres.");
    let cred;
    try {
      cred = await auth.createUserWithEmailAndPassword(cleanEmail, cleanPass);
    } catch (err) {
      throw new Error(mapAuthError(err));
    }
    // A conta já foi criada: uma falha do Firestore não deve parecer
    // "não consegui criar a conta". Só avisa que a sincronização falhou.
    currentUser = cred.user;
    try {
      await pushToCloud(true);
    } catch (err) {
      console.warn("[auth] envio inicial:", err.message);
      notifyCloudError(err);
    }
    return serializeUser(cred.user);
  }

  async function login(email, password) {
    if (!auth) throw new Error("Conta na nuvem não configurada. Veja o LEIA-ME (Firebase).");
    const cleanEmail = String(email || "").trim();
    const cleanPass = String(password || "");
    if (!cleanEmail || !cleanPass) throw new Error("Preencha e-mail e senha.");
    let cred;
    try {
      cred = await auth.signInWithEmailAndPassword(cleanEmail, cleanPass);
    } catch (err) {
      throw new Error(mapAuthError(err));
    }
    currentUser = cred.user;
    try {
      await pullFromCloud();
    } catch (err) {
      console.warn("[auth] download:", err.message);
      notifyCloudError(err);
    }
    return serializeUser(cred.user);
  }

  async function logout() {
    if (!auth) return;
    await auth.signOut();
    currentUser = null;
  }

  function collectLocalSnapshot() {
    const profiles = typeof getProfiles === "function" ? getProfiles() : [];
    const activeProfileId =
      typeof getActiveProfileId === "function" ? getActiveProfileId() : null;
    const addons = typeof getAddons === "function" ? getAddons() : [];

    const progressByProfile = {};
    const playlistByProfile = {};
    profiles.forEach((p) => {
      if (!p || !p.id) return;
      try {
        const raw = localStorage.getItem(`mf:progress:${p.id}`);
        progressByProfile[p.id] = raw ? JSON.parse(raw) : [];
      } catch {
        progressByProfile[p.id] = [];
      }
      try {
        const raw = localStorage.getItem(`mf:playlist:${p.id}`);
        playlistByProfile[p.id] = raw ? JSON.parse(raw) : [];
      } catch {
        playlistByProfile[p.id] = [];
      }
    });

    // fontes manuais (mf:src:*)
    const manualSources = {};
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith("mf:src:")) {
          try {
            manualSources[k] = JSON.parse(localStorage.getItem(k) || "[]");
          } catch {
            /* ignore */
          }
        }
      }
    } catch {
      /* ignore */
    }

    // manifestos locais de addons
    const localManifests = {};
    addons.forEach((a) => {
      if (a && String(a.url).startsWith("local:")) {
        const mk = `mf:local-manifest:${a.url}`;
        try {
          const raw = localStorage.getItem(mk);
          if (raw) localManifests[a.url] = JSON.parse(raw);
        } catch {
          /* ignore */
        }
      }
    });

    return {
      profiles,
      activeProfileId,
      addons,
      progressByProfile,
      playlistByProfile,
      manualSources,
      localManifests,
      updatedAt: Date.now(),
    };
  }

  /* Junta o que está na nuvem com o que está NESTE aparelho. Nada é
     descartado: perfil que só existe aqui continua aqui, título que só
     existe na nuvem desce, e em conflito vence o mais recente. Antes o
     download substituía tudo, então uma nuvem vazia apagava os perfis. */
  function mergeSnapshots(remote, local) {
    const r = remote && typeof remote === "object" ? remote : {};
    const l = local && typeof local === "object" ? local : {};

    const profiles = [];
    const seenProfiles = new Set();
    const remoteProfiles = Array.isArray(r.profiles) ? r.profiles : [];
    const localProfiles = Array.isArray(l.profiles) ? l.profiles : [];

    localProfiles.forEach((p) => {
      if (!p || !p.id || seenProfiles.has(p.id)) return;
      seenProfiles.add(p.id);
      const cloud = remoteProfiles.find((x) => x && x.id === p.id);
      profiles.push(cloud ? { ...p, ...cloud } : p);
    });
    remoteProfiles.forEach((p) => {
      if (!p || !p.id || seenProfiles.has(p.id)) return;
      seenProfiles.add(p.id);
      profiles.push(p);
    });

    const profileIds = new Set([
      ...Object.keys(l.progressByProfile || {}),
      ...Object.keys(r.progressByProfile || {}),
      ...Object.keys(l.playlistByProfile || {}),
      ...Object.keys(r.playlistByProfile || {}),
    ]);

    const progressByProfile = {};
    profileIds.forEach((pid) => {
      const map = new Map();
      [...(l.progressByProfile?.[pid] || []), ...(r.progressByProfile?.[pid] || [])].forEach(
        (item) => {
          if (!item || !item.key) return;
          const prev = map.get(item.key);
          if (!prev || (item.updatedAt || 0) >= (prev.updatedAt || 0)) map.set(item.key, item);
        }
      );
      progressByProfile[pid] = [...map.values()]
        .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0))
        .slice(0, 40);
    });

    const playlistByProfile = {};
    profileIds.forEach((pid) => {
      const map = new Map();
      [...(l.playlistByProfile?.[pid] || []), ...(r.playlistByProfile?.[pid] || [])].forEach(
        (entry) => {
          if (!entry || !entry.key) return;
          const prev = map.get(entry.key);
          if (!prev || (entry.addedAt || 0) >= (prev.addedAt || 0)) map.set(entry.key, entry);
        }
      );
      playlistByProfile[pid] = [...map.values()]
        .sort((a, b) => (b.addedAt || 0) - (a.addedAt || 0))
        .slice(0, 200);
    });

    const addons = [];
    const seenAddons = new Set();
    [...(l.addons || []), ...(r.addons || [])].forEach((a) => {
      if (!a || !a.url || seenAddons.has(a.url)) return;
      seenAddons.add(a.url);
      addons.push(a);
    });

    const activeProfileId =
      profiles.find((p) => p.id === l.activeProfileId)?.id ||
      profiles.find((p) => p.id === r.activeProfileId)?.id ||
      (profiles[0] ? profiles[0].id : null);

    return {
      profiles,
      activeProfileId,
      addons,
      progressByProfile,
      playlistByProfile,
      manualSources: { ...(r.manualSources || {}), ...(l.manualSources || {}) },
      localManifests: { ...(r.localManifests || {}), ...(l.localManifests || {}) },
      updatedAt: Date.now(),
    };
  }

  function applyLocalSnapshot(data) {
    if (!data || typeof data !== "object") return;
    applyingRemote = true;
    try {
      // nunca troca uma lista de perfis existente por uma vazia
      if (Array.isArray(data.profiles) && (data.profiles.length || !getProfiles().length)) {
        writeJSON("mf:profiles", data.profiles);
      }
      if (data.activeProfileId) {
        writeRaw("mf:active-profile", data.activeProfileId);
      } else {
        removeRaw("mf:active-profile");
      }
      if (Array.isArray(data.addons)) {
        writeJSON("mf:addons", data.addons);
      }
      if (data.progressByProfile && typeof data.progressByProfile === "object") {
        Object.keys(data.progressByProfile).forEach((pid) => {
          writeJSON(`mf:progress:${pid}`, data.progressByProfile[pid] || []);
        });
      }
      if (data.playlistByProfile && typeof data.playlistByProfile === "object") {
        Object.keys(data.playlistByProfile).forEach((pid) => {
          writeJSON(`mf:playlist:${pid}`, data.playlistByProfile[pid] || []);
        });
      }
      if (data.manualSources && typeof data.manualSources === "object") {
        Object.keys(data.manualSources).forEach((k) => {
          writeJSON(k, data.manualSources[k]);
        });
      }
      if (data.localManifests && typeof data.localManifests === "object") {
        Object.keys(data.localManifests).forEach((id) => {
          writeJSON(`mf:local-manifest:${id}`, data.localManifests[id]);
        });
      }
    } finally {
      applyingRemote = false;
    }
    document.dispatchEvent(new CustomEvent("auth:data-restored"));
  }

  /* Devolve true só quando o documento foi realmente gravado. Antes esta
     função saía em silêncio sem gravar nada, e o botão "Sincronizar agora"
     anunciava sucesso mesmo quando o Firestore nem existia. */
  async function pushToCloud(force) {
    if (applyingRemote) return false;
    if (!isConfigured()) {
      throw new Error("Login na nuvem não configurado: preencha FIREBASE_CONFIG no config.js.");
    }
    if (!isLoggedIn() || !auth || !auth.currentUser) {
      throw new Error("Entre na sua conta para sincronizar.");
    }
    if (!db) {
      throw new Error(
        "O Firestore não foi inicializado. Confira a Parte 4 do MANUAL-NUVEM.txt (criar o banco)."
      );
    }
    const user = auth.currentUser;
    const snap = collectLocalSnapshot();
    try {
      await withTimeout(
        db.collection("users").doc(user.uid).set(
          {
            email: user.email || "",
            data: snap,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
          },
          { merge: true }
        )
      );
    } catch (err) {
      const friendly = new Error(cloudErrorMessage(err));
      friendly.code = err && err.code;
      throw friendly;
    }
    return true;
  }

  async function pullFromCloud() {
    if (!db || !isLoggedIn()) return null;
    const user = auth.currentUser;
    if (!user) return null;

    const doc = await withTimeout(db.collection("users").doc(user.uid).get());
    const local = collectLocalSnapshot();
    const payload = doc.exists ? doc.data() : null;
    const remote =
      payload && payload.data && typeof payload.data === "object" ? payload.data : null;

    // Nuvem vazia (ou primeira vez): sobe o que existe aqui. Nunca apaga.
    if (!remote) {
      await pushToCloud(true);
      return "sent";
    }

    const merged = mergeSnapshots(remote, local);
    applyLocalSnapshot(merged);

    // Devolve para a nuvem o que só existia neste aparelho.
    const remoteIds = new Set((remote.profiles || []).map((p) => p && p.id));
    const localOnly = (local.profiles || []).some((p) => p && p.id && !remoteIds.has(p.id));
    const newest = (map) =>
      Math.max(
        0,
        ...Object.values(map || {})
          .flat()
          .map((item) => (item && item.updatedAt) || 0)
      );
    const localIsNewer =
      newest(local.progressByProfile) > newest(remote.progressByProfile);

    if (localOnly || localIsNewer) {
      try {
        await pushToCloud(true);
      } catch (err) {
        console.warn("[auth] envio após combinar:", err.message);
      }
    }
    return "merged";
  }

  function scheduleCloudSync() {
    if (!isLoggedIn() || applyingRemote) return;
    clearTimeout(syncTimer);
    syncTimer = setTimeout(() => {
      pushToCloud(false).catch((err) => {
        console.warn("[auth] sync:", err.message);
        notifyCloudError(err);
      });
    }, 1200);
  }

  return {
    init,
    ready,
    isConfigured,
    isLoggedIn,
    getUser,
    register,
    login,
    logout,
    scheduleCloudSync,
    pushToCloud,
    pullFromCloud,
  };
})();

// Hook global para api.js / script.js
function scheduleCloudSync() {
  if (typeof Auth !== "undefined" && Auth.scheduleCloudSync) {
    Auth.scheduleCloudSync();
  }
}
