/**
 * Netfilmes — proxy HTTP + gateway torrent (Node 18+)
 *
 * Rotas:
 *   GET /health
 *   GET /proxy?url=<URL>[&h=<headers base64url>][&key=]
 *   GET /torrent?magnet=<magnet>[&file=0][&key=]
 *   GET /torrent?ih=<infoHash>[&file=0][&key=]
 *   GET /pinguim/manifest.json                          fonte PinguimCinema
 *   GET /pinguim?type=movie&id=550&season=&episode=     { streams: [...] }
 *
 * A fonte PinguimCinema (proxy/pinguim.js) resolve no servidor e o site toca o
 * HLS no player dele. Env dela: PINGUIMCINEMA_* (veja proxy/README.txt).
 *
 * Torrent: o servidor baixa com WebTorrent (UDP/TCP) e entrega o arquivo
 * de vídeo por HTTP com Range — o navegador só vê um stream normal.
 *
 * Env:
 *   PORT, PROXY_SECRET, ALLOW_ORIGIN, MAX_REDIRECTS, FETCH_TIMEOUT_MS
 *   TORRENT_ENABLED=1|0   (padrão: 1 se webtorrent estiver instalado)
 *   TORRENT_IDLE_MS       (padrão 10 min sem uso → remove torrent)
 *   TORRENT_MAX           (padrão 4 torrents simultâneos)
 */

"use strict";

const http = require("http");
const https = require("https");

// A fonte PinguimCinema é um módulo separado e OPCIONAL: se ele não carregar
// (erro de edição, arquivo ausente), /proxy, /torrent e /library continuam de
// pé e só /pinguim avisa.
let Pinguim = null;
try {
  Pinguim = require("./pinguim");
} catch (err) {
  console.warn(`[netfilmes-proxy] fonte pinguim indisponível: ${(err && err.message) || err}`);
}
const { URL } = require("url");
const path = require("path");
const os = require("os");
const fs = require("fs");

const PORT = Number(process.env.PORT) || 8787;
const PROXY_SECRET = process.env.PROXY_SECRET || "";
const ALLOW_ORIGIN = process.env.ALLOW_ORIGIN || "*";
const MAX_REDIRECTS = Number(process.env.MAX_REDIRECTS) || 5;
const FETCH_TIMEOUT_MS = Number(process.env.FETCH_TIMEOUT_MS) || 45000;
const TORRENT_IDLE_MS = Number(process.env.TORRENT_IDLE_MS) || 10 * 60 * 1000;
const TORRENT_MAX = Number(process.env.TORRENT_MAX) || 4;

let WebTorrent = null; // construtor, preenchido no primeiro uso
let WebTorrentPromise = null;
let torrentClient = null;

// webtorrent 2.x é ESM puro ("type": "module" no pacote): require() estoura
// ERR_REQUIRE_ESM e, como o erro era engolido, o gateway ficava desligado sem
// avisar. Aqui o pacote é carregado por import() dinâmico, uma vez só, e o
// servidor sobe mesmo sem ele (só a rota /torrent responde 503).
function loadWebTorrent() {
  if (WebTorrent) return Promise.resolve(WebTorrent);
  if (!WebTorrentPromise) {
    WebTorrentPromise = import("webtorrent")
      .then((mod) => {
        const Ctor = mod && (mod.default || mod.WebTorrent || mod);
        if (typeof Ctor !== "function") {
          throw new Error("export inesperado do pacote webtorrent");
        }
        WebTorrent = Ctor;
        return Ctor;
      })
      .catch((err) => {
        WebTorrentPromise = null;
        throw err;
      });
  }
  return WebTorrentPromise;
}

const TORRENT_ENABLED = process.env.TORRENT_ENABLED !== "0";

const HOP_BY_HOP = new Set([
  "connection",
  "keep-alive",
  "proxy-authenticate",
  "proxy-authorization",
  "te",
  "trailers",
  "transfer-encoding",
  "upgrade",
  "host",
  "content-length",
]);

const VIDEO_RE = /\.(mp4|m4v|webm|mkv|mov|avi|ogv)$/i;
const activeTorrents = new Map(); // key → { torrent, lastUsed, ready }

function sendJson(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(data),
    ...corsHeaders(),
  });
  res.end(data);
}

function corsHeaders(extra = {}) {
  return {
    "Access-Control-Allow-Origin": ALLOW_ORIGIN,
    "Access-Control-Allow-Methods": "GET,HEAD,OPTIONS",
    "Access-Control-Allow-Headers": "Range, Content-Type",
    "Access-Control-Expose-Headers":
      "Content-Length, Content-Range, Accept-Ranges, Content-Type",
    ...extra,
  };
}

function checkAuth(query) {
  if (!PROXY_SECRET) return true;
  return (query.get("key") || "") === PROXY_SECRET;
}

function decodeHeadersParam(raw) {
  if (!raw) return {};
  try {
    let b64 = String(raw).replace(/-/g, "+").replace(/_/g, "/");
    while (b64.length % 4) b64 += "=";
    const json = Buffer.from(b64, "base64").toString("utf8");
    const obj = JSON.parse(json);
    if (!obj || typeof obj !== "object") return {};
    const out = {};
    for (const [k, v] of Object.entries(obj)) {
      if (v == null) continue;
      const key = String(k).trim();
      if (!key || HOP_BY_HOP.has(key.toLowerCase())) continue;
      out[key] = String(v);
    }
    return out;
  } catch {
    return {};
  }
}

function isAllowedTarget(url) {
  if (!url || (url.protocol !== "http:" && url.protocol !== "https:")) return false;
  const host = (url.hostname || "").toLowerCase();
  if (!host || host === "localhost" || host === "127.0.0.1" || host === "::1") return false;
  if (/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[0-1])\.|169\.254\.)/.test(host)) return false;
  if (host.endsWith(".local") || host.endsWith(".internal")) return false;
  return true;
}

function fetchUpstream(targetUrl, reqHeaders, redirectsLeft) {
  return new Promise((resolve, reject) => {
    const lib = targetUrl.protocol === "https:" ? https : http;
    const opts = {
      protocol: targetUrl.protocol,
      hostname: targetUrl.hostname,
      port: targetUrl.port || (targetUrl.protocol === "https:" ? 443 : 80),
      path: targetUrl.pathname + targetUrl.search,
      method: "GET",
      headers: reqHeaders,
      timeout: FETCH_TIMEOUT_MS,
      rejectUnauthorized: true,
    };

    const upstream = lib.request(opts, (ures) => {
      const status = ures.statusCode || 0;
      if ([301, 302, 303, 307, 308].includes(status) && ures.headers.location && redirectsLeft > 0) {
        ures.resume();
        try {
          const next = new URL(ures.headers.location, targetUrl);
          if (!isAllowedTarget(next)) {
            reject(new Error("Redirecionamento bloqueado"));
            return;
          }
          resolve(fetchUpstream(next, reqHeaders, redirectsLeft - 1));
        } catch (err) {
          reject(err);
        }
        return;
      }
      resolve({ res: ures, finalUrl: targetUrl });
    });

    upstream.on("timeout", () => {
      upstream.destroy();
      reject(new Error("Timeout ao buscar a fonte"));
    });
    upstream.on("error", reject);
    upstream.end();
  });
}

async function handleProxy(req, res, query) {
  if (!checkAuth(query)) {
    sendJson(res, 401, { error: "Chave inválida. Passe ?key= no STREAM_PROXY." });
    return;
  }

  const rawUrl = query.get("url") || query.get("u") || "";
  if (!rawUrl) {
    sendJson(res, 400, { error: "Falta ?url= com o endereço do stream." });
    return;
  }

  let target;
  try {
    target = new URL(rawUrl);
  } catch {
    sendJson(res, 400, { error: "URL inválida." });
    return;
  }

  if (!isAllowedTarget(target)) {
    sendJson(res, 403, { error: "Destino não permitido." });
    return;
  }

  const extraHeaders = decodeHeadersParam(query.get("h") || query.get("headers") || "");
  const forward = {
    "User-Agent":
      extraHeaders["User-Agent"] ||
      extraHeaders["user-agent"] ||
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    Accept: "*/*",
    "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
  };

  if (req.headers.range) forward.Range = req.headers.range;

  for (const [k, v] of Object.entries(extraHeaders)) {
    if (/^user-agent$/i.test(k)) continue;
    forward[k] = v;
  }

  if (!forward.Referer && !forward.referer) {
    forward.Referer = `${target.protocol}//${target.host}/`;
  }

  let upstream;
  try {
    upstream = await fetchUpstream(target, forward, MAX_REDIRECTS);
  } catch (err) {
    sendJson(res, 502, { error: "Falha ao buscar a fonte", detail: String(err.message || err) });
    return;
  }

  const { res: ures } = upstream;
  const status = ures.statusCode || 502;
  const outHeaders = corsHeaders({ "Cache-Control": "no-store" });
  const pass = ["content-type", "content-length", "content-range", "accept-ranges", "content-disposition"];
  for (const name of pass) {
    if (ures.headers[name]) outHeaders[name] = ures.headers[name];
  }
  if (!outHeaders["accept-ranges"]) outHeaders["Accept-Ranges"] = "bytes";

  res.writeHead(status, outHeaders);
  if (req.method === "HEAD") {
    ures.resume();
    res.end();
    return;
  }
  ures.pipe(res);
  ures.on("error", () => {
    try {
      res.end();
    } catch {
      /* noop */
    }
  });
  req.on("close", () => {
    try {
      ures.destroy();
    } catch {
      /* noop */
    }
  });
}

/* ---------------- torrent gateway ---------------- */

/** Pasta onde os pedaços vão para o DISCO (sem ela o WebTorrent usa RAM). */
function downloadDir() {
  const dir = process.env.TORRENT_PATH || path.join(os.tmpdir(), "netfilmes-torrents");
  try {
    fs.mkdirSync(dir, { recursive: true });
  } catch {
    /* noop */
  }
  return dir;
}

function getClient() {
  if (!WebTorrent) throw new Error("Pacote webtorrent não instalado (npm install na pasta proxy)");
  if (!torrentClient || torrentClient.destroyed) {
    torrentClient = new WebTorrent({
      // disco, não memória: um filme não pode morar na RAM do servidor
      path: downloadDir(),
    });
  }
  return torrentClient;
}

function extractInfoHash(magnetOrHash) {
  const s = String(magnetOrHash || "").trim();
  if (/^[a-f0-9]{40}$/i.test(s)) return s.toLowerCase();
  if (/^[a-f0-9]{64}$/i.test(s)) return s.toLowerCase().slice(0, 40);
  try {
    const u = new URL(s);
    const xt = u.searchParams.get("xt") || "";
    const m = xt.match(/btih:([a-f0-9]{40}|[a-z2-7]{32})/i);
    if (m) {
      if (/^[a-f0-9]{40}$/i.test(m[1])) return m[1].toLowerCase();
      // base32 — devolve como veio; WebTorrent aceita no magnet
      return m[1].toUpperCase();
    }
  } catch {
    /* noop */
  }
  return s.slice(0, 64);
}

function pickVideoFile(torrent, fileIdx) {
  const files = torrent.files || [];
  if (!files.length) return null;
  if (Number.isInteger(fileIdx) && fileIdx >= 0 && fileIdx < files.length) {
    return files[fileIdx];
  }
  const videos = files.filter(
    (f) => /^video\//i.test(f.type || "") || VIDEO_RE.test(f.name || "")
  );
  const list = videos.length ? videos : files;
  return list.slice().sort((a, b) => b.length - a.length)[0];
}

function touchTorrent(key) {
  const entry = activeTorrents.get(key);
  if (entry) entry.lastUsed = Date.now();
}

function pruneTorrents() {
  const now = Date.now();
  for (const [key, entry] of activeTorrents) {
    if (now - entry.lastUsed > TORRENT_IDLE_MS) {
      try {
        entry.torrent.destroy();
      } catch {
        /* noop */
      }
      activeTorrents.delete(key);
    }
  }
  // Limite de simultâneos: remove o mais antigo
  while (activeTorrents.size > TORRENT_MAX) {
    let oldestKey = null;
    let oldest = Infinity;
    for (const [key, entry] of activeTorrents) {
      if (entry.lastUsed < oldest) {
        oldest = entry.lastUsed;
        oldestKey = key;
      }
    }
    if (!oldestKey) break;
    const entry = activeTorrents.get(oldestKey);
    try {
      entry.torrent.destroy();
    } catch {
      /* noop */
    }
    activeTorrents.delete(oldestKey);
  }
}

async function loadTorrent(magnet) {
  await loadWebTorrent();
  const key = extractInfoHash(magnet);
  pruneTorrents();

  const existing = activeTorrents.get(key);
  if (existing) {
    touchTorrent(key);
    if (existing.ready) return Promise.resolve(existing.torrent);
    return existing.promise;
  }

  if (activeTorrents.size >= TORRENT_MAX) pruneTorrents();

  const client = getClient();
  const entry = {
    torrent: null,
    lastUsed: Date.now(),
    ready: false,
    promise: null,
  };

  entry.promise = new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      activeTorrents.delete(key);
      reject(new Error("Timeout: metadados do torrent não chegaram em 60s"));
    }, 60000);

    let t;
    try {
      t = client.add(magnet, {
        path: downloadDir(),
        destroyStoreOnDestroy: true,
      });
    } catch (err) {
      clearTimeout(timer);
      activeTorrents.delete(key);
      reject(err);
      return;
    }

    entry.torrent = t;
    t.on("error", (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      activeTorrents.delete(key);
      reject(err);
    });
    t.on("ready", () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      entry.ready = true;
      entry.lastUsed = Date.now();
      resolve(t);
    });
  });

  activeTorrents.set(key, entry);
  return entry.promise;
}

function parseRange(header, size) {
  if (!header || !size) return null;
  const m = String(header).match(/bytes=(\d*)-(\d*)/);
  if (!m) return null;
  let start = m[1] === "" ? null : parseInt(m[1], 10);
  let end = m[2] === "" ? null : parseInt(m[2], 10);
  if (start == null && end == null) return null;
  if (start == null) {
    start = Math.max(0, size - end);
    end = size - 1;
  } else if (end == null) {
    end = size - 1;
  }
  if (start < 0 || end >= size || start > end) return null;
  return { start, end };
}

/** Nome para Content-Disposition: header HTTP só aceita latin1/ASCII.
    Sem isso, "Órfãos.mkv" derruba o writeHead com ERR_INVALID_CHAR. */
function safeFilename(name) {
  return String(path.basename(String(name || "")) || "video")
    .replace(/[^\x20-\x7e]/g, "_")
    .replace(/["\\]/g, "");
}

function guessContentType(name) {
  const n = String(name || "").toLowerCase();
  if (n.endsWith(".webm")) return "video/webm";
  if (n.endsWith(".mkv")) return "video/x-matroska";
  if (n.endsWith(".avi")) return "video/x-msvideo";
  if (n.endsWith(".mov")) return "video/quicktime";
  return "video/mp4";
}

async function handleTorrent(req, res, query) {
  if (!checkAuth(query)) {
    sendJson(res, 401, { error: "Chave inválida." });
    return;
  }
  if (!TORRENT_ENABLED) {
    sendJson(res, 503, {
      error: "Gateway torrent desligado",
      detail: "TORRENT_ENABLED=0 no ambiente do servidor.",
    });
    return;
  }
  try {
    await loadWebTorrent();
  } catch (err) {
    sendJson(res, 503, {
      error: "Motor torrent indisponível",
      detail:
        "Rode npm install na pasta proxy (dependência webtorrent) e reinicie. " +
        String((err && err.message) || err),
    });
    return;
  }

  let magnet = query.get("magnet") || query.get("m") || "";
  const ih = query.get("ih") || query.get("infoHash") || "";
  if (!magnet && ih) {
    magnet = `magnet:?xt=urn:btih:${ih}`;
  }
  if (!magnet) {
    sendJson(res, 400, { error: "Falta ?magnet= ou ?ih=" });
    return;
  }

  // Garante prefixo magnet
  if (!/^magnet:/i.test(magnet) && /^[a-f0-9]{40}$/i.test(magnet)) {
    magnet = `magnet:?xt=urn:btih:${magnet}`;
  }

  const fileIdxRaw = query.get("file") ?? query.get("fileIdx");
  const fileIdx =
    fileIdxRaw != null && fileIdxRaw !== "" ? parseInt(fileIdxRaw, 10) : null;

  let torrent;
  try {
    torrent = await loadTorrent(magnet);
  } catch (err) {
    sendJson(res, 502, {
      error: "Não foi possível abrir o torrent no servidor",
      detail: String(err.message || err),
    });
    return;
  }

  const key = extractInfoHash(magnet);
  touchTorrent(key);

  const file = pickVideoFile(torrent, Number.isFinite(fileIdx) ? fileIdx : null);
  if (!file) {
    sendJson(res, 404, { error: "Nenhum arquivo de vídeo neste torrent" });
    return;
  }

  // Prioriza download deste arquivo
  try {
    if (typeof file.select === "function") file.select();
  } catch {
    /* noop */
  }

  const size = file.length;
  const type = guessContentType(file.name);
  const range = parseRange(req.headers.range, size);

  if (range) {
    const { start, end } = range;
    const chunk = end - start + 1;
    res.writeHead(206, corsHeaders({
      "Content-Type": type,
      "Content-Length": chunk,
      "Content-Range": `bytes ${start}-${end}/${size}`,
      "Accept-Ranges": "bytes",
      "Cache-Control": "no-store",
      "Content-Disposition": `inline; filename="${safeFilename(file.name)}"`,
    }));
    if (req.method === "HEAD") {
      res.end();
      return;
    }
    const stream = file.createReadStream({ start, end });
    stream.pipe(res);
    stream.on("error", () => {
      try {
        res.end();
      } catch {
        /* noop */
      }
    });
    req.on("close", () => {
      try {
        stream.destroy();
      } catch {
        /* noop */
      }
    });
    return;
  }

  res.writeHead(200, corsHeaders({
    "Content-Type": type,
    "Content-Length": size,
    "Accept-Ranges": "bytes",
    "Cache-Control": "no-store",
    "Content-Disposition": `inline; filename="${safeFilename(file.name)}"`,
  }));
  if (req.method === "HEAD") {
    res.end();
    return;
  }
  const stream = file.createReadStream();
  stream.pipe(res);
  stream.on("error", () => {
    try {
      res.end();
    } catch {
      /* noop */
    }
  });
  req.on("close", () => {
    try {
      stream.destroy();
    } catch {
      /* noop */
    }
  });
}

/* ---------------- acervo local (pasta de vídeos do servidor) --------------
   LIBRARY_DIR=/filmes liga estas rotas. O site enxerga um addon NATIVO:
     GET /library/manifest.json                       manifesto para colar
     GET /library?type=movie&id=550&season=&episode=  { streams: [...] }
     GET /file?p=<caminho-relativo>                   vídeo com Range
     GET /library/list                                diagnóstico

   O casamento com o catálogo aceita duas formas:
     1) marcador no nome:  Clube da Luta (1999) [tmdb-550].mp4
        série:            Breaking Bad (2008) [tmdb-1396]/S01E01.mkv
     2) sem marcador: o título/ano do arquivo é comparado com o TMDB
        (precisa de TMDB_API_KEY no ambiente)
------------------------------------------------------------------------- */

const LIBRARY_DIR = process.env.LIBRARY_DIR ? path.resolve(process.env.LIBRARY_DIR) : "";
const LIBRARY_TTL = (Number(process.env.LIBRARY_TTL) || 300) * 1000;
const PUBLIC_ORIGIN = String(process.env.PUBLIC_ORIGIN || "").replace(/\/+$/, "");
const TMDB_KEY = process.env.TMDB_API_KEY || "";
const VIDEO_FILE_RE = /\.(mp4|m4v|webm|mkv|mov|avi|ogv|ts)$/i;

let libraryIndex = { at: 0, files: [] };
const tmdbCache = new Map();

function stripAccents(text) {
  return String(text || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function normTitle(text) {
  return stripAccents(text)
    .toLowerCase()
    .replace(/\[[^\]]*\]|\{[^}]*\}/g, " ")
    .replace(/\((19|20)\d{2}\)/g, " ")
    .replace(/\b(2160p|1080p|720p|480p|4k|bluray|blu-?ray|web-?dl|webrip|hdtv|x264|x265|h\.?264|h\.?265|hevc|aac|ac3|dts|ddp?5\.?1|dual|dublado|legendado)\b/g, " ")
    .replace(/[._-]+/g, " ")
    .replace(/[^a-z0-9 ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function parseLibraryMeta(rel) {
  const parts = rel.split("/");
  const file = parts.pop() || "";
  const folder = parts.length ? parts[parts.length - 1] : "";

  const tag = rel.match(/\[tmdb-(\d+)\]/i) || rel.match(/\{tmdb-(\d+)\}/i);
  const tmdb = tag ? tag[1] : null;

  const se =
    file.match(/(?:^|[^0-9a-z])s(\d{1,2})[\s._-]*e(\d{1,3})/i) ||
    file.match(/(?:^|[^0-9])(\d{1,2})x(\d{1,3})(?:[^0-9]|$)/i);
  const season = se ? Number(se[1]) : null;
  const episode = se ? Number(se[2]) : null;

  const yearMatch =
    rel.match(/\((19|20)\d{2}\)/) ||
    file.match(/\b(19|20)\d{2}\b/) ||
    folder.match(/\b(19|20)\d{2}\b/);
  const year = yearMatch ? String(yearMatch[0]).replace(/[()]/g, "") : "";

  const quality =
    (file.match(/\b(2160p|1080p|720p|480p|4k)\b/i) || [])[0] || "";

  // Série: o título está na pasta. Filme: no nome do arquivo.
  const titleSource = season != null && folder
    ? folder
    : file.replace(VIDEO_FILE_RE, "").replace(/s\d{1,2}[\s._-]*e\d{1,3}.*$/i, "");

  return { tmdb, season, episode, year, quality, norm: normTitle(titleSource) };
}

function walkVideos(dir, base, out, depth) {
  if (depth > 5) return;
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of entries) {
    if (String(entry.name).startsWith(".")) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walkVideos(full, base, out, depth + 1);
      continue;
    }
    if (!VIDEO_FILE_RE.test(entry.name)) continue;
    let size = 0;
    try {
      size = fs.statSync(full).size;
    } catch {
      /* noop */
    }
    out.push({ rel: path.relative(base, full).split(path.sep).join("/"), size });
  }
}

function getLibraryIndex() {
  if (!LIBRARY_DIR) return [];
  const now = Date.now();
  if (libraryIndex.files.length && now - libraryIndex.at < LIBRARY_TTL) {
    return libraryIndex.files;
  }
  const raw = [];
  walkVideos(LIBRARY_DIR, LIBRARY_DIR, raw, 0);
  const files = raw.map((item) => ({ ...item, meta: parseLibraryMeta(item.rel) }));
  libraryIndex = { at: now, files };
  return files;
}

async function tmdbInfo(type, id) {
  if (!TMDB_KEY) return null;
  const key = `${type}:${id}`;
  if (tmdbCache.has(key)) return tmdbCache.get(key);

  const section = type === "tv" ? "tv" : "movie";
  const url =
    `https://api.themoviedb.org/3/${section}/${encodeURIComponent(id)}` +
    `?api_key=${encodeURIComponent(TMDB_KEY)}&language=pt-BR`;
  let info = null;
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`TMDB ${res.status}`);
    const data = await res.json();
    info = {
      title: normTitle(data.title || data.name || ""),
      alt: normTitle(data.original_title || data.original_name || ""),
      year: String(data.release_date || data.first_air_date || "").slice(0, 4),
    };
  } catch {
    info = null;
  }
  tmdbCache.set(key, info);
  return info;
}

function publicBase(req) {
  if (PUBLIC_ORIGIN) return PUBLIC_ORIGIN;
  const host = req.headers.host || `localhost:${PORT}`;
  const proto =
    String(req.headers["x-forwarded-proto"] || "").split(",")[0].trim() ||
    (req.socket && req.socket.encrypted ? "https" : "http");
  return `${proto}://${host}`;
}

function libraryFileUrl(req, rel) {
  const key = PROXY_SECRET ? `&key=${encodeURIComponent(PROXY_SECRET)}` : "";
  return `${publicBase(req)}/file?p=${encodeURIComponent(rel)}${key}`;
}

async function findLibraryStreams(req, type, id, season, episode) {
  const files = getLibraryIndex();
  const wanted = String(id || "").trim();
  if (!wanted || !files.length) return [];

  const isTv = type === "tv" || type === "series";

  // 1) marcador explícito no nome — sem rede, sem adivinhação
  let hits = files.filter((file) => file.meta.tmdb === wanted);

  // 2) sem marcador: compara título/ano do arquivo com o TMDB
  if (!hits.length) {
    const info = await tmdbInfo(isTv ? "tv" : "movie", wanted);
    if (info && (info.title || info.alt)) {
      hits = files.filter((file) => {
        if (file.meta.tmdb) return false;
        const meta = file.meta;
        if (!meta.norm) return false;
        if (meta.norm !== info.title && meta.norm !== info.alt) return false;
        if (meta.year && info.year && meta.year !== info.year) return false;
        return true;
      });
    }
  }
  if (!hits.length) return [];

  if (isTv) {
    const wantSeason = Number(season) || 1;
    const wantEpisode = Number(episode) || 1;
    const episodeHits = hits.filter(
      (file) => file.meta.season === wantSeason && file.meta.episode === wantEpisode
    );
    // sem SxxExx no nome não dá para saber qual episódio é: melhor não chutar
    if (!episodeHits.length) return [];
    hits = episodeHits;
  } else {
    // filme: descarta arquivos que são episódio de série
    hits = hits.filter((file) => file.meta.season == null);
  }
  if (!hits.length) return [];

  hits.sort((a, b) => b.size - a.size);

  return hits.slice(0, 6).map((file) => ({
    label: file.meta.quality || path.basename(file.rel),
    quality: file.meta.quality || "",
    size: file.size,
    url: libraryFileUrl(req, file.rel),
  }));
}

function handleLibraryFile(req, res, query) {
  if (!LIBRARY_DIR) {
    sendJson(res, 503, {
      error: "Acervo local desligado",
      detail: "Defina LIBRARY_DIR no ambiente do servidor.",
    });
    return;
  }
  if (!checkAuth(query)) {
    sendJson(res, 401, { error: "Chave inválida." });
    return;
  }

  const rel = String(query.get("p") || query.get("path") || "").replace(/\\/g, "/");
  if (!rel) {
    sendJson(res, 400, { error: "Falta ?p=<caminho relativo dentro de LIBRARY_DIR>" });
    return;
  }

  const full = path.resolve(LIBRARY_DIR, rel);
  if (full !== LIBRARY_DIR && !full.startsWith(LIBRARY_DIR + path.sep)) {
    sendJson(res, 403, { error: "Caminho fora do acervo." });
    return;
  }

  let stat;
  try {
    stat = fs.statSync(full);
  } catch {
    sendJson(res, 404, { error: "Arquivo não encontrado." });
    return;
  }
  if (!stat.isFile()) {
    sendJson(res, 404, { error: "Não é um arquivo." });
    return;
  }

  const size = stat.size;
  const type = guessContentType(full);
  const range = parseRange(req.headers.range, size);
  const name = safeFilename(full);
  const baseHeaders = {
    "Content-Type": type,
    "Accept-Ranges": "bytes",
    "Cache-Control": "no-store",
    "Content-Disposition": `inline; filename="${name}"`,
  };

  if (range) {
    const { start, end } = range;
    res.writeHead(
      206,
      corsHeaders({
        ...baseHeaders,
        "Content-Length": end - start + 1,
        "Content-Range": `bytes ${start}-${end}/${size}`,
      })
    );
    if (req.method === "HEAD") {
      res.end();
      return;
    }
    const stream = fs.createReadStream(full, { start, end });
    stream.pipe(res);
    stream.on("error", () => {
      try {
        res.end();
      } catch {
        /* noop */
      }
    });
    req.on("close", () => stream.destroy());
    return;
  }

  res.writeHead(200, corsHeaders({ ...baseHeaders, "Content-Length": size }));
  if (req.method === "HEAD") {
    res.end();
    return;
  }
  const stream = fs.createReadStream(full);
  stream.pipe(res);
  stream.on("error", () => {
    try {
      res.end();
    } catch {
      /* noop */
    }
  });
  req.on("close", () => stream.destroy());
}

/* ---------------- HTTP server ---------------- */

const server = http.createServer(async (req, res) => {
  try {
    const host = req.headers.host || `localhost:${PORT}`;
    const full = new URL(req.url || "/", `http://${host}`);
    const pathname = full.pathname.replace(/\/+$/, "") || "/";

    if (req.method === "OPTIONS") {
      res.writeHead(204, corsHeaders());
      res.end();
      return;
    }

    if (pathname === "/health" || pathname === "/") {
      // Confere de verdade se o motor carrega (uma vez só; depois fica em cache).
      const engine = TORRENT_ENABLED
        ? await loadWebTorrent()
            .then(() => true)
            .catch(() => false)
        : false;
      sendJson(res, 200, {
        ok: true,
        service: "netfilmes-stream-proxy",
        proxy: "/proxy?url=",
        torrent: TORRENT_ENABLED && engine ? "/torrent?magnet=" : null,
        torrentEngine: engine,
        torrentPath: TORRENT_ENABLED && engine ? downloadDir() : null,
        node: process.version,
        auth: Boolean(PROXY_SECRET),
        library: LIBRARY_DIR
          ? {
              dir: LIBRARY_DIR,
              files: libraryIndex.files.length,
              manifest: "/library/manifest.json",
              tmdbKey: Boolean(TMDB_KEY),
            }
          : null,
        pinguim: Pinguim ? Pinguim.info() : null,
        activeTorrents: activeTorrents.size,
      });
      return;
    }

    if (pathname === "/proxy") {
      if (req.method !== "GET" && req.method !== "HEAD") {
        sendJson(res, 405, { error: "Use GET ou HEAD." });
        return;
      }
      await handleProxy(req, res, full.searchParams);
      return;
    }

    if (pathname === "/torrent") {
      if (req.method !== "GET" && req.method !== "HEAD") {
        sendJson(res, 405, { error: "Use GET ou HEAD." });
        return;
      }
      await handleTorrent(req, res, full.searchParams);
      return;
    }

    if (pathname === "/library/manifest.json" || pathname === "/library/manifest") {
      if (!LIBRARY_DIR) {
        sendJson(res, 503, {
          error: "Acervo local desligado",
          detail: "Defina LIBRARY_DIR no ambiente do servidor.",
        });
        return;
      }
      const sep = PROXY_SECRET ? `?key=${encodeURIComponent(PROXY_SECRET)}&` : "?";
      sendJson(res, 200, {
        name: `Acervo local (${path.basename(LIBRARY_DIR)})`,
        endpoint:
          `${publicBase(req)}/library${sep}` +
          "type={type}&id={id}&season={season}&episode={episode}",
      });
      return;
    }

    if (pathname === "/library/list") {
      if (!checkAuth(full.searchParams)) {
        sendJson(res, 401, { error: "Chave inválida." });
        return;
      }
      const files = getLibraryIndex();
      sendJson(res, 200, {
        dir: LIBRARY_DIR || null,
        total: files.length,
        files: files.slice(0, 200).map((file) => ({
          path: file.rel,
          size: file.size,
          tmdb: file.meta.tmdb,
          season: file.meta.season,
          episode: file.meta.episode,
          title: file.meta.norm,
          year: file.meta.year,
        })),
      });
      return;
    }

    if (pathname === "/library") {
      if (req.method !== "GET" && req.method !== "HEAD") {
        sendJson(res, 405, { error: "Use GET ou HEAD." });
        return;
      }
      if (!checkAuth(full.searchParams)) {
        sendJson(res, 401, { error: "Chave inválida." });
        return;
      }
      const streams = await findLibraryStreams(
        req,
        String(full.searchParams.get("type") || "movie").toLowerCase(),
        full.searchParams.get("id") || full.searchParams.get("tmdb") || "",
        full.searchParams.get("season") || "",
        full.searchParams.get("episode") || ""
      );
      sendJson(res, 200, { streams });
      return;
    }

    if (pathname === "/file") {
      if (req.method !== "GET" && req.method !== "HEAD") {
        sendJson(res, 405, { error: "Use GET ou HEAD." });
        return;
      }
      handleLibraryFile(req, res, full.searchParams);
      return;
    }

    if (pathname === "/pinguim/manifest.json" || pathname === "/pinguim/manifest") {
      if (!Pinguim) {
        sendJson(res, 503, {
          error: "Fonte PinguimCinema indisponível",
          detail: "O módulo proxy/pinguim.js não carregou — veja o log do servidor.",
        });
        return;
      }
      const sep = PROXY_SECRET ? `?key=${encodeURIComponent(PROXY_SECRET)}&` : "?";
      sendJson(res, 200, {
        name: "PinguimCinema",
        endpoint:
          `${publicBase(req)}/pinguim${sep}` +
          "type={type}&id={id}&season={season}&episode={episode}",
      });
      return;
    }

    if (pathname === "/pinguim") {
      if (req.method !== "GET" && req.method !== "HEAD") {
        sendJson(res, 405, { error: "Use GET ou HEAD." });
        return;
      }
      if (!Pinguim) {
        sendJson(res, 503, {
          error: "Fonte PinguimCinema indisponível",
          detail: "O módulo proxy/pinguim.js não carregou — veja o log do servidor.",
        });
        return;
      }
      if (!checkAuth(full.searchParams)) {
        sendJson(res, 401, { error: "Chave inválida." });
        return;
      }
      const result = await Pinguim.getStreams({
        type: full.searchParams.get("type") || "movie",
        id: full.searchParams.get("id") || full.searchParams.get("tmdb") || "",
        season: full.searchParams.get("season") || "",
        episode: full.searchParams.get("episode") || "",
        base: publicBase(req),
      });
      const wantsDebug = /^(1|true|yes)$/i.test(String(full.searchParams.get("debug") || ""));
      sendJson(
        res,
        200,
        wantsDebug ? { streams: result.streams, debug: result.debug } : { streams: result.streams }
      );
      return;
    }

    sendJson(res, 404, { error: "Rota inexistente. Use /proxy?url= ou /torrent?magnet=" });
  } catch (err) {
    sendJson(res, 500, { error: "Erro interno", detail: String(err.message || err) });
  }
});

setInterval(pruneTorrents, 60 * 1000).unref?.();

// Monta o índice do acervo em segundo plano: a primeira busca do site não
// pode pagar a varredura da pasta inteira.
if (LIBRARY_DIR) {
  setTimeout(() => {
    try {
      const files = getLibraryIndex();
      console.log(`[netfilmes-proxy] acervo: ${files.length} arquivo(s) em ${LIBRARY_DIR}`);
      if (!TMDB_KEY) {
        console.log(
          "[netfilmes-proxy] acervo: sem TMDB_API_KEY só casam arquivos com [tmdb-<id>] no nome"
        );
      }
    } catch (err) {
      console.warn("[netfilmes-proxy] acervo:", err.message);
    }
  }, 500).unref?.();
}

server.listen(PORT, () => {
  console.log(`[netfilmes-proxy] http://0.0.0.0:${PORT}`);
  console.log(`[netfilmes-proxy] /health  /proxy?url=  /torrent?magnet=  /pinguim/manifest.json`);
  console.log(
    `[netfilmes-proxy] torrent: ${
      TORRENT_ENABLED ? "LIGADO (webtorrent carrega no 1º uso)" : "desligado"
    }`
  );
  if (PROXY_SECRET) console.log("[netfilmes-proxy] PROXY_SECRET ativo");
});
