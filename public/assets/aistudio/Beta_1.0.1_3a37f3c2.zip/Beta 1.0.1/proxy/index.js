/**
 * Ponto de entrada exigido pelo host (no Shard Cloud: MAIN=index.js no
 * .shardcloud). O servidor de verdade está em server.js — aqui só chamamos.
 * Rodar direto também funciona: node server.js
 */

"use strict";

require("./server.js");
