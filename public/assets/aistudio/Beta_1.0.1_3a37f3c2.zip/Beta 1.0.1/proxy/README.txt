========================================
  PROXY NODE + GATEWAY TORRENT — Netfilmes
========================================

Rotas
-----
  GET /health
  GET /proxy?url=<URL-codificada>[&h=...][&key=]
  GET /torrent?magnet=<magnet>[&file=0][&key=]
  GET /torrent?ih=<infoHash>[&file=0]
  GET /library/manifest.json
  GET /library?type=movie&id=<tmdb>&season=&episode=[&key=]
  GET /file?p=<caminho-relativo>[&key=]
  GET /library/list[?key=]
  GET /pinguim/manifest.json
  GET /pinguim?type=movie|tv&id=<tmdb>&season=&episode=[&key=][&debug=1]

O /torrent baixa o torrent NO SERVIDOR (UDP/TCP) e entrega o vídeo por
HTTP com Range. O navegador só vê um stream normal.

1) Instalar e subir
-------------------
  cd proxy
  npm install
  npm start

  Teste: http://127.0.0.1:8787/health
  Deve mostrar torrent: "/torrent?magnet=" e torrentEngine: true

  Se vier torrentEngine: false, o pacote webtorrent não carregou.
  Rode: npm run check   (ele usa import(), que é o modo certo: o
  webtorrent 2.x é ESM puro e não funciona com require).

  NO SEU PC (Windows) — para testar sem hospedagem
  ------------------------------------------------
  1. Instale o Node.js LTS: https://nodejs.org (instalador padrão, "next" até o fim)
  2. Abra a pasta proxy/ e dê dois cliques em  INICIAR-NO-PC.bat
     (ou: botão direito na pasta → "Abrir no Terminal" → node index.js)
  3. Deixe a janela aberta e teste no navegador:
       http://127.0.0.1:8787/health
       http://127.0.0.1:8787/pinguim?type=movie&id=603&debug=1
     A segunda tem que trazer "streams" com um .m3u8 (ou debug dizendo o
     que o WatchPlay e o megaembed responderam).
  4. Para PARAR: feche a janela (ou Ctrl+C).

  npm install  NÃO é preciso para esta fonte: a pasta roda com o Node puro
  (só o gateway /torrent depende do pacote webtorrent, e o /health avisa).

  Enquanto o proxy roda SÓ no seu PC, o site publicado NÃO alcança ele (cada
  visitante procuraria o computador dele). Para testar de verdade no seu PC,
  aponte o config.js do site para o endereço local
    const PINGUIM_PROXY_URL = "http://127.0.0.1:8787";
  e abra o site NO MESMO computador (não suba essa versão do config.js: quem
  visita o site de fora iria procurar a máquina dele).

  Para valer para todo mundo: publique o proxy (item 2) ou exponha o seu PC
  por um túnel, ex.:  cloudflared tunnel --url http://localhost:8787  — aí o
  seu PC precisa ficar ligado e o endereço do túnel vai no PINGUIM_PROXY_URL.

2) Deploy (Shard / Node / VPS)
------------------------------
  Pasta: proxy/
  Start: npm start   (ou node server.js)
  Install: npm install
  Env:
    PROXY_SECRET=senha
    ALLOW_ORIGIN=https://seu-site.com
    TORRENT_ENABLED=1
    TORRENT_MAX=3
    TORRENT_PATH=/tmp/netfilmes-torrents   (opcional, onde os pedaços
                                            vão para o disco)

   SHARD CLOUD (o host do site) — passo a passo
   -------------------------------------------
   O site é estático, mas ESTA pasta precisa de um app Node: ela sobe um
   servidor HTTP de verdade.

   1. No painel, crie um app NOVO (linguagem JavaScript/Node — NÃO "static") e
      escolha um subdomínio, ex. netfilmes-proxy
      → a URL fica https://netfilmes-proxy.shardcloud.app
   2. Monte um ZIP com o CONTEÚDO desta pasta:
        index.js  server.js  pinguim.js  package.json  .shardcloud  README.txt
      - NÃO mande node_modules nem package-lock.json (o host instala sozinho)
      - o .shardcloud é obrigatório e é um arquivo com ponto: confira se o ZIP
        o incluiu (junto dele, e NÃO o .shardcloud do site, que é da pasta de cima)
      - o index.js só chama o server.js (MAIN=index.js no .shardcloud)
   3. Envie o ZIP pelo painel do app e aguarde o build/deploy.
   4. Variáveis de ambiente (painel do app → Environment Variables):
        ALLOW_ORIGIN    https://SEU-SITE (o domínio do catálogo) ou *
        PROXY_SECRET    senha opcional — o manifesto já sai com ?key=
        TORRENT_ENABLED=0     desliga o gateway torrent (economiza RAM; a
                              fonte PinguimCinema NÃO precisa dele)
        PINGUIMCINEMA_DEBUG=1 logs detalhados na primeira semana
        LIBRARY_DIR     só se você tiver pasta de vídeos no servidor
      PORT o host injeta sozinho.
   5. Confira:  https://SEU-PROXY/health
      A resposta precisa trazer o bloco "pinguim". Se vier null, o
      pinguim.js não carregou — o log do app diz o porquê.
      E:  https://SEU-PROXY/pinguim/manifest.json   → { name, endpoint }

   Se o build falhar na instalação, o pacote webtorrent (só usado pelo
   /torrent) é o suspeito: dá para tirá-lo do package.json e deixar
   TORRENT_ENABLED=0 — o proxy e a fonte PinguimCinema seguem funcionando.


3) config.js do site
--------------------
  const STREAM_PROXY = "https://SEU-PROXY/proxy?url=";
  const STREAM_PROXY_ALWAYS = true;
  const TORRENT_PROXY = null;  // usa o mesmo host em /torrent?magnet=

4) Avisos
---------
  - Usa CPU, disco e muita banda: precisa de um host Node de verdade
    (o site estático não roda esta pasta)
  - O download vai para DISCO, não para a memória. Com 512 MB de RAM
    ainda dá para 1-2 torrents; o gargalo passa a ser espaço em disco
  - O primeiro play demora alguns segundos (metadados + primeiros
    pedaços); o servidor desiste em 60 s se não achar ninguém
  - Confira ToS do provedor (torrent)
  - MKV/HEVC/AC3 ainda depende do navegador: o proxy entrega os bytes
    originais, não converte. Para MKV tocar, use um motor com remux
    (ex.: Webtor self-hosted)

5) Desligar só torrent
----------------------
  Servidor: TORRENT_ENABLED=0
  Site: const TORRENT_PROXY = false;


6) ACERVO LOCAL (sua pasta de vídeos)
-------------------------------------
Serve os arquivos do próprio servidor por HTTP com Range — o player do
site toca como se fosse um addon normal, sem torrent e sem terceiros.

Ligar:
  LIBRARY_DIR=/caminho/dos/videos  PUBLIC_ORIGIN=https://seu-proxy.com  npm start

  Env:
    LIBRARY_DIR    pasta com os vídeos (liga as rotas /library e /file)
    PUBLIC_ORIGIN  URL pública do proxy (senão ele deduz do Host)
    TMDB_API_KEY   chave do TMDB, para casar título/ano
    LIBRARY_TTL    segundos de cache do índice (padrão 300)

No site:
  Fontes de vídeo (☰) → cole  https://SEU-PROXY/library/manifest.json

Como o arquivo é ligado ao título do catálogo (o site manda o id do TMDB):

  1) Marcador no nome — exato, não precisa de TMDB_API_KEY:
       Filmes/Clube da Luta (1999) [tmdb-550].mp4
       Series/Breaking Bad (2008) [tmdb-1396]/S01E01.mkv

  2) Sem marcador — compara título e ano do arquivo com o TMDB:
       Filmes/Clube da Luta (1999).mp4

Regras:
  - Série precisa de SxxExx no nome do episódio (S01E01 ou 1x01)
  - Vários arquivos do mesmo título viram várias fontes (1080p, 4K…)
  - Só serve caminho DENTRO de LIBRARY_DIR (".." é recusado)
  - MKV/HEVC continua dependendo do navegador
  - Diagnóstico: /library/list mostra o que foi indexado e como cada
    arquivo foi interpretado

Teste rápido:
  curl http://127.0.0.1:8787/library/list
  curl "http://127.0.0.1:8787/library?type=movie&id=550"
  curl -I "http://127.0.0.1:8787/file?p=Filmes%2FClube%20da%20Luta%20(1999)%20%5Btmdb-550%5D.mp4"
  (o /file deve responder 206 com Content-Range)


7) FONTE PINGUIMCINEMA (FILMES E SÉRIES)
----------------------------------------
Resolve no SERVIDOR (o navegador não consegue falar com esses servidores: as
páginas não liberam CORS e o player exige User-Agent/Referer de navegador) e
entrega o HLS pronto para o player do próprio site:

  GET /pinguim/manifest.json                        manifesto para colar
  GET /pinguim?type=movie&id=550&season=&episode=   { streams: [...] }
  GET /pinguim?...&debug=1                          + o que foi medido

No site, escolha UM dos dois jeitos:

  a) Sem mexer no código: Fontes de vídeo (☰) → cole
       https://SEU-PROXY/pinguim/manifest.json
     O manifesto já sai com a sua URL (e com a chave, se PROXY_SECRET estiver
     ligado).

  b) Fixa na lista, pelo config.js do site: preencha
       const PINGUIM_PROXY_URL = "https://SEU-PROXY";
     e a fonte entra sozinha na lista de "Fontes de vídeo", com o botão
     liga/desliga — não precisa colar nada. Em branco, nada aparece.

Depois disso o vídeo toca no player do site — nada de abrir player de terceiros.

Como resolve, em ordem:
  1) WatchPlay (v2.watchplay.shop) — ~1 s, e é o único que diz o idioma da
     faixa (Dublado/Legendado); devolve a playlist HLS assinada
  2) megaembed (mgeb.site, hoje redireciona para mgeb.lat) — ficha do servidor
     2 do site, sem desafio; imprime as opções HLS
Toda opção é sondada (master → variante → segmentos) e só entra a que comprova
mídia: o endereço é temporário e opção morta viraria um item que gira para
sempre. Se nenhuma comprovar, a resposta é {"streams":[]} e o site mostra as
outras fontes.

Tempo: o site desiste em 7 s. Se a resolução não couber nesse orçamento, a
resposta sai vazia AGORA, mas o trabalho continua e entra no cache (6 min):
reabrir o título — ou "↻ Tentar de novo" no player — já vem completo.

Env (todas opcionais):
  PINGUIMCINEMA_BASE_URL        site usado no Referer (padrão pinguimcinema.space)
  PINGUIMCINEMA_WATCHPLAY_URL   padrão https://v2.watchplay.shop
  PINGUIMCINEMA_EMBED_URL       padrão https://mgeb.site
  PINGUIMCINEMA_USER_AGENT      UA usado nas requisições
  PINGUIMCINEMA_WAIT_MS         orçamento de espera (padrão 5000)
  PINGUIMCINEMA_VIA_PROXY=1     manda a mídia pelo /proxy?url= DESTE servidor
                                (use se o CDN recusar o IP do visitante; gasta
                                banda do servidor de vídeo)
  PINGUIMCINEMA_DEBUG=1         loga cada passo (HTTP, playlist, cache)

Teste rápido:
  curl http://127.0.0.1:8787/pinguim/manifest.json
  curl "http://127.0.0.1:8787/pinguim?type=movie&id=603&debug=1"
  curl "http://127.0.0.1:8787/pinguim?type=tv&id=1396&season=1&episode=1&debug=1"
  (streams[].url deve ser um .m3u8 que abre no navegador)

O arquivo proxy/pinguim.js é a adaptação do addon PinguimCinema para este
servidor: o que era o formato do Stremio virou o addon NATIVO do site, e a
lista de acervo de 211 KB e o fallback "abrir no navegador" ficaram de fora —
sem mídia comprovada a fonte não entra na lista.
