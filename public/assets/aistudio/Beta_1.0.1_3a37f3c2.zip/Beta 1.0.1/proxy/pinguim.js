/**
 * PinguimCinema — fonte de filmes e séries para o Netfilmes (Node 18+)
 *
 * O catálogo do site é estático e o navegador não consegue falar com esses
 * servidores: as páginas não liberam CORS e o player deles exige User-Agent e
 * Referer de navegador. Por isso a resolução acontece AQUI, no servidor, e o
 * site só recebe o endereço do HLS já testado, no formato do addon nativo:
 *
 *   GET /pinguim/manifest.json                      manifesto para colar
 *   GET /pinguim?type=movie&id=550&season=&episode= { streams: [...] }
 *
 * Ordem de resolução (mesma lógica do addon, medida ao vivo):
 *   1) WatchPlay   — responde em ~1 s e é o único que diz o idioma da faixa
 *                    (Dublado/Legendado); a playlist vem assinada e com CORS.
 *   2) megaembed   — ficha do site (servidor 2, sem desafio): imprime o array
 *                    `sources` com as playlists HLS.
 *
 * Toda opção é SONDADA (master → variante → segmentos) antes de entrar: o
 * endereço é temporário e opção morta viraria um item que gira para sempre.
 * Esta versão não usa a lista de acervo do player (`/lista`, 211 KB) nem o
 * fallback de "abrir no navegador": sem mídia comprovada a fonte devolve [].
 *
 * Env (opcional):
 *   PINGUIMCINEMA_BASE_URL, PINGUIMCINEMA_WATCHPLAY_URL, PINGUIMCINEMA_EMBED_URL,
 *   PINGUIMCINEMA_USER_AGENT, PINGUIMCINEMA_WAIT_MS, PINGUIMCINEMA_DEBUG=1,
 *   PINGUIMCINEMA_VIA_PROXY=1  (manda a mídia pelo /proxy?url= deste servidor)
 */

"use strict";

const PROVIDER = "PinguimCinema";

const DEFAULT_SITE_URL = "https://pinguimcinema.space";
const DEFAULT_WATCHPLAY_URL = "https://v2.watchplay.shop";
const DEFAULT_EMBED_URL = "https://mgeb.site";
const DEFAULT_USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

/* O site espera a resposta do endpoint em 7 s (FETCH_TIMEOUT no api.js) e
   desiste. O que não couber neste orçamento continua rodando em segundo plano e
   entra no cache: a próxima abertura do título — ou o "↻ Tentar de novo" do
   player — já recebe a lista completa, sem esperar de novo. */
const DEFAULT_WAIT_MS = 5000;
const WATCHPLAY_TIMEOUT_MS = 4000;
const EMBED_TIMEOUT_MS = 4500;
const PLAYLIST_TIMEOUT_MS = 3500;
const RESOLVE_TTL_MS = 6 * 60 * 1000;
const RESOLVE_FAILURE_TTL_MS = 60 * 1000;
const MAX_STREAMS = 4;
const MAX_WATCHPLAY_CHOICES = 3;

function envText(name) {
  const value = process.env[name];
  if (value != null && String(value).trim()) return String(value).trim();
  // Nome publicado antes deste módulo tinha um typo ("PINGUIMCIANEMA"): quem já
  // configurou o deploy com ele continua funcionando.
  const legacy = String(name).replace(/^PINGUIMCINEMA_/, "PINGUIMCIANEMA_");
  const alt = process.env[legacy];
  return alt != null ? String(alt).trim() : "";
}

function envNumber(name, fallback) {
  const value = Number(envText(name));
  return Number.isFinite(value) && value > 0 ? value : fallback;
}

function envFlag(name) {
  return /^(?:1|true|yes|on)$/i.test(envText(name));
}

function config() {
  return {
    siteUrl: (envText("PINGUIMCINEMA_BASE_URL") || DEFAULT_SITE_URL).replace(/\/+$/, ""),
    watchplayUrl: (envText("PINGUIMCINEMA_WATCHPLAY_URL") || DEFAULT_WATCHPLAY_URL).replace(/\/+$/, ""),
    embedUrl: (envText("PINGUIMCINEMA_EMBED_URL") || DEFAULT_EMBED_URL).replace(/\/+$/, ""),
    userAgent: envText("PINGUIMCINEMA_USER_AGENT") || DEFAULT_USER_AGENT,
  };
}

function info() {
  const cfg = config();
  return {
    provider: PROVIDER,
    manifest: "/pinguim/manifest.json",
    endpoint: "/pinguim?type={type}&id={id}&season={season}&episode={episode}",
    watchplay: cfg.watchplayUrl,
    embed: cfg.embedUrl,
    viaProxy: envFlag("PINGUIMCINEMA_VIA_PROXY"),
    waitMs: envNumber("PINGUIMCINEMA_WAIT_MS", DEFAULT_WAIT_MS),
  };
}

function log(message) {
  console.log(`[pinguim] ${message}`);
}

function debug(message) {
  if (envFlag("PINGUIMCINEMA_DEBUG")) console.log(`[pinguim] ${message}`);
}

function delay(ms) {
  return new Promise((resolve) => {
    const timer = setTimeout(resolve, ms);
    if (timer && typeof timer.unref === "function") timer.unref();
  });
}

function numeric(value) {
  const parsed = parseInt(value, 10);
  return parsed > 0 ? parsed : 0;
}

/* kind: "filme" | "serie" — o vocabulário do player deles. */
function kindOf(mediaType) {
  const type = String(mediaType || "").toLowerCase();
  if (type === "series" || type === "serie" || type === "tv" || type === "anime" || type === "dorama") {
    return "serie";
  }
  return "filme";
}

function hostOf(url) {
  try {
    return new URL(String(url || "")).hostname;
  } catch {
    return "";
  }
}

function absoluteUrl(uri, base) {
  try {
    return new URL(String(uri || "").trim(), base).href;
  } catch {
    return "";
  }
}

/* O caminho é sempre o id do TMDB (filme sem temporada), igual ao player. */
function watchplayUrl(mediaType, tmdbId, season, episode) {
  const id = numeric(tmdbId);
  if (!id) return "";
  const base = config().watchplayUrl;
  if (kindOf(mediaType) === "serie") {
    return `${base}/tvshow/${id}/${numeric(season) || 1}/${numeric(episode) || 1}`;
  }
  return `${base}/movie/${id}`;
}

function embedUrl(mediaType, tmdbId, season, episode) {
  const id = numeric(tmdbId);
  if (!id) return "";
  const base = config().embedUrl;
  if (kindOf(mediaType) === "serie") {
    return `${base}/embed/${id}/${numeric(season) || 1}/${numeric(episode) || 1}`;
  }
  return `${base}/embed/${id}`;
}

/* ---------------- parsers (medidos ao vivo; ver proxy/README.txt) ---------- */

/* A página imprime, num <script>, o idioma da faixa e o endereço da playlist:
     window.MyPlayerAudio="Dublado"; window.MyPlayerPlayers=["Dublado"];
     createMyPlayer({..., url:"https:\/\/...\/playlist.m3u8?md5=...", ...})
   O endereço vem com as barras escapadas (\/), formato de string JS. */
function parseWatchplayPage(html) {
  const body = String(html || "");
  const urlMatch = /url\s*:\s*["']([^"']+)["']/i.exec(body);
  if (!urlMatch) return null;
  const file = urlMatch[1].replace(/\\\//g, "/").trim();
  if (!/^https?:\/\//i.test(file)) return null;

  const audioMatch = /window\.MyPlayerAudio\s*=\s*["']([^"']*)["']/i.exec(body);
  let audio = audioMatch ? String(audioMatch[1]).trim() : "";

  const playersMatch = /window\.MyPlayerPlayers\s*=\s*(\[[^\]]*\])/i.exec(body);
  let players = [];
  if (playersMatch) {
    try {
      players = JSON.parse(playersMatch[1]);
    } catch {
      players = [];
    }
  }
  if (!audio && players.length) audio = String(players[0] || "").trim();

  const labelled = players
    .map((value) => String(value || "").trim())
    .filter((value, index, list) => value && list.indexOf(value) === index);
  if (labelled.length > 1) audio = labelled.join(" + ");

  return { url: file, audio, players: labelled };
}

/* Algumas fichas não imprimem o player: listam escolhas
   (`<a href="?player=0">Dublado</a>`) e só montam com o parâmetro. */
function parseWatchplayChoices(html) {
  const body = String(html || "");
  const out = [];
  const pattern = /href=["']\?player=(\d+)["']/gi;
  let match;
  while ((match = pattern.exec(body))) {
    const index = parseInt(match[1], 10);
    if (!Number.isNaN(index) && out.indexOf(index) === -1) out.push(index);
  }
  return out;
}

/* A ficha do megaembed imprime `var sources = [...]`, com {file, type, label}. */
function parseSources(html) {
  const match = /(?:var|let|const)\s+sources\s*=\s*(\[[\s\S]*?\])\s*;/i.exec(String(html || ""));
  if (!match) return [];
  let parsed;
  try {
    parsed = JSON.parse(match[1]);
  } catch {
    return [];
  }
  if (!Array.isArray(parsed)) return [];
  return parsed
    .map((row) => ({
      url: String((row && row.file) || "").trim(),
      type: String((row && row.type) || "").toLowerCase(),
      label: String((row && row.label) || "").trim(),
    }))
    .filter((row) => /^https?:\/\//i.test(row.url));
}

/* ---------------- playlist HLS ---------------- */

function qualityFromHeight(height) {
  const value = Number(height) || 0;
  if (value >= 2000) return "2160p";
  if (value >= 1400) return "1440p";
  if (value >= 1000) return "1080p";
  if (value >= 700) return "720p";
  if (value >= 470) return "480p";
  if (value >= 340) return "360p";
  if (value >= 230) return "240p";
  return "";
}

function qualityFromInf(line) {
  const resolution = /RESOLUTION=(\d+)x(\d+)/i.exec(String(line || ""));
  if (resolution) {
    const fromResolution = qualityFromHeight(resolution[2]);
    if (fromResolution) return fromResolution;
  }
  const name = /NAME="([^"]+)"/i.exec(String(line || ""));
  if (name) {
    const labelled = /(\d{3,4})p/i.exec(name[1]);
    if (labelled) {
      const fromName = qualityFromHeight(labelled[1]);
      if (fromName) return fromName;
    }
  }
  return "";
}

function bandwidthFromInf(line) {
  const match = /BANDWIDTH=(\d+)/i.exec(String(line || ""));
  return match ? Number(match[1]) || 0 : 0;
}

function qualityFromUrl(url) {
  const decoded = (() => {
    try {
      return decodeURIComponent(String(url || ""));
    } catch {
      return String(url || "");
    }
  })();
  const pair = /(?:^|[^0-9])(\d{3,4})x(\d{3,4})(?:[^0-9]|$)/.exec(decoded);
  if (pair) return qualityFromHeight(pair[2]);
  const named = /(?:^|[^0-9])(2160|1440|1080|720|480|360|240)p(?:[^0-9]|$)/i.exec(decoded);
  return named ? qualityFromHeight(named[1]) : "";
}

/* Devolve {variants, segments, dead} ou null quando o corpo não é HLS.
   `dead` é o "Nenhuma qualidade encontrada" que o worker deles devolve com
   HTTP 200: sem essa checagem a opção morta entraria na lista. */
function playlistInfo(text) {
  const body = String(text || "");
  if (body.indexOf("#EXTM3U") === -1) return null;
  if (/Nenhuma\s+qualidade/i.test(body)) return { variants: [], segments: 0, dead: true };

  const lines = body.split(/\r?\n/);
  const variants = [];
  let segments = 0;
  let pending = "";
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (line.charAt(0) === "#") {
      if (/^#EXT-X-STREAM-INF/i.test(line)) pending = line;
      continue;
    }
    if (pending) {
      variants.push({ uri: line, quality: qualityFromInf(pending), bandwidth: bandwidthFromInf(pending) });
      pending = "";
      continue;
    }
    segments += 1;
  }
  return { variants, segments, dead: false };
}

function bestVariant(variants) {
  const list = Array.isArray(variants) ? variants.slice() : [];
  if (!list.length) return null;
  list.sort((a, b) => {
    const qa = parseInt(String(a.quality || ""), 10) || 0;
    const qb = parseInt(String(b.quality || ""), 10) || 0;
    if (qa !== qb) return qb - qa;
    return (Number(b.bandwidth) || 0) - (Number(a.bandwidth) || 0);
  });
  return list[0];
}

/* ---------------- rede ---------------- */

function signalFor(ms) {
  return typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function"
    ? AbortSignal.timeout(ms)
    : undefined;
}

/* `status` 0 = não medido (rede/timeout); 404 = o player não tem o título. */
async function fetchPage(url, timeoutMs) {
  try {
    const res = await fetch(url, {
      headers: {
        Accept: "text/html,application/xhtml+xml",
        "User-Agent": config().userAgent,
      },
      // `referrer` (e não o cabeçalho Referer, que o fetch do Node descarta)
      referrer: `${config().siteUrl}/`,
      redirect: "follow",
      signal: signalFor(timeoutMs),
    });
    if (!res || !res.ok) {
      debug(`página HTTP ${(res && res.status) || 0} (${url})`);
      return { html: "", status: Number(res && res.status) || 0 };
    }
    return { html: await res.text(), status: res.status };
  } catch (err) {
    debug(`página falhou (${url}): ${String((err && err.message) || err)}`);
    return { html: "", status: 0 };
  }
}

async function fetchPlaylist(url, deadline) {
  const remaining = deadline - Date.now();
  if (remaining <= 250) return null;
  try {
    const res = await fetch(url, {
      headers: {
        Accept: "application/vnd.apple.mpegurl, application/x-mpegURL, */*",
        "User-Agent": config().userAgent,
      },
      signal: signalFor(Math.min(PLAYLIST_TIMEOUT_MS, remaining)),
    });
    if (!res || !res.ok) {
      debug(`playlist HTTP ${(res && res.status) || 0} (${hostOf(url)})`);
      return null;
    }
    return playlistInfo(await res.text());
  } catch (err) {
    debug(`playlist falhou (${hostOf(url)}): ${String((err && err.message) || err)}`);
    return null;
  }
}

/* Só entra o que comprova playlist com mídia: a URL é efêmera e, sem a sonda,
   o usuário receberia um item que gira para sempre. */
async function probeSource(source, deadline) {
  const url = String((source && source.url) || "").trim();
  if (!url) return null;

  const master = await fetchPlaylist(url, deadline);
  if (!master || master.dead) return null;

  const variant = bestVariant(master.variants);
  if (variant) {
    const variantUrl = absoluteUrl(variant.uri, url);
    if (!variantUrl) return null;
    const child = await fetchPlaylist(variantUrl, deadline);
    if (!child || child.dead) return null;
    if (!child.segments && !child.variants.length) return null;
    return {
      url,
      quality: variant.quality || qualityFromUrl(variantUrl) || "Auto",
      label: source.label,
      variants: master.variants.length,
    };
  }

  if (master.segments > 0) {
    return { url, quality: qualityFromUrl(url) || "Auto", label: source.label, variants: 0 };
  }
  return null;
}

function uniqueSources(sources) {
  const seen = Object.create(null);
  const out = [];
  for (const source of sources) {
    const isHls =
      source.type === "hls" ||
      /\.m3u8(?:[?#]|$)/i.test(source.url) ||
      /[?&]file=[^&]*\.m3u8/i.test(source.url);
    if (!isHls || seen[source.url]) continue;
    seen[source.url] = true;
    out.push(source);
  }
  return out;
}

/* ---------------- rotas de resolução ---------------- */

/* WatchPlay: além de rápido, é o único que declara o áudio. Devolve
   { audio, stream, status } — `audio` volta mesmo sem playlist, para a rota do
   megaembed herdar o idioma. */
async function watchplayAttempt(mediaType, tmdbId, season, episode, deadline) {
  const pageUrl = watchplayUrl(mediaType, tmdbId, season, episode);
  if (!pageUrl) return { audio: "", stream: null, status: 0 };

  const page = await fetchPage(pageUrl, WATCHPLAY_TIMEOUT_MS);
  if (!page.html) return { audio: "", stream: null, status: page.status };

  const ready = async (parsed, status) => {
    let stream = null;
    try {
      stream = await probeSource({ url: parsed.url, label: "WatchPlay", type: "hls" }, deadline);
    } catch {
      stream = null;
    }
    return { audio: parsed.audio, stream, status };
  };

  const parsed = parseWatchplayPage(page.html);
  if (parsed) return ready(parsed, page.status);

  // Ficha de escolha: segue `?player=N` na ordem da página até alguma entregar
  // playlist; o idioma da primeira que respondeu fica guardado.
  let audio = "";
  const choices = parseWatchplayChoices(page.html).slice(0, MAX_WATCHPLAY_CHOICES);
  for (const choice of choices) {
    if (Date.now() >= deadline - 500) break;
    const step = await fetchPage(`${pageUrl}?player=${choice}`, WATCHPLAY_TIMEOUT_MS);
    if (!step.html) continue;
    const stepParsed = parseWatchplayPage(step.html);
    if (!stepParsed) continue;
    const result = await ready(stepParsed, step.status);
    if (!audio) audio = result.audio;
    if (result.stream) return result;
  }
  return { audio, stream: null, status: page.status };
}

/* Ficha do servidor 2 (megaembed): a rota mais fraca, sem rótulo de áudio. */
async function megaembedStreams(mediaType, tmdbId, season, episode, deadline, audioHint) {
  const pageUrl = embedUrl(mediaType, tmdbId, season, episode);
  if (!pageUrl) return { rows: [], options: 0 };

  const page = await fetchPage(pageUrl, EMBED_TIMEOUT_MS);
  if (!page.html) return { rows: [], options: 0 };

  const sources = uniqueSources(parseSources(page.html));
  if (!sources.length) return { rows: [], options: 0 };

  const resolved = await Promise.all(
    sources.map((source) => probeSource(source, deadline).catch(() => null))
  );
  const working = resolved.filter(Boolean);
  working.sort((a, b) => (parseInt(b.quality, 10) || 0) - (parseInt(a.quality, 10) || 0));

  return {
    options: sources.length,
    rows: working.slice(0, MAX_STREAMS).map((row) => ({ ...row, audio: audioHint || "" })),
  };
}

async function resolveUncached(mediaType, tmdbId, season, episode) {
  const deadline = Date.now() + envNumber("PINGUIMCINEMA_WAIT_MS", DEFAULT_WAIT_MS) + 2500;
  const id = numeric(tmdbId);
  const notes = {};

  // WatchPlay primeiro: é o único que declara o áudio e responde em ~1 s.
  let attempt = { audio: "", stream: null, status: 0 };
  try {
    attempt = await watchplayAttempt(mediaType, id, season, episode, deadline);
  } catch (err) {
    debug(`watchplay falhou: ${String((err && err.message) || err)}`);
  }
  notes.watchplay = { status: attempt.status, audio: attempt.audio, stream: Boolean(attempt.stream) };

  if (attempt.stream) {
    return { rows: [{ ...attempt.stream, audio: attempt.audio || "", source: "watchplay" }], notes };
  }

  const embed = await megaembedStreams(mediaType, id, season, episode, deadline, attempt.audio || "");
  notes.embed = { options: embed.options, working: embed.rows.length };

  return {
    rows: embed.rows.map((row) => ({ ...row, source: "megaembed" })),
    notes,
  };
}

const resolveCache = new Map();
const resolvePending = new Map();

function resolveKey(mediaType, tmdbId, season, episode) {
  return `${kindOf(mediaType)}:${numeric(tmdbId)}:${numeric(season) || 1}:${numeric(episode) || 1}`;
}

/* Resolve com cache curto e sem pedidos duplicados: dois toques no mesmo título
   esperam a MESMA resolução. */
function resolve(mediaType, tmdbId, season, episode) {
  const key = resolveKey(mediaType, tmdbId, season, episode);
  const cached = resolveCache.get(key);
  if (cached && Date.now() < cached.expiresAt) {
    return Promise.resolve({ rows: cached.rows, notes: cached.notes, cached: true });
  }
  const running = resolvePending.get(key);
  if (running) return running;

  const task = (async () => {
    let state = { rows: [], notes: {} };
    try {
      state = await resolveUncached(mediaType, tmdbId, season, episode);
    } catch (err) {
      log(`falha ao resolver ${key}: ${String((err && err.message) || err)}`);
    }
    resolveCache.set(key, {
      rows: state.rows,
      notes: state.notes,
      expiresAt: Date.now() + (state.rows.length ? RESOLVE_TTL_MS : RESOLVE_FAILURE_TTL_MS),
    });
    return state;
  })();

  resolvePending.set(key, task);
  task.finally(() => resolvePending.delete(key));
  return task;
}

/* ---------------- API usada pelo server.js ---------------- */

function toStream(row, { base, viaProxy }) {
  // Com viaProxy a mídia sai pelo /proxy?url= DESTE servidor: a URL assinada foi
  // gerada para o IP dele, então quem toca é o mesmo cliente que pediu.
  let url = row.url;
  if (viaProxy && base) {
    const key = process.env.PROXY_SECRET ? `&key=${encodeURIComponent(process.env.PROXY_SECRET)}` : "";
    url = `${base}/proxy?url=${encodeURIComponent(row.url)}${key}`;
  }
  return {
    label: row.audio || PROVIDER,
    quality: row.quality || "",
    kind: "hls",
    url,
  };
}

/**
 * Resolve as fontes de um título para o site.
 * opts: { type, id, season, episode, waitMs, viaProxy, base }
 * Devolve { streams, debug } — debug sempre traz o que foi medido (tempo,
 * WatchPlay, megaembed) para diagnóstico no /pinguim?debug=1.
 */
async function getStreams(opts = {}) {
  const started = Date.now();
  const type = String(opts.type || "movie").toLowerCase();
  const id = numeric(opts.id || opts.tmdb);
  const season = numeric(opts.season) || 1;
  const episode = numeric(opts.episode) || 1;

  if (!id) return { streams: [], debug: { error: "id ausente", ms: 0 } };

  const waitMs = envNumber("PINGUIMCINEMA_WAIT_MS", DEFAULT_WAIT_MS);
  const viaProxy = opts.viaProxy != null ? Boolean(opts.viaProxy) : envFlag("PINGUIMCINEMA_VIA_PROXY");
  const task = resolve(type, id, season, episode);

  // Corrida contra o relógio do site: se estourar o orçamento, responde vazio
  // agora, mas a resolução continua e entra no cache para a próxima tentativa.
  const state = await Promise.race([
    task,
    delay(opts.waitMs || waitMs).then(() => null),
  ]);

  if (!state) {
    log(`sem resposta em ${opts.waitMs || waitMs} ms para ${resolveKey(type, id, season, episode)}; resolvendo em segundo plano`);
    return {
      streams: [],
      debug: { id, type, season, episode, ms: Date.now() - started, pending: true },
    };
  }

  const streams = state.rows.slice(0, MAX_STREAMS).map((row) =>
    toStream(row, { base: opts.base, viaProxy })
  );

  if (streams.length) {
    debug(
      `${resolveKey(type, id, season, episode)} → ${streams.length} fonte(s) em ${Date.now() - started} ms (${streams[0].quality || "?"}, ${streams[0].label})`
    );
  } else {
    log(`nada encontrado para ${resolveKey(type, id, season, episode)} em ${Date.now() - started} ms`);
  }

  return {
    streams,
    debug: {
      id,
      type,
      season,
      episode,
      ms: Date.now() - started,
      cached: Boolean(state.cached),
      notes: state.notes || {},
      viaProxy,
    },
  };
}

module.exports = {
  getStreams,
  info,
  _test: {
    parseWatchplayPage,
    parseWatchplayChoices,
    parseSources,
    playlistInfo,
    qualityFromInf,
    qualityFromUrl,
    bestVariant,
    uniqueSources,
    watchplayUrl,
    embedUrl,
    kindOf,
    resolveKey,
    resetCache() {
      resolveCache.clear();
      resolvePending.clear();
    },
  },
};
