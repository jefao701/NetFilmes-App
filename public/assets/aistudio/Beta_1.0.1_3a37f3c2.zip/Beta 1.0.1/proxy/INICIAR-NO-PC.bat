@echo off
title Proxy do Netfilmes
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js nao encontrado neste PC.
  echo  Instale a versao LTS em https://nodejs.org e abra este arquivo de novo.
  echo.
  pause
  exit /b 1
)

echo.
echo  ===========================================
echo   Proxy do Netfilmes - iniciando
echo  ===========================================
echo.
echo  Enderecos para testar no navegador:
echo    http://127.0.0.1:8787/health
echo    http://127.0.0.1:8787/pinguim?type=movie^&id=603^&debug=1
echo.
echo  Para PARAR: feche esta janela (ou aperte Ctrl+C).
echo.

node index.js

echo.
echo  O proxy parou. Veja a mensagem acima caso tenha dado erro.
pause
