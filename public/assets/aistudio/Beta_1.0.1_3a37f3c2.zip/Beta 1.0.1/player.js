/* ============================================================
   player.js — player próprio (controles customizados)
   ============================================================ */

const Player = (() => {
  const dom = {};
  const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];

  // Tempo máximo para uma fonte começar a tocar. Fonte travada não pode
  // segurar o player: depois disso ela conta como falha e a próxima entra.
  const START_TIMEOUT = 12000;
  // Fonte que já falhou no teste rápido ganha menos tempo: quase sempre é um
  // link que cai para HTTP e o navegador bloqueia em página HTTPS.
  const RETRY_TIMEOUT = 5000;
  const FALLBACK_DELAY = 900;

  // Pular abertura (heurística — fontes não enviam timestamps de intro)
  const SKIP_INTRO_FROM = 6;       // aparece a partir de ~6s
  const SKIP_INTRO_UNTIL = 95;     // some depois de ~95s
  const SKIP_INTRO_TO = 90;        // ao clicar, salta para ~90s
  const SKIP_INTRO_MIN_DUR = 480;  // só em vídeos > 8 min
  // Cartão "próximo episódio" um pouco antes do fim
  const NEXT_PROMPT_REMAINING = 50;

  // Teste rápido das fontes (só em página HTTPS). Um fetch "no-cors" não
  // deixa ler a resposta, mas mostra em ~100 ms se o link cai para HTTP —
  // o elemento de vídeo leva até 12 s para dar o mesmo erro. Assim o player
  // começa pela fonte que o navegador consegue abrir, em vez de gastar
  // minutos tentando uma por uma.
  const PROBE_TIMEOUT = 8000;
  const PROBE_WAIT = 4000;
  const PROBE_FAIL_LIMIT = 3;

  const state = {
    media: null,
    sources: [],
    index: 0,
    session: 0,
    attempt: 0,
    failed: new Set(),
    probes: new Map(),
    probeTries: 0,
    playStarted: false,
    startTimer: null,
    fallbackTimer: null,
    mediaErrorHandler: null,
    allFailed: false,
    hls: null,
    subs: [],
    subIndex: -1,
    menu: null,
    idleTimer: null,
    nextTimer: null,
    next: null,
    nextPrompting: false,
    skipIntroUsed: false,
    resumeAt: 0,
    lastSaved: 0,
    dragging: false,
  };

  let hlsLoading = null;
  let torrentPromise = null;
  let torrentClient = null;
  let torrentServer = null;
  let torrent = null;
  let torrentTimer = null;
  let torrentStats = null;
  const TORRENT_VIDEO_RE = /\.(mp4|m4v|webm|mkv|mov|avi|ogv)$/i;

  /* ---------------- inicialização ---------------- */

  function init() {
    const ids = [
      "player", "pv", "playerFrame", "playerTop", "pTitle", "pSubtitle", "pProvider",
      "playerCenter", "pSpinner", "pMessage", "pBigPlay", "playerNext", "pNextText",
      "pNextPlay", "pNextCancel", "pSkipIntro", "pControls", "pBar", "pBuffer", "pPlayed", "pPlay",
      "pBack10", "pFwd10", "pMute", "pVolume", "pTime", "pSubs", "pSpeed", "pSource",
      "pPip", "pFull", "pMenu", "pToast", "pBack", "pPreview", "pPreviewCanvas",
      "pPreviewTime",
    ];
    ids.forEach((id) => {
      const node = document.getElementById(id);
      if (node) dom[id] = node;
    });
    dom.root = dom.player;
    dom.frame = dom.playerFrame;
    dom.center = dom.playerCenter;
    dom.controls = dom.pControls;
    dom.spinner = dom.pSpinner;
    dom.message = dom.pMessage;
    dom.bigPlay = dom.pBigPlay;
    dom.next = dom.playerNext;
    dom.nextText = dom.pNextText;
    dom.nextPlay = dom.pNextPlay;
    dom.nextCancel = dom.pNextCancel;
    dom.skipIntro = dom.pSkipIntro;
    dom.bar = dom.pBar;
    dom.buffer = dom.pBuffer;
    dom.played = dom.pPlayed;
    dom.play = dom.pPlay;
    dom.back10 = dom.pBack10;
    dom.fwd10 = dom.pFwd10;
    dom.mute = dom.pMute;
    dom.volume = dom.pVolume;
    dom.time = dom.pTime;
    dom.subsBtn = dom.pSubs;
    dom.speedBtn = dom.pSpeed;
    dom.sourceBtn = dom.pSource;
    dom.pipBtn = dom.pPip;
    dom.fullBtn = dom.pFull;
    dom.menu = dom.pMenu;
    dom.toast = dom.pToast;
    dom.title = dom.pTitle;
    dom.subtitle = dom.pSubtitle;
    dom.provider = dom.pProvider;
    dom.preview = dom.pPreview;
    dom.previewCanvas = dom.pPreviewCanvas;
    dom.previewTime = dom.pPreviewTime;
    dom.previewCtx = dom.pPreviewCanvas ? dom.pPreviewCanvas.getContext("2d") : null;

    bindEvents();
  }

  function bindEvents() {
    dom.root.addEventListener("mousemove", showControls);
    dom.root.addEventListener("pointerdown", showControls);

    dom.pBack.addEventListener("click", close);
    dom.play.addEventListener("click", togglePlay);
    dom.bigPlay.addEventListener("click", () => {
      if (dom.pv.ended) dom.pv.currentTime = 0;
      dom.pv.play().catch(() => {});
    });
    dom.back10.addEventListener("click", () => seekBy(-10));
    dom.fwd10.addEventListener("click", () => seekBy(10));
    dom.mute.addEventListener("click", toggleMute);
    dom.volume.addEventListener("input", () => setVolume(Number(dom.volume.value)));
    dom.subsBtn.addEventListener("click", () => openMenu("subs"));
    dom.speedBtn.addEventListener("click", () => openMenu("speed"));
    dom.sourceBtn.addEventListener("click", () => openMenu("source"));
    dom.pipBtn.addEventListener("click", togglePip);
    dom.fullBtn.addEventListener("click", toggleFullscreen);
    dom.nextPlay.addEventListener("click", goNext);
    dom.nextCancel.addEventListener("click", clearNext);
    if (dom.skipIntro) dom.skipIntro.addEventListener("click", skipIntro);

    dom.bar.addEventListener("pointerdown", (e) => {
      state.dragging = true;
      dom.bar.setPointerCapture?.(e.pointerId);
      seekFromEvent(e);
    });
    dom.bar.addEventListener("pointermove", (e) => {
      if (state.dragging) seekFromEvent(e);
    });
    dom.bar.addEventListener("pointerup", () => {
      state.dragging = false;
      showControls();
    });
    dom.bar.addEventListener("pointercancel", () => {
      state.dragging = false;
    });

    dom.bar.addEventListener("pointermove", showPreviewAt);
    dom.bar.addEventListener("pointerleave", hidePreview);

    const video = dom.pv;
    video.addEventListener("loadedmetadata", onLoadedMetadata);
    video.addEventListener("timeupdate", () => {
      updateBar();
      maybeSave();
      updateSkipIntro();
      maybePromptNext();
    });
    video.addEventListener("durationchange", updateBar);
    video.addEventListener("progress", updateBar);
    video.addEventListener("waiting", () => showSpinner(true));
    video.addEventListener("playing", () => {
      clearPlaybackTimers();
      state.allFailed = false;
      showSpinner(false);
      dom.bigPlay.classList.add("hidden");
      dom.play.textContent = "❚❚";
      hideMessage();
      showControls();
    });
    video.addEventListener("pause", () => {
      dom.play.textContent = "▶";
      showControls();
      if (state.media) saveNow();
    });
    video.addEventListener("play", () => {
      dom.play.textContent = "❚❚";
    });
    video.addEventListener("canplay", () => {
      clearPlaybackTimers();
      showSpinner(false);
    });
    video.addEventListener("ended", handleEnded);
    video.addEventListener("volumechange", syncVolumeUI);

    document.addEventListener("keydown", onKeydown);
    document.addEventListener("fullscreenchange", () => {
      dom.fullBtn.textContent = document.fullscreenElement ? "⤡" : "⛶";
    });
  }

  /* ---------------- abrir / fechar ---------------- */

  async function open(media, opts = {}) {
    if (!dom.root) init();
    const session = ++state.session;

    state.attempt += 1;
    clearPlaybackTimers();
    clearNext();
    hideSkipIntro();
    detachMedia();
    resetProgressState();

    state.media = { ...media };
    state.sources = [];
    state.index = 0;
    state.failed = new Set();
    state.probes = new Map();
    state.probeTries = 0;
    state.playStarted = false;
    state.allFailed = false;
    state.nextPrompting = false;
    state.skipIntroUsed = false;
    state.resumeAt = 0;
    state.lastSaved = 0;
    state.subs = [];
    state.subIndex = -1;

    dom.root.classList.remove("hidden", "controls-hidden");
    dom.root.setAttribute("aria-hidden", "false");
    document.body.classList.add("player-open");

    setHeading(state.media);
    dom.provider.textContent = "";
    dom.menu.classList.add("hidden");
    dom.next.classList.add("hidden");
    dom.bigPlay.classList.add("hidden");
    dom.play.textContent = "▶";
    dom.time.textContent = "0:00 / 0:00";
    dom.played.style.width = "0%";
    dom.buffer.style.width = "0%";
    dom.center.classList.remove("hidden");
    hideMessage();
    showSpinner(true);
    showControls();

    const saved = getProgress(state.media);
    state.resumeAt = saved ? saved.position : 0;

    let sources = opts.sourcesOverride;
    // Começa a tocar assim que a primeira fonte aparecer (não espera o
    // addon mais lento): o resto chega depois e completa o menu de fontes.
    let started = false;

    if (!sources) {
      try {
        sources = await resolveStreams(state.media, {
          onSources: (partial) => {
            if (started || session !== state.session) return;
            started = true;
            state.sources = partial;
            state.index = 0;
            updateSourceLabel();
            startPlayback(session);
          },
        });
      } catch (err) {
        console.warn("[player] fontes:", err);
        sources = [];
      }
    }
    if (session !== state.session) return;

    if (started) {
      // Mantém tocando a fonte atual e só atualiza a lista completa
      const current = state.sources[state.index];
      const rest = sources.filter(
        (src) => !current || src.kind !== current.kind || src.url !== current.url
      );
      state.sources = current ? [current, ...rest] : sources;
      state.index = 0;
      updateSourceLabel();
      // Fontes que chegaram depois também entram no teste rápido.
      startProbing();

      // Se todas as fontes conhecidas falharam enquanto os outros addons
      // ainda respondiam, as que acabaram de chegar merecem uma chance.
      if (state.allFailed) {
        const retry = findNextSource();
        if (retry >= 0) {
          hideMessage();
          playSourceAt(retry);
        }
      }
      return;
    }

    state.sources = sources;
    state.index = 0;
    updateSourceLabel();

    if (!state.sources.length) {
      showSpinner(false);
      await showUnavailable(state.media, session);
      return;
    }

    startPlayback(session);
  }

  async function openTrailer(media) {
    const trailer = await findTrailer(media).catch(() => null);
    if (!trailer) {
      document.dispatchEvent(new CustomEvent("app:toast", { detail: { message: "Nenhum trailer disponível para este título." } }));
      return;
    }
    open(media, {
      sourcesOverride: [
        {
          label: "Trailer oficial",
          kind: "youtube",
          url: trailer.key,
          provider: "TMDB",
          subtitles: [],
        },
      ],
    });
  }

  function close() {
    if (!dom.root || dom.root.classList.contains("hidden")) return;
    saveNow();
    clearNext();
    hideSkipIntro();
    state.session += 1;
    state.attempt += 1;
    clearPlaybackTimers();
    detachMedia();
    dom.root.classList.add("hidden");
    dom.root.setAttribute("aria-hidden", "true");
    document.body.classList.remove("player-open");
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    dom.menu.classList.add("hidden");
    state.menu = null;
    state.media = null;
    state.sources = [];
    state.failed = new Set();
    state.allFailed = false;
    document.dispatchEvent(new CustomEvent("player:closed"));
  }

  function resetProgressState() {
    if (state.idleTimer) clearTimeout(state.idleTimer);
    state.idleTimer = null;
  }

  /* ---------------- título / estado ---------------- */

  function setHeading(media) {
    dom.title.textContent = media.title || "";
    const parts = [];
    if (media.type === "tv") parts.push(`T${media.season || 1}E${media.episode || 1}`);
    if (media.episodeTitle) parts.push(media.episodeTitle);
    if (media.year) parts.push(media.year);
    dom.subtitle.textContent = parts.join(" · ");
  }

  function updateSourceLabel() {
    const src = state.sources[state.index];
    dom.provider.textContent = src ? src.provider || "" : "";
    dom.sourceBtn.classList.toggle("active-opt", state.sources.length > 1);
    dom.subsBtn.disabled = !state.subs.length;
    dom.pipBtn.disabled = !document.pictureInPictureEnabled;
  }

  /* ---------------- falha de uma fonte / próxima fonte ----------------
     O navegador não consegue tocar tudo o que o Stremio toca (link HTTP
     em site HTTPS, cabeçalho exigido, MKV/HEVC). Em vez de parar na
     primeira fonte, o player registra a falha e tenta a próxima sozinho. */

  function srcKey(src) {
    return src ? `${src.kind || ""}|${src.url || src.magnet || ""}` : "";
  }

  function srcName(src) {
    const label = String((src && (src.label || src.provider)) || "Fonte")
      .replace(/\s+/g, " ")
      .trim();
    return label.length > 54 ? `${label.slice(0, 51)}…` : label;
  }

  /* ---------------- teste rápido das fontes ----------------
     Em página HTTPS, um link que redireciona para HTTP é bloqueado pelo
     navegador (conteúdo misto). O elemento de vídeo demora até 12 s para
     avisar; já um fetch "no-cors" falha em milissegundos — e um fetch que
     responde, mesmo opaco, garante que o servidor é alcançável por HTTPS.
     Nada do vídeo é baixado: o corpo é abortado assim que a resposta chega. */

  function pageIsHttps() {
    return typeof location !== "undefined" && location.protocol === "https:";
  }

  function canProbe(src) {
    if (!src || !src.url || !/^https?:/i.test(src.url)) return false;
    return !["torrent", "dash", "youtube", "embed"].includes(src.kind);
  }

  /** Em página HTTPS, link http:// puro é bloqueado (conteúdo misto). */
  function isMixedContentBlocked(src) {
    if (!pageIsHttps() || !src || !src.url) return false;
    return /^http:\/\//i.test(src.url);
  }

  /** Normaliza URL de stream (espaços, barras extras). */
  function normalizeStreamUrl(raw) {
    const s = String(raw || "").trim();
    if (!s || /^magnet:/i.test(s)) return s;
    try {
      // new URL corrige encoding básico; mantém query
      return new URL(s).href;
    } catch {
      return s.replace(/ /g, "%20");
    }
  }

  function isAlreadyProxied(url) {
    const u = String(url || "");
    // /file?p= é o acervo local do próprio servidor: não faz sentido mandar
    // o proxy buscar de novo o que ele mesmo está servindo.
    return (
      /\/proxy\?/i.test(u) ||
      /\/file\?p=/i.test(u) ||
      (/[?&]url=/.test(u) && /proxy/i.test(u))
    );
  }

  function wrapWithProxy(rawUrl, headers) {
    const proxy =
      typeof STREAM_PROXY === "string" && STREAM_PROXY.trim() ? STREAM_PROXY.trim() : "";
    if (!proxy || !rawUrl || isAlreadyProxied(rawUrl)) return rawUrl;
    let out;
    if (proxy.endsWith("=") || proxy.endsWith("?")) out = proxy + encodeURIComponent(rawUrl);
    else out = proxy.replace(/\/?$/, "/") + encodeURIComponent(rawUrl);
    if (headers && typeof headers === "object" && Object.keys(headers).length) {
      try {
        const json = JSON.stringify(headers);
        const b64 = btoa(unescape(encodeURIComponent(json)))
          .replace(/\+/g, "-")
          .replace(/\//g, "_")
          .replace(/=+$/, "");
        out += (out.includes("?") ? "&" : "?") + "h=" + b64;
      } catch {
        /* noop */
      }
    }
    return out;
  }

  function looksProgressiveFile(url) {
    const u = String(url || "");
    // .mp4 / .m4v / video.mp4 em qualquer ponto do caminho (antes de ? # / fim)
    return (
      /\.(mp4|m4v|webm|mov|mkv|avi|ts)(?=([?#]|$|\/))/i.test(u) ||
      /\/video\.mp4(?=([?#]|$|\/))/i.test(u) ||
      /[?&](?:file|name|path|url)=[^&]*\.mp4\b/i.test(u)
    );
  }

  /**
   * URL final enviada ao player.
   * Com STREAM_PROXY: MP4/arquivo progressivo passa pelo proxy (Referer/CORS).
   */
  function resolvePlayUrl(src, { forceProxy = false } = {}) {
    const raw = normalizeStreamUrl(src && src.url ? src.url : "");
    if (!raw || /^magnet:/i.test(raw)) return raw;
    const proxy =
      typeof STREAM_PROXY === "string" && STREAM_PROXY.trim() ? STREAM_PROXY.trim() : "";
    if (!proxy) return raw;
    if (isAlreadyProxied(raw)) return raw;

    const always =
      typeof STREAM_PROXY_ALWAYS !== "undefined" && STREAM_PROXY_ALWAYS === true;
    const hasHeaders = src.proxyHeaders && Object.keys(src.proxyHeaders).length > 0;
    const progressive =
      looksProgressiveFile(raw) ||
      src.kind === "mp4" ||
      src.kind === "mkv" ||
      src.kind === "webm";
    const needsProxy =
      forceProxy ||
      always ||
      isMixedContentBlocked(src) ||
      src.notWebReady ||
      hasHeaders ||
      progressive;
    if (!needsProxy) return raw;
    return wrapWithProxy(raw, src.proxyHeaders || null);
  }

  function probeState(src) {
    const entry = state.probes.get(srcKey(src));
    return entry ? entry.state : "unknown";
  }

  function probeSource(src) {
    const key = srcKey(src);
    const cached = state.probes.get(key);
    if (cached) return cached.promise;

    const entry = { state: "pending", promise: null };
    entry.promise = new Promise((resolve) => {
      const controller = new AbortController();
      const finish = (result) => {
        clearTimeout(timer);
        entry.state = result;
        resolve(result);
      };
      const timer = setTimeout(() => {
        try {
          controller.abort();
        } catch {
          /* noop */
        }
        finish("unknown");
      }, PROBE_TIMEOUT);

      fetch(src.url, { mode: "no-cors", signal: controller.signal })
        .then(() => {
          try {
            controller.abort();
          } catch {
            /* noop */
          }
          finish("ok");
        })
        .catch(() => finish("fail"));
    });
    state.probes.set(key, entry);
    return entry.promise;
  }

  // Só vale a pena testar quando há mais de uma fonte: com uma só, o teste
  // atrasaria o início sem ter para onde trocar.
  function startProbing() {
    if (!pageIsHttps()) return false;
    const list = state.sources.filter(canProbe);
    if (list.length < 2) return false;
    list.forEach((src) => probeSource(src));
    return true;
  }

  // Espera a primeira fonte que responder por HTTPS (ou desiste no prazo).
  function waitForProbe(ms) {
    const pending = state.sources.filter(canProbe).map((src) => probeSource(src));
    if (!pending.length) return Promise.resolve(-1);

    return new Promise((resolve) => {
      let done = false;
      let left = pending.length;
      const finish = (index) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        resolve(index);
      };
      const timer = setTimeout(() => finish(-1), ms);

      pending.forEach((promise) => {
        promise.then((result) => {
          left -= 1;
          if (result === "ok") {
            // Mantém a ordem do addon: a primeira que já respondeu bem.
            finish(state.sources.findIndex((src) => probeState(src) === "ok"));
          } else if (left <= 0) {
            finish(-1);
          }
        });
      });
    });
  }

  function startPlayback(session) {
    if (state.playStarted) return;
    if (!startProbing()) {
      playSourceAt(0);
      return;
    }
    waitForProbe(PROBE_WAIT).then((index) => {
      if (session !== state.session || state.playStarted) return;
      playSourceAt(index >= 0 ? index : 0);
    });
  }

  function clearPlaybackTimers() {
    if (state.startTimer) {
      clearTimeout(state.startTimer);
      state.startTimer = null;
    }
    if (state.fallbackTimer) {
      clearTimeout(state.fallbackTimer);
      state.fallbackTimer = null;
    }
  }

  function removeMediaErrorWatcher() {
    if (state.mediaErrorHandler) {
      dom.pv.removeEventListener("error", state.mediaErrorHandler);
      state.mediaErrorHandler = null;
    }
  }

  function watchMediaError(attempt, src) {
    removeMediaErrorWatcher();
    const handler = () => {
      if (attempt !== state.attempt) return;
      // Em HLS o hls.js trata o erro e dispara o evento dele; aqui só
      // interessa erro de rede do próprio elemento de vídeo.
      if (state.hls) return;
      const mediaError = dom.pv.error;
      if (!mediaError || mediaError.code === 1) return;
      handleSourceFailure(mediaErrorMessage(mediaError.code), src, attempt);
    };
    state.mediaErrorHandler = handler;
    dom.pv.addEventListener("error", handler);
  }

  function armStartTimer(attempt, src, timeout = START_TIMEOUT) {
    if (state.startTimer) clearTimeout(state.startTimer);
    state.startTimer = setTimeout(() => {
      if (attempt !== state.attempt) return;
      handleSourceFailure(
        `A fonte demorou mais de ${Math.round(timeout / 1000)}s para começar.`,
        src,
        attempt
      );
    }, timeout);
  }

  function mediaErrorMessage(code) {
    switch (code) {
      case 2:
        return "A conexão com o servidor da fonte falhou.";
      case 3:
        return "O navegador não conseguiu decodificar o vídeo (codec não suportado).";
      case 4:
        return "O navegador não conseguiu abrir o arquivo: link fora do ar, redirecionamento para HTTP (bloqueado em página HTTPS) ou formato não suportado.";
      default:
        return "Não foi possível reproduzir esta fonte.";
    }
  }

  function findNextSource() {
    const total = state.sources.length;
    if (total < 2) return -1;

    // Já tentamos fontes que o teste reprovou? Então não vale a pena gastar
    // 15 s em cada restante: quase todas caem para HTTP e ficam bloqueadas.
    const skipProbeFailed = state.probeTries >= PROBE_FAIL_LIMIT;

    let best = -1;
    let bestScore = Infinity;
    for (let step = 1; step < total; step++) {
      const i = (state.index + step) % total;
      const src = state.sources[i];
      if (!src || state.failed.has(srcKey(src))) continue;
      // Torrent e DASH não entram no pulo automático: torrent pode levar
      // 25s e DASH o player não abre. O usuário escolhe no menu "Fonte".
      if (src.kind === "torrent" || src.kind === "dash") continue;

      const probe = probeState(src);
      if (skipProbeFailed && probe === "fail") continue;

      // Respondeu por HTTPS (0) > ainda testando (1) > só HTTP (2);
      // fontes que exigem cabeçalho (notWebReady) ficam por último.
      const score = (probe === "ok" ? 0 : probe === "fail" ? 2 : 1) + (src.notWebReady ? 3 : 0);
      if (score < bestScore) {
        best = i;
        bestScore = score;
      }
    }
    return best;
  }

  function handleSourceFailure(reason, src, attempt) {
    if (attempt != null && attempt !== state.attempt) return;

    clearPlaybackTimers();
    removeMediaErrorWatcher();
    state.attempt += 1;
    detachHls();
    try {
      dom.pv.pause();
    } catch {
      /* noop */
    }

    // Arquivo progressivo falhou e há proxy: tenta uma vez via STREAM_PROXY
    const hasProxy =
      typeof STREAM_PROXY === "string" && STREAM_PROXY.trim().length > 0;
    const looksDirect =
      src &&
      src.url &&
      /^https?:/i.test(src.url) &&
      !isAlreadyProxied(src.url) &&
      !src._proxyRetry &&
      (src.kind === "mp4" ||
        src.kind === "mkv" ||
        looksProgressiveFile(src.url) ||
        !/\.m3u8/i.test(src.url || ""));

    if (hasProxy && looksDirect && src.kind !== "youtube" && src.kind !== "embed" && src.kind !== "torrent") {
      showToast("Tentando de novo pelo proxy…", 2200);
      const session = state.session;
      const idx = state.sources.findIndex((s) => srcKey(s) === srcKey(src));
      const proxied = { ...src, _proxyRetry: true };
      if (idx >= 0) state.sources[idx] = proxied;
      state.fallbackTimer = setTimeout(() => {
        if (session !== state.session) return;
        playSourceAt(idx >= 0 ? idx : state.index);
      }, 400);
      return;
    }

    if (src) state.failed.add(srcKey(src));

    if (findNextSource() >= 0) {
      dom.bigPlay.classList.add("hidden");
      showToast(`${srcName(src)} não abriu. Tentando outra fonte…`, 2800);
      const session = state.session;
      state.fallbackTimer = setTimeout(() => {
        if (session !== state.session) return;
        const next = findNextSource();
        if (next >= 0) playSourceAt(next);
        else showPlaybackError(reason, src);
      }, FALLBACK_DELAY);
      return;
    }

    showPlaybackError(reason, src);
  }

  async function showUnavailable(media, session) {
    const trailer = await findTrailer(media).catch(() => null);
    if (session !== state.session) return;

    const episode = media.type === "tv" ? ` (T${media.season || 1}E${media.episode || 1})` : "";
    showMessage(
      `<div class="p-empty">
        <h2>Nenhuma fonte disponível</h2>
        <p>Adicione uma fonte de vídeo para <strong>${esc(media.title)}</strong>${episode} ou configure um addon em “Fontes de vídeo”.</p>
        <div class="p-empty-actions">
          ${trailer ? '<button class="btn btn-play" data-act="trailer">▶ Ver trailer oficial</button>' : ""}
          <button class="btn btn-info" data-act="add">＋ Adicionar fonte</button>
          <button class="btn btn-info" data-act="manage">⚙ Gerenciar addons</button>
        </div>
      </div>`,
      {
        trailer: () => {
          state.sources = [
            { label: "Trailer oficial", kind: "youtube", url: trailer.key, provider: "TMDB", subtitles: [] },
          ];
          updateSourceLabel();
          hideMessage();
          playSourceAt(0);
        },
        add: () => {
          close();
          document.dispatchEvent(new CustomEvent("player:add-source", { detail: { media } }));
        },
        manage: () => {
          close();
          document.dispatchEvent(new CustomEvent("player:open-sources"));
        },
      }
    );
  }

  function showMessage(html, actions = {}) {
    dom.message.innerHTML = html;
    dom.message.classList.remove("hidden");
    Object.entries(actions).forEach(([name, handler]) => {
      dom.message.querySelector(`[data-act="${name}"]`)?.addEventListener("click", handler);
    });
  }

  function hideMessage() {
    dom.message.classList.add("hidden");
    dom.message.innerHTML = "";
  }

  function showSpinner(show) {
    dom.spinner.classList.toggle("hidden", !show);
  }

  function showToast(text, ms = 2600) {
    dom.toast.textContent = text;
    dom.toast.classList.remove("hidden");
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => dom.toast.classList.add("hidden"), ms);
  }

  /* ---------------- fontes ---------------- */

  async function playSourceAt(index) {
    const src = state.sources[index];
    if (!src) return;

    // Ao trocar de fonte, guarda onde estava para retomar na nova.
    // (resumeAt é consumido em onLoadedMetadata.)
    try {
      const t = dom.pv && dom.pv.currentTime;
      if (isFinite(t) && t > 5) {
        state.resumeAt = t;
        if (state.media) {
          const d = dom.pv.duration;
          if (isFinite(d) && d > 30) {
            saveProgress(state.media, t, d);
            state.lastSaved = t;
          }
        }
      } else if (!(state.resumeAt > 5) && state.media) {
        const saved = getProgress(state.media);
        if (saved && saved.position > 5) state.resumeAt = saved.position;
      }
    } catch {
      /* noop */
    }

    const session = state.session;
    const attempt = ++state.attempt;
    clearPlaybackTimers();

    state.index = index;
    state.allFailed = false;
    state.playStarted = true;
    if (probeState(src) === "fail") state.probeTries += 1;
    else state.probeTries = 0;
    detachMedia();
    hideMessage();
    showSpinner(true);
    dom.bigPlay.classList.add("hidden");
    dom.next.classList.add("hidden");
    clearNext();
    updateSourceLabel();

    if (src.kind === "youtube" || src.kind === "embed") {
      showSpinner(false);
      showFrame(src);
      return;
    }

    if (src.kind === "torrent") {
      playTorrent(src);
      return;
    }

    if (src.kind === "dash") {
      showSpinner(false);
      showMessage(
        `<div class="p-empty"><h2>Formato DASH</h2><p>Esta fonte usa <code>.mpd</code>, que este player não reproduz. Use HLS (.m3u8) ou MP4.</p></div>`
      );
      return;
    }

    dom.pv.classList.remove("hidden");
    dom.frame.classList.add("hidden");
    dom.controls.classList.remove("hidden");
    dom.center.classList.remove("hidden");
    renderSubtitles(src.subtitles || []);
    updateSourceLabel();

    // HTTP em página HTTPS sem proxy: o navegador bloqueia — não vale esperar 12s.
    const hasProxy =
      typeof STREAM_PROXY === "string" && STREAM_PROXY.trim().length > 0;
    if (isMixedContentBlocked(src) && !hasProxy) {
      handleSourceFailure(
        "Esta fonte usa HTTP e o site está em HTTPS: o navegador bloqueia (conteúdo misto). Configure o proxy Node (STREAM_PROXY).",
        src,
        attempt
      );
      return;
    }

    const forceProxy = Boolean(src._proxyRetry);
    const url = resolvePlayUrl(src, { forceProxy });
    const isHls =
      src.kind === "hls" || /\.m3u8(?=([?#]|$|\/))/i.test(src.url || url || "");
    const isMp4 =
      src.kind === "mp4" ||
      looksProgressiveFile(src.url || "") ||
      looksProgressiveFile(url);

    watchMediaError(attempt, src);
    const quickFail =
      probeState(src) === "fail" || src.notWebReady || isMixedContentBlocked(src);
    // MP4 / arquivo progressivo: mais tempo (CDN lenta, proxy, Range)
    armStartTimer(
      attempt,
      src,
      quickFail ? RETRY_TIMEOUT : isMp4 ? Math.max(START_TIMEOUT, 25000) : START_TIMEOUT
    );

    if (isHls && !dom.pv.canPlayType("application/vnd.apple.mpegurl")) {
      try {
        const Hls = await loadHls();
        if (session !== state.session || attempt !== state.attempt) return;
        if (!Hls || !Hls.isSupported()) throw new Error("HLS não é suportado neste navegador.");
        detachHls();
        const headers = src.proxyHeaders || null;
        const hls = new Hls({
          enableWorker: true,
          xhrSetup: headers
            ? (xhr) => {
                try {
                  Object.entries(headers).forEach(([key, value]) => {
                    if (key && value != null) xhr.setRequestHeader(String(key), String(value));
                  });
                } catch {
                  /* alguns headers são proibidos no XHR do navegador */
                }
              }
            : undefined,
        });
        state.hls = hls;
        let retries = 0;
        hls.on(Hls.Events.ERROR, (_evt, data) => {
          if (attempt !== state.attempt || !data || !data.fatal) return;
          if (data.type === Hls.ErrorTypes.NETWORK_ERROR && retries < 2) {
            retries += 1;
            setTimeout(() => {
              if (attempt === state.attempt) hls.startLoad();
            }, 700);
            return;
          }
          if (data.type === Hls.ErrorTypes.MEDIA_ERROR && retries < 2) {
            retries += 1;
            hls.recoverMediaError();
            return;
          }
          handleSourceFailure(`Falha no HLS (${data.details || data.type}).`, src, attempt);
        });
        hls.loadSource(url);
        hls.attachMedia(dom.pv);
      } catch (err) {
        if (session !== state.session || attempt !== state.attempt) return;
        handleSourceFailure(`Não foi possível abrir o HLS: ${err.message}`, src, attempt);
        return;
      }
    } else {
      // Progressive (MP4 etc.): src direto — mais compatível que <source> sozinho
      try {
        dom.pv.removeAttribute("crossorigin");
      } catch {
        /* noop */
      }
      try {
        while (dom.pv.firstChild) dom.pv.removeChild(dom.pv.firstChild);
      } catch {
        /* noop */
      }

      dom.pv.preload = "auto";
      // type="video/mp4" via atributo não existe no video; usamos src + load
      dom.pv.src = url;
      try {
        dom.pv.load();
      } catch {
        /* noop */
      }

      // Se o play() imediato falhar por "not ready", tenta de novo no canplay
      const tryPlay = () => {
        if (session !== state.session || attempt !== state.attempt) return;
        dom.pv.play().catch(() => {
          if (session !== state.session || attempt !== state.attempt) return;
          showSpinner(false);
          dom.bigPlay.classList.remove("hidden");
        });
      };
      if (dom.pv.readyState >= 2) tryPlay();
      else {
        const onCanPlay = () => {
          dom.pv.removeEventListener("canplay", onCanPlay);
          tryPlay();
        };
        dom.pv.addEventListener("canplay", onCanPlay, { once: true });
        // fallback: ainda tenta play (alguns browsers precisam do gesto)
        tryPlay();
      }

      setMediaSession();
      return;
    }

    setMediaSession();

    try {
      const promise = dom.pv.play();
      if (promise) {
        await promise.catch(() => {
          if (session !== state.session || attempt !== state.attempt) return;
          showSpinner(false);
          dom.bigPlay.classList.remove("hidden");
        });
      }
    } catch {
      if (session !== state.session || attempt !== state.attempt) return;
      showSpinner(false);
      dom.bigPlay.classList.remove("hidden");
    }
  }

  /* ---------------- torrents (WebTorrent) ----------------
     O navegador só alcança peers WebRTC (trackers wss://) e webseeds HTTP.
     Sem peer, não há como baixar os pedaços — P2P não funciona sozinho. */

  async function loadWebTorrent() {
    if (torrentPromise) return torrentPromise;

    torrentPromise = (async () => {
      const urls =
        typeof WEBTORRENT_CDNS !== "undefined" &&
        Array.isArray(WEBTORRENT_CDNS) &&
        WEBTORRENT_CDNS.length
          ? WEBTORRENT_CDNS
          : ["https://cdn.jsdelivr.net/npm/webtorrent@2/dist/webtorrent.min.js"];

      let lastError = null;
      for (const url of urls) {
        try {
          const mod = await import(url);
          const WT = mod.default || mod;
          if (typeof WT === "function") return WT;
        } catch (err) {
          lastError = err;
        }
      }
      throw lastError || new Error("biblioteca indisponível");
    })().catch((err) => {
      torrentPromise = null;
      throw err;
    });

    return torrentPromise;
  }

  function getTorrentClient(WebTorrent) {
    if (torrentClient && !torrentClient.destroyed) return torrentClient;
    torrentClient = new WebTorrent();
    return torrentClient;
  }

  function stopTorrentStats() {
    if (torrentStats) {
      clearInterval(torrentStats);
      torrentStats = null;
    }
  }

  function fmtRate(bytes) {
    let value = Number(bytes) || 0;
    if (value < 1024) return `${Math.round(value)} B/s`;
    const units = ["KB/s", "MB/s", "GB/s"];
    let index = -1;
    do {
      value /= 1024;
      index += 1;
    } while (value >= 1024 && index < units.length - 1);
    return `${value.toFixed(value < 10 ? 1 : 0)} ${units[index]}`;
  }

  /* Como no Stremio Web: enquanto conecta, mostra peers, velocidade e
     quanto já baixou — em vez de uma tela parada por 25 segundos. */
  function startTorrentStats(torrentRef, session) {
    stopTorrentStats();
    const draw = () => {
      if (!torrentRef || session !== state.session) return stopTorrentStats();
      const peers = torrentRef.numPeers || 0;
      const percent = ((torrentRef.progress || 0) * 100).toFixed(1);
      showMessage(
        `<div class="p-empty">
          <h2>Conectando ao torrent…</h2>
          <p>${peers} peer${peers === 1 ? "" : "s"} · ${fmtRate(
            torrentRef.downloadSpeed
          )} · ${percent}%</p>
          <p class="p-note">O navegador só alcança peers WebRTC (trackers <code>wss://</code>) e webseeds HTTP. Seeds comuns (TCP/UDP) não são visíveis daqui.</p>
        </div>`
      );
    };
    draw();
    torrentStats = setInterval(draw, 1000);
  }

  function destroyTorrent() {
    torrentServer = null;
    stopTorrentStats();
    if (torrentTimer) {
      clearTimeout(torrentTimer);
      torrentTimer = null;
    }
    if (torrent) {
      try {
        torrent.destroy();
      } catch {
        /* noop */
      }
      torrent = null;
    }
    if (torrentClient) {
      try {
        torrentClient.destroy();
      } catch {
        /* noop */
      }
      torrentClient = null;
    }
  }

  function pickTorrentFile(t, fileIdx) {
    const files = (t.files || []).filter((file) => file && file.length > 0);
    if (!files.length) return null;
    if (Number.isInteger(fileIdx) && files[fileIdx]) return files[fileIdx];

    const videos = files.filter(
      (file) => /^video\//i.test(file.type || "") || TORRENT_VIDEO_RE.test(file.name || "")
    );
    const list = videos.length ? videos : files;
    return list.slice().sort((a, b) => b.length - a.length)[0];
  }

  function showTorrentError(text) {
    showSpinner(false);
    const hasGateway = Boolean(torrentProxyBase());
    const note = hasGateway
      ? "O gateway do servidor não aceitou este magnet. Tente outra fonte (HTTP/HLS) no menu Fonte."
      : "No navegador, torrent só funciona com peers WebRTC (wss) ou webseed HTTP. Para seeds normais (UDP/TCP), publique o proxy Node e configure <code>STREAM_PROXY</code> no config.js.";
    showMessage(
      `<div class="p-empty">
        <h2>Torrent não abriu</h2>
        <p>${esc(text)}</p>
        <p class="p-note">${note}</p>
        <div class="p-empty-actions">
          <button class="btn btn-info" data-act="sources">⚙ Trocar de fonte</button>
        </div>
      </div>`,
      {
        sources: () => openMenu("source"),
      }
    );
  }

  /* O WebTorrent transmite pelo service worker (webtorrent-sw.js): sem ele
     `file.streamTo` não tem servidor e não toca nada. */
  async function ensureTorrentServer(client) {
    if (!("serviceWorker" in navigator)) return null;
    if (torrentServer) return torrentServer;

    try {
      let registration = await navigator.serviceWorker.getRegistration();
      if (!registration) {
        registration = await navigator.serviceWorker.register("webtorrent-sw.js");
      }
      await navigator.serviceWorker.ready;

      // O novo worker assume a página no activate (clients.claim), mas leva
      // alguns instantes: espera até 2s pelo controller antes de desistir.
      let controller = navigator.serviceWorker.controller;
      for (let i = 0; i < 10 && !controller; i++) {
        await new Promise((resolve) => setTimeout(resolve, 200));
        controller = navigator.serviceWorker.controller;
      }
      if (!controller) return null;

      torrentServer = client.createServer({ controller });
      return torrentServer;
    } catch (err) {
      console.warn("[player] torrent server:", err);
      return null;
    }
  }

  async function attachTorrentFile(file, client) {
    const video = dom.pv;

    const server = await ensureTorrentServer(client);
    if (server) {
      try {
        file.streamTo(video);
        return true;
      } catch (err) {
        console.warn("[player] torrent stream:", err);
      }
    }

    if (file.length > 900 * 1024 * 1024) {
      showTorrentError(
        "Sem o streaming por service worker, só dá para baixar arquivos até ~900 MB. Verifique se o webtorrent-sw.js está publicado na mesma pasta do site."
      );
      return false;
    }

    showMessage(
      `<div class="p-empty">
        <h2>Baixando do torrent…</h2>
        <p>Sem o <code>webtorrent-sw.js</code>, o vídeo só começa quando o download terminar.</p>
      </div>`
    );

    try {
      const buffer = await file.arrayBuffer();
      const blob = new Blob([buffer], { type: file.type || "video/mp4" });
      video.src = URL.createObjectURL(blob);
      hideMessage();
      return true;
    } catch (err) {
      console.warn("[player] torrent buffer:", err);
      return false;
    }
  }

  /** Base do gateway torrent no proxy Node (se configurado). */
  function torrentProxyBase() {
    if (typeof TORRENT_PROXY !== "undefined" && TORRENT_PROXY === false) return "";
    if (typeof TORRENT_PROXY === "string" && TORRENT_PROXY.trim()) return TORRENT_PROXY.trim();
    const sp =
      typeof STREAM_PROXY === "string" && STREAM_PROXY.trim() ? STREAM_PROXY.trim() : "";
    if (!sp) return "";
    try {
      const u = new URL(sp, typeof location !== "undefined" ? location.origin : "http://localhost");
      u.pathname = u.pathname.replace(/\/proxy\/?$/i, "/torrent");
      if (!/torrent$/i.test(u.pathname.replace(/\/$/, ""))) u.pathname = "/torrent";
      u.searchParams.delete("url");
      u.searchParams.delete("u");
      const qs = u.searchParams.toString();
      return `${u.origin}${u.pathname.replace(/\/$/, "")}?${qs ? `${qs}&` : ""}magnet=`;
    } catch {
      return sp.replace(/\/proxy\?/i, "/torrent?").replace(/url=$/i, "magnet=");
    }
  }

  function buildTorrentProxyUrl(magnet, fileIdx) {
    const base = torrentProxyBase();
    if (!base) return "";
    let url =
      base.endsWith("=") || base.endsWith("?")
        ? base + encodeURIComponent(magnet)
        : base.replace(/\/?$/, "/") + encodeURIComponent(magnet);
    if (Number.isInteger(fileIdx) && fileIdx >= 0) {
      url += (url.includes("?") ? "&" : "?") + "file=" + fileIdx;
    }
    return url;
  }

  async function playTorrent(src) {
    const session = state.session;
    // Preferir magnet já normalizado (api.js); fallback para url magnet
    let magnet = src.magnet || null;
    if (!magnet && /^magnet:\?/i.test(src.url || "")) magnet = src.url;
    if (!magnet && src.infoHash && typeof torrentMagnet === "function") {
      magnet = torrentMagnet(src);
    }

    if (!magnet) {
      showTorrentError("Esta fonte torrent não trouxe um magnet/infoHash válido.");
      return;
    }

    // Magnet mínimo válido: xt=urn:btih: + hash
    const xtOk = /xt=urn:btih:([a-f0-9]{40}|[a-z2-7]{32})/i.test(magnet);
    if (!xtOk) {
      showTorrentError(
        "Magnet/infoHash em formato que o player não reconhece. Use outra fonte (HTTP/HLS) ou um addon que envie hash completo."
      );
      return;
    }

    // Gateway no servidor: UDP/TCP no Node → HTTP para o player
    const gatewayUrl = buildTorrentProxyUrl(
      magnet,
      Number.isInteger(src.fileIdx) ? src.fileIdx : null
    );
    if (gatewayUrl) {
      showSpinner(true);
      showToast("Torrent via servidor…", 2500);
      const proxied = {
        ...src,
        kind: "mp4",
        url: gatewayUrl,
        magnet: null,
        label: `${src.label || "Torrent"} · servidor`,
      };
      const idx = state.sources.findIndex((s) => srcKey(s) === srcKey(src));
      if (idx >= 0) state.sources[idx] = proxied;
      else state.sources.push(proxied);
      const playIdx = idx >= 0 ? idx : state.sources.length - 1;
      await playSourceAt(playIdx);
      return;
    }

    showSpinner(true);
    showMessage(
      `<div class="p-empty">
        <h2>Conectando ao torrent…</h2>
        <p>Procurando peers WebRTC para <strong>${esc(state.media?.title || "este título")}</strong>.</p>
        <p class="p-note">Sem STREAM_PROXY/TORRENT_PROXY no config, só entram peers WebRTC (wss) ou webseed HTTP.</p>
      </div>`
    );

    let WebTorrent;
    try {
      WebTorrent = await loadWebTorrent();
    } catch (err) {
      if (session !== state.session) return;
      showTorrentError(`Não foi possível carregar o WebTorrent (${err.message}).`);
      return;
    }
    if (session !== state.session) return;

    const client = getTorrentClient(WebTorrent);

    let active;
    try {
      active = client.add(magnet);
    } catch (err) {
      const msg = String((err && err.message) || err || "");
      showTorrentError(
        /invalid torrent identifier/i.test(msg)
          ? "Magnet/infoHash inválido (formato que o WebTorrent não aceita). Tente outra fonte ou um addon que mande link HTTP/HLS."
          : `Magnet inválido: ${msg}`
      );
      return;
    }
    torrent = active;
    startTorrentStats(active, session);

    let finished = false;
    const fail = (text) => {
      if (finished || session !== state.session) return;
      finished = true;
      stopTorrentStats();
      if (torrentTimer) {
        clearTimeout(torrentTimer);
        torrentTimer = null;
      }
      showTorrentError(text);
    };

    torrentTimer = setTimeout(() => {
      const peers = active.numPeers || 0;
      fail(
        peers
          ? `Nenhum dado chegou em 25 segundos (${peers} peer${
              peers === 1 ? "" : "s"
            } conectado${peers === 1 ? "" : "s"}, mas sem enviar pedaços).`
          : "Nenhum peer WebRTC respondeu em 25 segundos."
      );
    }, 25000);

    active.on("error", (err) => fail(`O torrent falhou: ${(err && err.message) || err}`));

    active.on("ready", async () => {
      if (finished || session !== state.session) return;
      finished = true;
      stopTorrentStats();
      if (torrentTimer) {
        clearTimeout(torrentTimer);
        torrentTimer = null;
      }

      const file = pickTorrentFile(active, src.fileIdx);
      if (!file) {
        showTorrentError("O torrent não tem nenhum arquivo de vídeo.");
        return;
      }

      hideMessage();
      dom.pv.classList.remove("hidden");
      dom.frame.classList.add("hidden");
      dom.controls.classList.remove("hidden");
      dom.center.classList.remove("hidden");
      renderSubtitles(src.subtitles || []);
      updateSourceLabel();
      showSpinner(true);

      if (!(await attachTorrentFile(file, client))) {
        showTorrentError("Este navegador não consegue transmitir o arquivo do torrent.");
        return;
      }

      setMediaSession();
      try {
        await dom.pv.play();
      } catch {
        showSpinner(false);
        dom.bigPlay.classList.remove("hidden");
      }
    });
  }

  function showFrame(src) {
    let url = src.url;
    if (src.kind === "youtube") {
      const key = youtubeKey(src.url);
      url = key
        ? `https://www.youtube-nocookie.com/embed/${key}?autoplay=1&rel=0&modestbranding=1&playsinline=1`
        : src.url;
    }
    dom.frame.innerHTML = `<iframe src="${esc(url)}" title="${esc(state.media?.title || "Vídeo")}" allow="autoplay; fullscreen; encrypted-media; picture-in-picture" referrerpolicy="strict-origin-when-cross-origin"></iframe>`;
    dom.frame.classList.remove("hidden");
    dom.pv.classList.add("hidden");
    dom.controls.classList.add("hidden");
    dom.center.classList.add("hidden");
    dom.bigPlay.classList.add("hidden");
    dom.play.textContent = "▶";
    showControls();
    setTimeout(() => dom.root.classList.add("controls-hidden"), 2600);
  }

  function detachMedia() {
    clearPlaybackTimers();
    removeMediaErrorWatcher();
    destroyPreview();
    detachHls();
    destroyTorrent();
    try {
      dom.pv.pause();
    } catch {
      /* noop */
    }
    dom.pv.removeAttribute("src");
    try {
      while (dom.pv.firstChild) dom.pv.removeChild(dom.pv.firstChild);
    } catch {
      /* noop */
    }
    try {
      dom.pv.load();
    } catch {
      /* noop */
    }
    dom.frame.innerHTML = "";
    dom.frame.classList.add("hidden");
    dom.pv.classList.remove("hidden");
    dom.center.classList.remove("hidden");
    dom.controls.classList.remove("hidden");
    dom.pv.playbackRate = 1;
    dom.speedBtn.textContent = "1x";
    dom.subsBtn.disabled = true;
    dom.subsBtn.classList.remove("active-opt");
    [...dom.pv.querySelectorAll("track")].forEach((t) => t.remove());
    state.subs = [];
    state.subIndex = -1;
    state.menu = null;
    dom.menu.classList.add("hidden");
    if ("mediaSession" in navigator) {
      try {
        navigator.mediaSession.metadata = null;
      } catch {
        /* noop */
      }
    }
  }

  function detachHls() {
    if (state.hls) {
      try {
        state.hls.destroy();
      } catch {
        /* noop */
      }
      state.hls = null;
    }
  }

  function loadHls() {
    if (window.Hls) return Promise.resolve(window.Hls);
    if (hlsLoading) return hlsLoading;
    hlsLoading = new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = HLS_CDN;
      script.onload = () => resolve(window.Hls);
      script.onerror = () => {
        hlsLoading = null;
        reject(new Error("Não foi possível carregar o suporte a HLS."));
      };
      document.head.appendChild(script);
    });
    return hlsLoading;
  }

  function showPlaybackError(detail, src) {
    showSpinner(false);
    dom.bigPlay.classList.add("hidden");
    state.allFailed = true;

    const total = state.sources.length;
    const others = total > 1;
    const failed = Math.min(state.failed.size, total);
    const name = src ? srcName(src) : "";
    // Fontes que o teste rápido reprovou: quase sempre são links que caem
    // para HTTP e o navegador bloqueia em página HTTPS.
    const httpOnly = state.sources.filter(
      (item) => !state.failed.has(srcKey(item)) && probeState(item) === "fail"
    ).length;

    showMessage(
      `<div class="p-empty">
        <h2>Falha ao reproduzir</h2>
        <p>${esc(detail || "O arquivo pode estar indisponível, fora do ar ou bloquear acesso direto (CORS).")}</p>
        ${name ? `<p class="p-note">Fonte: ${esc(name)}</p>` : ""}
        ${others ? `<p class="p-note">${failed} de ${total} fontes não abriram neste navegador.</p>` : ""}
        ${
          httpOnly
            ? `<p class="p-note">Outras ${httpOnly} fonte${httpOnly === 1 ? "" : "s"} só respondem por HTTP: o navegador bloqueia em site HTTPS (conteúdo misto).</p>`
            : ""
        }
        <p class="p-note">No navegador muitas fontes de addon falham por CORS, HTTP bloqueado em HTTPS, ou codec (MKV/HEVC). Fontes HLS/MP4 em HTTPS costumam funcionar melhor. Use <strong>Fonte</strong> no canto do player para trocar manualmente.</p>
        <div class="p-empty-actions">
          ${others ? '<button class="btn btn-play" data-act="next">Tentar outra fonte</button>' : ""}
          <button class="btn btn-info" data-act="retry">↻ Tentar de novo</button>
          <button class="btn btn-info" data-act="add">＋ Adicionar fonte</button>
        </div>
      </div>`,
      {
        next: () => {
          state.failed = new Set();
          state.probeTries = 0;
          state.allFailed = false;
          state.probes = new Map();
          hideMessage();
          playSourceAt((state.index + 1) % Math.max(state.sources.length, 1));
        },
        retry: () => {
          state.failed = new Set();
          state.probeTries = 0;
          state.allFailed = false;
          state.probes = new Map();
          hideMessage();
          const i = state.sources.length ? state.index % state.sources.length : 0;
          playSourceAt(i);
        },
        add: () => {
          const media = state.media;
          close();
          if (media) document.dispatchEvent(new CustomEvent("player:add-source", { detail: { media } }));
        },
      }
    );
  }

  /* ---------------- legendas ---------------- */

  function renderSubtitles(subs) {
    state.subs = (subs || []).filter((s) => s && s.url);
    state.subIndex = -1;
    state.subs.forEach((sub, i) => {
      const track = document.createElement("track");
      track.kind = "subtitles";
      track.label = sub.label || `Legenda ${i + 1}`;
      track.srclang = sub.lang || "pt";
      track.src = sub.url;
      track.default = false;
      dom.pv.appendChild(track);
    });
    dom.subsBtn.disabled = !state.subs.length;
  }

  function selectSubtitle(index) {
    const tracks = dom.pv.textTracks;
    for (let i = 0; i < tracks.length; i++) {
      tracks[i].mode = i === index ? "showing" : "disabled";
    }
    state.subIndex = index;
    dom.subsBtn.classList.toggle("active-opt", index >= 0);
    showToast(index >= 0 ? `Legendas: ${state.subs[index].label || "ativadas"}` : "Legendas desligadas");
  }

  /* ---------------- controles ---------------- */

  function hasActiveMedia() {
    if (state.hls) return true;
    if (dom.pv.getAttribute("src")) return true;
    if (dom.pv.currentSrc) return true;
    // MP4 via <source type="video/mp4"> não usa atributo src no <video>
    if (dom.pv.querySelector("source[src]")) return true;
    return false;
  }

  function togglePlay() {
    if (dom.frame.classList.contains("hidden") === false) return;
    if (!hasActiveMedia()) return;
    if (dom.pv.paused) {
      if (dom.pv.ended) dom.pv.currentTime = 0;
      dom.pv.play().catch(() => {});
    } else {
      dom.pv.pause();
    }
  }

  function seekBy(seconds) {
    if (!isFinite(dom.pv.duration)) return;
    dom.pv.currentTime = Math.min(
      dom.pv.duration,
      Math.max(0, dom.pv.currentTime + seconds)
    );
    showToast(seconds > 0 ? `+${seconds}s` : `${seconds}s`, 900);
    showControls();
  }

  function seekFromEvent(event) {
    if (!isFinite(dom.pv.duration) || dom.pv.duration <= 0) return;
    const rect = dom.bar.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
    dom.pv.currentTime = ratio * dom.pv.duration;
    updateBar();
  }

  /* ---------------- preview do frame na barra (seek preview) ----------------
     Um segundo <video> escondido carrega a mesma fonte, vai para o instante
     apontado e o frame é desenhado num canvas. Vídeos de embed/YouTube não
     permitem isso: nesses casos aparece só o balão do tempo. */

  const preview = {
    video: null,
    hls: null,
    url: null,
    target: 0,
    seeking: false,
    ready: false,
    seekTimer: null,
  };

  function hidePreview() {
    if (dom.preview) dom.preview.classList.add("hidden");
  }

  function destroyPreview() {
    if (preview.hls) {
      try {
        preview.hls.destroy();
      } catch {
        /* noop */
      }
      preview.hls = null;
    }
    if (preview.video) {
      try {
        preview.video.pause();
      } catch {
        /* noop */
      }
      preview.video.removeAttribute("src");
      preview.video.remove();
      preview.video = null;
    }
    clearTimeout(preview.seekTimer);
    preview.seekTimer = null;
    preview.url = null;
    preview.ready = false;
    preview.seeking = false;
    if (dom.preview) dom.preview.classList.add("no-frame");
    hidePreview();
  }

  async function setupPreviewSource(src) {
    if (!src || preview.url === src.url) return;
    destroyPreview();
    preview.url = src.url;

    const isDirect =
      src.kind === "mp4" ||
      src.kind === "hls" ||
      /\.(mp4|webm|ogv|mov|m4v|m3u8)(\?|#|$)/i.test(src.url || "");
    if (!isDirect) return;

    const video = document.createElement("video");
    video.muted = true;
    video.playsInline = true;
    video.preload = "auto";
    video.className = "p-preview-source";
    video.setAttribute("aria-hidden", "true");
    video.style.position = "fixed";
    video.style.left = "-9999px";
    video.style.top = "0";
    video.style.width = "1px";
    video.style.height = "1px";
    video.style.opacity = "0";
    video.style.pointerEvents = "none";

    preview.video = video;

    video.addEventListener("loadedmetadata", () => {
      if (preview.video !== video) return;
      preview.ready = true;
      if (preview.target) seekPreview();
    });
    video.addEventListener("seeked", () => {
      if (preview.video !== video) return;
      clearTimeout(preview.seekTimer);
      preview.seekTimer = null;
      preview.seeking = false;
      drawPreviewFrame();
      if (Math.abs(preview.target - video.currentTime) > 0.5) seekPreview();
    });
    video.addEventListener("loadeddata", drawPreviewFrame);

    document.body.appendChild(video);

    const isHls = src.kind === "hls" || /\.m3u8(\?|#|$)/i.test(src.url || "");
    if (isHls && !video.canPlayType("application/vnd.apple.mpegurl")) {
      try {
        const Hls = await loadHls();
        if (preview.video !== video) return;
        if (Hls && Hls.isSupported()) {
          const hls = new Hls({ enableWorker: true, maxBufferLength: 8 });
          preview.hls = hls;
          hls.loadSource(src.url);
          hls.attachMedia(video);
          return;
        }
      } catch {
        /* fica sem preview de frame nesta fonte */
      }
    }

    video.src = src.url;
  }

  function drawPreviewFrame() {
    const video = preview.video;
    const canvas = dom.previewCanvas;
    if (!video || !canvas || !dom.previewCtx || video.readyState < 2) return;

    const width = video.videoWidth;
    const height = video.videoHeight;
    if (!width || !height) return;

    const scale = Math.max(canvas.width / width, canvas.height / height);
    const sourceWidth = canvas.width / scale;
    const sourceHeight = canvas.height / scale;

    try {
      dom.previewCtx.drawImage(
        video,
        (width - sourceWidth) / 2,
        (height - sourceHeight) / 2,
        sourceWidth,
        sourceHeight,
        0,
        0,
        canvas.width,
        canvas.height
      );
      dom.preview.classList.remove("no-frame");
    } catch {
      /* frame indisponível (vídeo protegido) */
    }
  }

  function seekPreview() {
    const video = preview.video;
    if (!video || !preview.ready || preview.seeking) return;
    if (Math.abs(video.currentTime - preview.target) < 0.1) {
      drawPreviewFrame();
      return;
    }
    preview.seeking = true;
    // fonte sem suporte a seek pode nunca disparar "seeked": libera depois
    clearTimeout(preview.seekTimer);
    preview.seekTimer = setTimeout(() => {
      preview.seeking = false;
    }, 2000);
    try {
      video.currentTime = preview.target;
    } catch {
      preview.seeking = false;
    }
  }

  function requestPreviewFrame(time) {
    if (!preview.video || !preview.ready) return;
    preview.target = time;
    seekPreview();
  }

  function showPreviewAt(event) {
    if (!dom.preview || !dom.bar) return;
    // No toque a miniatura atrapalha o seek
    if (isTouchUi()) {
      hidePreview();
      return;
    }
    const duration = dom.pv.duration;
    if (!isFinite(duration) || duration <= 0) {
      hidePreview();
      return;
    }

    const rect = dom.bar.getBoundingClientRect();
    if (!rect.width) return;

    const ratio = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
    const time = ratio * duration;
    const offset = Math.min(rect.width - 92, Math.max(92, event.clientX - rect.left));

    dom.preview.classList.remove("hidden");
    dom.preview.style.left = `${offset}px`;
    dom.previewTime.textContent = fmtTime(time);

    const src = state.sources[state.index];
    if (src && !preview.video) setupPreviewSource(src);
    if (!preview.video) dom.preview.classList.add("no-frame");

    requestPreviewFrame(time);
  }

  function toggleMute() {
    dom.pv.muted = !dom.pv.muted;
    syncVolumeUI();
  }

  function setVolume(value) {
    dom.pv.volume = Math.min(1, Math.max(0, value));
    dom.pv.muted = dom.pv.volume === 0;
    syncVolumeUI();
  }

  function syncVolumeUI() {
    dom.volume.value = String(dom.pv.muted ? 0 : dom.pv.volume);
    dom.mute.textContent = dom.pv.muted || dom.pv.volume === 0 ? "🔇" : "🔊";
  }

  async function toggleFullscreen() {
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
      } else if (dom.root.requestFullscreen) {
        await dom.root.requestFullscreen();
      } else if (dom.pv.webkitEnterFullscreen) {
        dom.pv.webkitEnterFullscreen();
      }
    } catch (err) {
      console.warn("[player] fullscreen:", err);
    }
  }

  async function togglePip() {
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if (document.pictureInPictureEnabled) {
        await dom.pv.requestPictureInPicture();
      }
    } catch {
      /* noop */
    }
  }

  function updateBar() {
    const duration = dom.pv.duration || 0;
    const current = dom.pv.currentTime || 0;
    const percent = duration ? (current / duration) * 100 : 0;
    dom.played.style.width = `${percent}%`;

    let buffered = 0;
    try {
      if (dom.pv.buffered.length && duration) {
        buffered = (dom.pv.buffered.end(dom.pv.buffered.length - 1) / duration) * 100;
      }
    } catch {
      /* noop */
    }
    dom.buffer.style.width = `${Math.min(100, buffered)}%`;
    dom.time.textContent = `${fmtTime(current)} / ${fmtTime(duration)}`;
  }

  function onLoadedMetadata() {
    clearPlaybackTimers();
    state.allFailed = false;
    updateBar();
    const duration = dom.pv.duration;

    // Onde retomar: prioridade resumeAt (troca de fonte) → progresso salvo
    let resume = state.resumeAt;
    if (!(resume > 5) && state.media) {
      const saved = getProgress(state.media);
      if (saved && saved.position > 5) resume = saved.position;
    }

    if (resume > 5 && isFinite(duration) && resume < duration - 10) {
      try {
        dom.pv.currentTime = resume;
        showToast(`Retomando de ${fmtTime(resume)}`, 1800);
      } catch {
        /* algumas fontes não aceitam seek imediato */
      }
    }
    state.resumeAt = 0;
    showSpinner(false);
    syncVolumeUI();
  }

  function isTouchUi() {
    try {
      return window.matchMedia("(hover: none), (pointer: coarse)").matches;
    } catch {
      return false;
    }
  }

  function showControls() {
    if (!dom.root) return;
    dom.root.classList.remove("controls-hidden");
    if (state.idleTimer) clearTimeout(state.idleTimer);
    const iframeOpen = !dom.frame.classList.contains("hidden");
    // No celular os controles ficam mais tempo visíveis (toque é mais lento)
    const idleMs = isTouchUi() ? 5200 : 3000;
    if ((iframeOpen || !dom.pv.paused) && !state.menu) {
      state.idleTimer = setTimeout(() => {
        if (!state.menu) dom.root.classList.add("controls-hidden");
      }, idleMs);
    }
  }

  /* ---------------- menu de opções ---------------- */

  function openMenu(kind) {
    if (state.menu === kind) return closeMenu();
    state.menu = kind;
    dom.menu.classList.remove("hidden");

    if (kind === "speed") {
      buildMenu(
        "Velocidade",
        SPEEDS.map((speed) => ({
          label: `${speed}x`,
          active: Math.abs(dom.pv.playbackRate - speed) < 0.01,
          onClick: () => {
            dom.pv.playbackRate = speed;
            dom.speedBtn.textContent = `${speed}x`;
            showToast(`Velocidade ${speed}x`);
          },
        }))
      );
    }

    if (kind === "subs") {
      const options = [
        {
          label: "Desligado",
          active: state.subIndex === -1,
          onClick: () => selectSubtitle(-1),
        },
        ...state.subs.map((sub, i) => ({
          label: sub.label || `Legenda ${i + 1}`,
          hint: (sub.lang || "").toUpperCase(),
          active: state.subIndex === i,
          onClick: () => selectSubtitle(i),
        })),
      ];
      buildMenu("Legendas", options, state.subs.length ? "Nenhuma legenda nesta fonte." : undefined);
    }

    if (kind === "source") {
      buildMenu(
        "Fonte de vídeo",
        state.sources.map((src, i) => ({
          label: src.label || `Fonte ${i + 1}`,
          hint: [
            src.quality,
            src.provider,
            state.failed.has(srcKey(src)) ? "falhou" : "",
            probeState(src) === "fail" ? "link HTTP" : "",
          ]
            .filter(Boolean)
            .join(" · "),
          active: i === state.index,
          onClick: () => {
            state.failed.delete(srcKey(src));
            state.probeTries = 0;
            playSourceAt(i);
          },
        }))
      );
    }

    showControls();
  }

  function buildMenu(title, options, emptyText) {
    const rows = options
      .map(
        (option, i) => `<button type="button" data-i="${i}" class="${option.active ? "active" : ""}">
          <span>${esc(option.label)}</span>
          <span class="p-menu-hint">${esc(option.hint || "")}</span>
        </button>`
      )
      .join("");

    dom.menu.innerHTML = `<div class="p-menu-title">${esc(title)}</div>${
      rows || `<div class="p-menu-empty">${esc(emptyText || "Nada aqui")}</div>`
    }`;

    options.forEach((option, i) => {
      dom.menu.querySelector(`[data-i="${i}"]`)?.addEventListener("click", () => {
        option.onClick();
        closeMenu();
      });
    });
  }

  function closeMenu() {
    state.menu = null;
    dom.menu.classList.add("hidden");
    dom.menu.innerHTML = "";
    showControls();
  }

  /* ---------------- progresso ---------------- */

  function maybeSave() {
    if (!state.media) return;
    if (Math.abs(dom.pv.currentTime - state.lastSaved) < 5) return;
    state.lastSaved = dom.pv.currentTime;
    saveProgress(state.media, dom.pv.currentTime, dom.pv.duration);
  }

  function saveNow() {
    if (!state.media) return;
    saveProgress(state.media, dom.pv.currentTime, dom.pv.duration);
    state.lastSaved = dom.pv.currentTime;
  }

  /* ---------------- pular abertura ---------------- */

  function updateSkipIntro() {
    if (!dom.skipIntro || !state.media) return;
    if (state.skipIntroUsed || state.media.type !== "tv") {
      hideSkipIntro();
      return;
    }
    const t = dom.pv.currentTime;
    const d = dom.pv.duration;
    if (!isFinite(d) || d < SKIP_INTRO_MIN_DUR) {
      hideSkipIntro();
      return;
    }
    // Se o usuário já passou do trecho de abertura (ex.: retomou no meio), não mostra
    if (state.resumeAt > SKIP_INTRO_UNTIL) {
      hideSkipIntro();
      return;
    }
    const show = t >= SKIP_INTRO_FROM && t <= SKIP_INTRO_UNTIL && t < SKIP_INTRO_TO - 2;
    if (show) {
      dom.skipIntro.classList.remove("hidden");
    } else {
      hideSkipIntro();
    }
  }

  function skipIntro() {
    if (!dom.pv || state.skipIntroUsed) return;
    state.skipIntroUsed = true;
    hideSkipIntro();
    const d = dom.pv.duration;
    const target = isFinite(d) ? Math.min(SKIP_INTRO_TO, Math.max(0, d - 5)) : SKIP_INTRO_TO;
    if (dom.pv.currentTime < target) {
      dom.pv.currentTime = target;
      showToast("Abertura pulada", 1200);
    }
    showControls();
  }

  function hideSkipIntro() {
    if (dom.skipIntro) dom.skipIntro.classList.add("hidden");
  }

  /* ---------------- próximo episódio ---------------- */

  async function handleEnded() {
    if (!state.media) return;
    clearProgress(state.media);
    hideSkipIntro();
    dom.play.textContent = "▶";

    if (state.media.type !== "tv") {
      dom.bigPlay.classList.remove("hidden");
      showControls();
      return;
    }

    await showNextCard({ countdown: true, spinner: true });
  }

  /** Mostra o cartão "A seguir" perto do fim ou ao terminar. */
  async function showNextCard({ countdown = false, spinner = false } = {}) {
    if (!state.media || state.media.type !== "tv") return;
    if (state.next && !dom.next.classList.contains("hidden")) {
      if (countdown && !state.nextTimer) startNextCountdown();
      return;
    }

    const media = state.media;
    const session = state.session;
    if (spinner) showSpinner(true);
    const next = state.next || (await findNextEpisode(media).catch(() => null));
    if (session !== state.session) return;
    if (spinner) showSpinner(false);

    if (!next) {
      if (countdown) {
        showToast("Você chegou ao fim da série.");
        dom.bigPlay.classList.remove("hidden");
      }
      return;
    }

    state.next = next;
    state.nextPrompting = true;
    hideSkipIntro();
    dom.nextText.textContent = `T${next.season}E${next.episode}${next.name ? ` · ${next.name}` : ""}`;
    dom.next.classList.remove("hidden");
    dom.bigPlay.classList.add("hidden");
    showControls();

    if (countdown) startNextCountdown();
    else {
      dom.nextPlay.textContent = "Reproduzir";
    }
  }

  function startNextCountdown() {
    if (state.nextTimer) return;
    let remaining = 8;
    dom.nextPlay.textContent = `Reproduzir (${remaining})`;
    state.nextTimer = setInterval(() => {
      remaining -= 1;
      dom.nextPlay.textContent = `Reproduzir (${remaining})`;
      if (remaining <= 0) goNext();
    }, 1000);
  }

  /** Perto do final do episódio, já oferece o próximo (sem contagem automática). */
  function maybePromptNext() {
    if (!state.media || state.media.type !== "tv") return;
    if (state.nextPrompting || state.nextTimer) return;
    const d = dom.pv.duration;
    const t = dom.pv.currentTime;
    if (!isFinite(d) || d < 120) return;
    if (d - t > NEXT_PROMPT_REMAINING || d - t < 1) return;
    state.nextPrompting = true;
    showNextCard({ countdown: false, spinner: false }).catch(() => {
      state.nextPrompting = false;
    });
  }

  function goNext() {
    const media = state.media;
    const next = state.next;
    clearNext();
    if (!media || !next) return;
    open({
      ...media,
      season: next.season,
      episode: next.episode,
      episodeTitle: next.name,
    });
  }

  function clearNext() {
    if (state.nextTimer) clearInterval(state.nextTimer);
    state.nextTimer = null;
    state.next = null;
    state.nextPrompting = false;
    if (dom.next) {
      dom.next.classList.add("hidden");
      dom.nextPlay.textContent = "Reproduzir";
    }
  }

  /* ---------------- media session ---------------- */

  function setMediaSession() {
    if (!("mediaSession" in navigator) || !state.media) return;
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: state.media.episodeTitle || state.media.title,
        album: state.media.title,
        artist: state.media.episode ? `T${state.media.season}E${state.media.episode}` : "Filme",
        artwork: state.media.posterPath
          ? [{ src: imgUrl(state.media.posterPath, "w342"), sizes: "342x513", type: "image/jpeg" }]
          : state.media.poster
            ? [{ src: state.media.poster, sizes: "342x513", type: "image/jpeg" }]
            : [],
      });
      navigator.mediaSession.setActionHandler("play", () => dom.pv.play().catch(() => {}));
      navigator.mediaSession.setActionHandler("pause", () => dom.pv.pause());
      navigator.mediaSession.setActionHandler("seekbackward", () => seekBy(-10));
      navigator.mediaSession.setActionHandler("seekforward", () => seekBy(10));
    } catch {
      /* noop */
    }
  }

  /* ---------------- teclado ---------------- */

  function onKeydown(event) {
    if (!dom.root || dom.root.classList.contains("hidden")) return;
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(event.target.tagName)) return;

    // Fire TV / controle remoto — teclas de mídia
    const k = event.key;
    if (
      k === "MediaPlayPause" ||
      k === "MediaPlay" ||
      k === "MediaPause" ||
      event.keyCode === 179 ||
      event.keyCode === 415 ||
      event.keyCode === 19
    ) {
      event.preventDefault();
      if (k === "MediaPlay") dom.pv.play().catch(() => {});
      else if (k === "MediaPause") dom.pv.pause();
      else togglePlay();
      showControls();
      return;
    }
    if (k === "MediaRewind" || event.keyCode === 412) {
      event.preventDefault();
      seekBy(-30);
      return;
    }
    if (k === "MediaFastForward" || event.keyCode === 417) {
      event.preventDefault();
      seekBy(30);
      return;
    }

    switch (event.key) {
      case " ":
      case "k":
      case "Select":
      case "Enter":
        // Enter no player = play/pause (TV)
        if (event.key === "Enter" || event.key === "Select" || event.key === " ") {
          event.preventDefault();
          togglePlay();
        } else {
          event.preventDefault();
          togglePlay();
        }
        break;
      case "ArrowRight":
        event.preventDefault();
        seekBy(10);
        break;
      case "ArrowLeft":
        event.preventDefault();
        seekBy(-10);
        break;
      case "ArrowUp":
        event.preventDefault();
        setVolume(dom.pv.volume + 0.05);
        showToast(`Volume ${Math.round(dom.pv.volume * 100)}%`, 900);
        break;
      case "ArrowDown":
        event.preventDefault();
        setVolume(dom.pv.volume - 0.05);
        showToast(`Volume ${Math.round(dom.pv.volume * 100)}%`, 900);
        break;
      case "m":
        toggleMute();
        break;
      case "f":
        toggleFullscreen();
        break;
      case "Escape":
        if (state.menu) {
          closeMenu();
        } else if (document.fullscreenElement) {
          document.exitFullscreen().catch(() => {});
        } else {
          close();
        }
        break;
      default:
        break;
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  return { open, openTrailer, close };
})();
