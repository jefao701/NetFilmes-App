// ============================================
//  Configuração do site
// ============================================

const TMDB_API_KEY = "bbd9576aac007fa885ed185429fb4770";

const TMDB_BASE = "https://api.themoviedb.org/3";
const IMG_BASE = "https://image.tmdb.org/t/p/";
const TMDB_LANG = "pt-BR";

// Biblioteca usada só quando a fonte é HLS (.m3u8)
const HLS_CDN = "https://cdn.jsdelivr.net/npm/hls.js@1.5.20/dist/hls.min.js";

// WebTorrent, carregado só quando a fonte é um torrent (magnet/infoHash).
// É um módulo ES: o player importa dinamicamente a primeira URL que funcionar.
// Lembre-se: no navegador só há peers WebRTC (trackers wss://) e webseed HTTP.
const WEBTORRENT_CDNS = [
  "https://cdn.jsdelivr.net/npm/webtorrent@2/dist/webtorrent.min.js",
];

// Trackers WebSocket usados quando o addon só manda trackers UDP/HTTP
// (o navegador não fala UDP: só chega a peers por WebSocket/WebRTC).
const TORRENT_WSS_TRACKERS = [
  "wss://tracker.openwebtorrent.com",
  "wss://tracker.webtorrent.dev",
  "wss://tracker.files.fm:7073/announce",
  "wss://tracker.btorrent.xyz",
];

// Addons de fontes que você mesmo hospeda (o site não vem com nenhum).
// Ex.: { name: "Meu acervo", url: "https://exemplo.com/addon.json" }
const DEFAULT_ADDONS = [];

// Fonte PinguimCinema — resolvida pelo SEU servidor Node (pasta proxy/).
// Com a URL preenchida, a fonte entra sozinha na lista de "Fontes de vídeo",
// com o mesmo botão liga/desliga dos outros addons (não precisa colar nada).
// Em branco: nada aparece e o site segue como sempre.
// A URL do manifesto (…/pinguim/manifest.json) é montada a partir desta.
// ESTE é o ÚNICO lugar com o endereço do proxy: o STREAM_PROXY logo abaixo
// também sai daqui.
//
// ATENÇÃO: o valor abaixo é o do TESTE NO SEU PC (proxy rodando no mesmo
// computador que abre o site). Antes de enviar o site para a hospedagem,
// troque pelo endereço público do proxy, exemplo:
//   const PINGUIM_PROXY_URL = "https://netfilmes-proxy.shardcloud.app";
const PINGUIM_PROXY_URL = "http://127.0.0.1:8787";

// Proxy Node próprio (pasta proxy/ neste projeto), montado a partir do
// endereço acima. Com PROXY_SECRET no servidor, escreva a chave aqui:
//   const STREAM_PROXY = PINGUIM_PROXY_URL ? `${PINGUIM_PROXY_URL}/proxy?key=SUA_SENHA&url=` : null;
// Deixe a linha como está (ou null) para não usar o proxy.
const STREAM_PROXY = PINGUIM_PROXY_URL ? `${PINGUIM_PROXY_URL}/proxy?url=` : null;

// false = o proxy entra só onde o navegador precisa dele: MP4/arquivo
// progressivo, link http:// (bloqueado em site https), fonte que exige
// cabeçalho próprio e as que o addon marca como problemáticas. O HLS (.m3u8)
// que já abre direto continua direto de propósito — a playlist traz os
// segmentos com endereço relativo e o /proxy repassa o corpo sem reescrever.
// true  = manda TODO stream http(s) pelo proxy (mais chances de abrir, mas
// inclui a playlist HLS, que pode quebrar, e toda a banda no seu servidor).
const STREAM_PROXY_ALWAYS = false;

// Gateway torrent no MESMO proxy Node (rota /torrent?magnet=).
// false = desliga (só WebTorrent no navegador)
// null  = deriva do STREAM_PROXY (troca /proxy?url= → /torrent?magnet=)
// string = URL completa, ex. "https://seu-proxy.../torrent?magnet="
const TORRENT_PROXY = false;

// Fire TV / Smart TV: true força o modo TV (controles remotos, UI grande).
// Também ativa sozinho em Fire TV, ou com ?tv=1 na URL.
const FORCE_TV_MODE = false;

// Conta na nuvem (e-mail/senha) — Firebase (plano gratuito).
// Projeto: login-3ebd2. Passo a passo completo em MANUAL-NUVEM.txt.
// Para desativar o login e voltar ao modo só local, troque por null.
//
// ATENÇÃO: esta config NÃO é segredo (ela é pública em todo site Firebase).
// O que protege os dados são as REGRAS do Firestore — veja a Parte 5 do
// MANUAL-NUVEM.txt. Sem publicar as regras, a sincronização é negada.
//
// No Firebase também é preciso (uma vez só):
//   Authentication → Sign-in method → ativar "E-mail/senha"
//   Firestore Database → criar em southamerica-east1 (São Paulo)
const FIREBASE_CONFIG = {
  apiKey: "AIzaSyDtcSTfWJYoiXJjANghnzOFThZl-vauh7o",
  authDomain: "login-3ebd2.firebaseapp.com",
  projectId: "login-3ebd2",
  storageBucket: "login-3ebd2.firebasestorage.app",
  messagingSenderId: "225339095501",
  appId: "1:225339095501:web:345f38dfaad8ef9972ac84",
};
// measurementId (G-...) não é usado: o site não carrega o Analytics.
