/* ============================================================
   tv.js — modo Fire TV / Smart TV (controle remoto)
   Ativa com: ?tv=1  |  UA Fire TV  |  FORCE_TV_MODE no config
   ============================================================ */

(function () {
  "use strict";

  function forceFlag() {
    try {
      if (typeof FORCE_TV_MODE !== "undefined" && FORCE_TV_MODE) return true;
    } catch {
      /* noop */
    }
    try {
      const q = new URLSearchParams(location.search);
      if (q.get("tv") === "1" || q.get("firetv") === "1") return true;
      if (localStorage.getItem("mf:tv-mode") === "1") return true;
    } catch {
      /* noop */
    }
    return false;
  }

  function detectTvUa() {
    const ua = navigator.userAgent || "";
    // Fire TV sticks/cubes, Amazon Silk on TV, outras TVs comuns
    return /AFTB|AFTS|AFTN|AFTR|AFTM|AFTK|AFTJ|AFTKM|AFTL|AFTT|FireTV|AmazonWebAppPlatform|BRAVIA|Web0S|WebOS|Tizen|SmartTV|Smart-TV|AppleTV|CrKey|GoogleTV|Android TV|AndroidTV|PLAYSTATION|Xbox/i.test(
      ua
    );
  }

  function isTvMode() {
    return forceFlag() || detectTvUa();
  }

  if (!isTvMode()) {
    window.NetfilmesTV = { active: false };
    return;
  }

  document.documentElement.classList.add("tv-mode");
  document.body.classList.add("tv-mode");

  // Cursor some na TV
  try {
    document.body.style.cursor = "none";
  } catch {
    /* noop */
  }

  const FOCUSABLE =
    'a.nav-link, button:not([disabled]), [tabindex]:not([tabindex="-1"]), .card, .hero-action, .icon-btn, .profile-btn, .p-btn, .top-card, .ep-item, .profile-card';

  function visible(el) {
    if (!el || !el.getBoundingClientRect) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const st = window.getComputedStyle(el);
    if (st.visibility === "hidden" || st.display === "none" || st.opacity === "0") return false;
    // Modal / player abertos: só elementos dentro deles
    const player = document.getElementById("player");
    const playerOpen = player && !player.classList.contains("hidden");
    if (playerOpen) return player.contains(el);
    const modal = document.querySelector(".modal:not(.hidden)");
    if (modal) return modal.contains(el);
    const profiles = document.getElementById("profilesScreen");
    if (profiles && !profiles.classList.contains("hidden")) return profiles.contains(el);
    return true;
  }

  function allFocusable() {
    return Array.from(document.querySelectorAll(FOCUSABLE)).filter(visible);
  }

  function centerOf(el) {
    const r = el.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2, r };
  }

  function moveFocus(dir) {
    const list = allFocusable();
    if (!list.length) return;

    let current = document.activeElement;
    if (!list.includes(current)) {
      // prioriza card na tela ou hero Assistir
      const prefer =
        list.find((el) => el.id === "heroPlay") ||
        list.find((el) => el.classList.contains("card")) ||
        list[0];
      prefer.focus({ preventScroll: false });
      prefer.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" });
      return;
    }

    const cur = centerOf(current);
    let best = null;
    let bestScore = Infinity;

    for (const el of list) {
      if (el === current) continue;
      const c = centerOf(el);
      const dx = c.x - cur.x;
      const dy = c.y - cur.y;
      let ok = false;
      let dist = 0;

      if (dir === "left") {
        ok = dx < -8 && Math.abs(dy) < Math.max(80, cur.r.height * 1.2);
        dist = -dx + Math.abs(dy) * 2;
      } else if (dir === "right") {
        ok = dx > 8 && Math.abs(dy) < Math.max(80, cur.r.height * 1.2);
        dist = dx + Math.abs(dy) * 2;
      } else if (dir === "up") {
        ok = dy < -8 && Math.abs(dx) < Math.max(120, cur.r.width * 1.4);
        dist = -dy + Math.abs(dx) * 1.5;
      } else if (dir === "down") {
        ok = dy > 8 && Math.abs(dx) < Math.max(120, cur.r.width * 1.4);
        dist = dy + Math.abs(dx) * 1.5;
      }

      if (!ok) continue;
      if (dist < bestScore) {
        bestScore = dist;
        best = el;
      }
    }

    // fallback: qualquer elemento na direção, mesmo desalinhado
    if (!best) {
      for (const el of list) {
        if (el === current) continue;
        const c = centerOf(el);
        const dx = c.x - cur.x;
        const dy = c.y - cur.y;
        let ok = false;
        let dist = Math.hypot(dx, dy);
        if (dir === "left" && dx < -12) ok = true;
        if (dir === "right" && dx > 12) ok = true;
        if (dir === "up" && dy < -12) ok = true;
        if (dir === "down" && dy > 12) ok = true;
        if (!ok) continue;
        // penaliza desalinhamento
        if (dir === "left" || dir === "right") dist += Math.abs(dy) * 3;
        else dist += Math.abs(dx) * 3;
        if (dist < bestScore) {
          bestScore = dist;
          best = el;
        }
      }
    }

    if (best) {
      best.focus({ preventScroll: false });
      best.scrollIntoView({ block: "nearest", inline: "center", behavior: "smooth" });
      // rola a fileira horizontal se for card
      const track = best.closest(".row-track");
      if (track && best.classList.contains("card")) {
        const tr = track.getBoundingClientRect();
        const br = best.getBoundingClientRect();
        if (br.right > tr.right - 20) track.scrollLeft += br.right - tr.right + 40;
        if (br.left < tr.left + 20) track.scrollLeft -= tr.left - br.left + 40;
      }
    }
  }

  function activateFocused(e) {
    const el = document.activeElement;
    if (!el || el === document.body) return;
    if (el.matches("input, textarea, select")) return;

    e.preventDefault();
    // botão / link
    if (typeof el.click === "function") {
      el.click();
      return;
    }
    // card com keydown próprio
    el.dispatchEvent(
      new KeyboardEvent("keydown", { key: "Enter", bubbles: true, cancelable: true })
    );
  }

  function onKeydown(e) {
    // não intercepta digitação em inputs
    if (e.target && e.target.matches && e.target.matches("input, textarea, select")) return;

    const key = e.key;
    const code = e.keyCode;
    const player = document.getElementById("player");
    const playerOpen = player && !player.classList.contains("hidden");

    // Com o player aberto: setas ficam com o player (seek/volume)
    if (playerOpen) {
      if (
        key === "ArrowLeft" ||
        key === "ArrowRight" ||
        key === "ArrowUp" ||
        key === "ArrowDown" ||
        code === 37 ||
        code === 38 ||
        code === 39 ||
        code === 40
      ) {
        return;
      }
      // Enter / OK = play-pause (player.js também trata)
      if (key === "Enter" || key === "Select" || code === 13 || code === 23) {
        return;
      }
    }

    // Setas / D-pad no catálogo
    if (key === "ArrowLeft" || code === 37) {
      e.preventDefault();
      moveFocus("left");
      return;
    }
    if (key === "ArrowRight" || code === 39) {
      e.preventDefault();
      moveFocus("right");
      return;
    }
    if (key === "ArrowUp" || code === 38) {
      e.preventDefault();
      moveFocus("up");
      return;
    }
    if (key === "ArrowDown" || code === 40) {
      e.preventDefault();
      moveFocus("down");
      return;
    }

    // OK / Enter / Select (Fire TV às vezes manda "Select")
    if (key === "Enter" || key === "Select" || code === 13 || code === 23) {
      activateFocused(e);
      return;
    }

    // Back — Escape já tratado em vários fluxos; reforça fechar player
    if (key === "Escape" || key === "Backspace" || code === 27 || code === 10009 || code === 461) {
      const player = document.getElementById("player");
      if (player && !player.classList.contains("hidden")) {
        e.preventDefault();
        if (window.Player && typeof Player.close === "function") Player.close();
        return;
      }
      const modal = document.querySelector(".modal:not(.hidden)");
      if (modal) {
        e.preventDefault();
        const closeBtn = modal.querySelector(".modal-close, [data-close], [data-close-settings], [data-close-prefs]");
        if (closeBtn) closeBtn.click();
        else modal.classList.add("hidden");
      }
    }
  }

  document.addEventListener("keydown", onKeydown, true);

  // Marca elementos focáveis e foca o primeiro útil após carga
  function prepareDom() {
    document.querySelectorAll(".card, .top-card, .hero-action, .nav-link, .icon-btn, .profile-btn").forEach((el) => {
      if (!el.hasAttribute("tabindex")) el.tabIndex = 0;
      el.classList.add("tv-focusable");
    });
  }

  function initialFocus() {
    prepareDom();
    const play = document.getElementById("heroPlay");
    if (play && visible(play)) {
      play.focus();
      return;
    }
    const card = document.querySelector(".card");
    if (card) card.focus();
  }

  // Reaplica quando o DOM muda (fileiras carregam async)
  const obs = new MutationObserver(() => prepareDom());
  obs.observe(document.body, { childList: true, subtree: true });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => setTimeout(initialFocus, 600));
  } else {
    setTimeout(initialFocus, 600);
  }

  // Desliga preview de trailer no hover (TV não tem hover)
  window.NetfilmesTV = {
    active: true,
    moveFocus,
    prepareDom,
  };

  console.info("[Netfilmes] modo TV / Fire TV ativo");
})();
