/* ============================================================
   api.js — TMDB, fontes de vídeo (addons), progresso e utilidades
   ============================================================ */

/* ---------------- TMDB ---------------- */

const Tmdb = (() => {
  const cache = new Map();

  async function get(path, params = {}) {
    const qs = new URLSearchParams({
      api_key: TMDB_API_KEY,
      language: TMDB_LANG,
      ...params,
    });

    let res;
    try {
      res = await fetchWithTimeout(`${TMDB_BASE}${path}?${qs.toString()}`, {}, 12000);
    } catch (err) {
      if (err && err.name === "AbortError") {
        throw new Error("O TMDB demorou demais para responder. Tente de novo.");
      }
      throw err;
    }
    if (!res.ok) {
      if (res.status === 401) throw new Error("Chave do TMDB inválida ou ausente.");
      throw new Error(`O TMDB respondeu com erro ${res.status}.`);
    }
    return res.json();
  }

  function cached(path, params) {
    const key = path + "|" + JSON.stringify(params || {});
    if (!cache.has(key)) {
      const promise = get(path, params).catch((err) => {
        cache.delete(key);
        throw err;
      });
      cache.set(key, promise);
    }
    return cache.get(key);
  }

  return { get, cached };
})();

/* ---------------- Normalização de títulos ---------------- */

/* fetch com timeout — addon travado não pode segurar o player */
const FETCH_TIMEOUT = 7000;

async function fetchWithTimeout(url, options = {}, timeout = FETCH_TIMEOUT) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function normMedia(item, forcedType) {
  if (!item) return null;
  const type =
    forcedType || (item.media_type === "tv" || item.first_air_date ? "tv" : "movie");
  const isTv = type === "tv";
  const date = (isTv ? item.first_air_date : item.release_date) || "";

  return {
    type,
    id: item.id,
    title:
      item.title ||
      item.name ||
      item.original_title ||
      item.original_name ||
      "Sem título",
    overview: item.overview || "",
    posterPath: item.poster_path || null,
    backdropPath: item.backdrop_path || null,
    rating: Number(item.vote_average) || 0,
    date,
    year: date.slice(0, 4),
  };
}

function imgUrl(path, size = "w342") {
  return path ? `${IMG_BASE}${size}${path}` : null;
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (ch) => {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
  });
}

/* Link de imagem colado pelo usuário (foto ou capa do perfil).
   Só http(s) é aceito; qualquer outra coisa vira null (campo vazio). */
function normalizeImageUrl(value) {
  const raw = String(value || "").trim();
  if (!raw) return null;
  try {
    const url = new URL(raw);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return url.href;
  } catch {
    return null;
  }
}

function fmtTime(seconds) {
  if (!isFinite(seconds) || seconds < 0) seconds = 0;
  const s = Math.floor(seconds % 60);
  const m = Math.floor((seconds / 60) % 60);
  const h = Math.floor(seconds / 3600);
  const mm = h > 0 ? String(m).padStart(2, "0") : String(m);
  return (h > 0 ? `${h}:` : "") + `${mm}:${String(s).padStart(2, "0")}`;
}

function fmtRuntime(minutes) {
  if (!minutes) return "";
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return h ? `${h}h${m ? ` ${m}min` : ""}` : `${m}min`;
}

/* ---------------- Armazenamento local ---------------- */

function readJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function writeJSON(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* modo privado / cota cheia */
  }
}

function streamKey(media) {
  if (media.type === "tv") {
    return `tv:${media.id}:${media.season || 1}:${media.episode || 1}`;
  }
  return `movie:${media.id}`;
}

/* ---------------- Fontes de vídeo (addons) ----------------
   Formatos aceitos:

   1) Nativo (Meus Filmes):
   {
     "name": "Meu acervo",
     "endpoint": "https://meuserver.com/streams?type={type}&id={id}&season={season}&episode={episode}",
     "entries": {
       "movie:550":  [{ "label": "1080p", "url": "https://cdn/.../filme.mp4", "kind": "mp4" }],
       "tv:1396:1:1":[{ "label": "1080p", "url": "https://cdn/.../s01e01.m3u8", "kind": "hls" }]
     }
   }

   2) Stremio (manifest.json com resources/types):
   URL típica: https://addon.exemplo.com/manifest.json
   Streams em: {base}/stream/{movie|series}/{id}.json
   id costuma ser IMDb (tt...) ou tt...:temporada:episodio

   Instalação: link http(s), arquivo .json ou .zip (contendo manifest.json).
   ZIP local só funciona com "entries" estáticos (sem servidor).
------------------------------------------------------------ */

const ADDONS_KEY = "mf:addons";
const SOURCE_KEY = (key) => `mf:src:${key}`;
const LOCAL_MANIFEST_KEY = (id) => `mf:local-manifest:${id}`;
const manifestCache = new Map();
const imdbCache = new Map();

function normalizeAddon(entry) {
  if (typeof entry === "string") {
    return {
      url: entry,
      name: hostOf(entry),
      enabled: true,
      kind: "auto",
      baseUrl: null,
    };
  }
  if (!entry || !entry.url) return null;
  return {
    url: entry.url,
    name: entry.name || (String(entry.url).startsWith("local:") ? "Addon local" : hostOf(entry.url)),
    enabled: entry.enabled !== false,
    kind: entry.kind || "auto",
    baseUrl: entry.baseUrl || null,
  };
}

function hostOf(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return String(url || "").replace(/^local:/, "local · ");
  }
}

/* Addons embutidos, vindos do config.js (ex.: PINGUIM_PROXY_URL). Eles ficam
   sempre na lista de "Fontes de vídeo", com o mesmo botão liga/desliga dos
   outros — e o estado do botão é salvo junto. */
function builtinAddons() {
  const base =
    typeof PINGUIM_PROXY_URL === "string" ? PINGUIM_PROXY_URL.trim().replace(/\/+$/, "") : "";
  if (!base) return [];
  return [
    {
      url: `${base}/pinguim/manifest.json`,
      name: "PinguimCinema",
      enabled: true,
      kind: "native",
      baseUrl: null,
      builtin: true,
    },
  ];
}

function getAddons() {
  const stored = readJSON(ADDONS_KEY, null);
  const raw = Array.isArray(stored) ? stored : DEFAULT_ADDONS;
  const list = raw.map(normalizeAddon).filter(Boolean);

  // O embutido vem primeiro e o que está salvo (com o estado do botão) vence.
  const out = [];
  const seen = new Set();
  builtinAddons().forEach((addon) => {
    const saved = list.find((item) => item.url === addon.url);
    out.push({ ...addon, ...(saved || {}), builtin: true });
    seen.add(addon.url);
  });
  list.forEach((addon) => {
    if (!seen.has(addon.url)) out.push(addon);
  });
  return out;
}

function setAddons(list) {
  writeJSON(ADDONS_KEY, list.map(normalizeAddon).filter(Boolean));
  if (typeof scheduleCloudSync === "function") scheduleCloudSync();
}

function isStremioManifest(data) {
  if (!data || typeof data !== "object") return false;
  if (Array.isArray(data.resources) && data.resources.length) return true;
  if (Array.isArray(data.types) && (data.id || data.catalogs)) return true;
  return false;
}

function isNativeManifest(data) {
  if (!data || typeof data !== "object") return false;
  return !!(data.endpoint || data.entries);
}

function stremioBaseFromManifestUrl(url) {
  const clean = String(url || "").trim().replace(/\/+$/, "");
  if (/\/manifest\.json$/i.test(clean)) {
    return clean.replace(/\/manifest\.json$/i, "");
  }
  return clean;
}

function classifyManifest(data, sourceUrl) {
  if (isStremioManifest(data)) {
    return {
      kind: "stremio",
      name: data.name || hostOf(sourceUrl),
      baseUrl: stremioBaseFromManifestUrl(sourceUrl),
      data,
    };
  }
  if (isNativeManifest(data)) {
    return {
      kind: "native",
      name: data.name || hostOf(sourceUrl),
      baseUrl: null,
      data,
    };
  }
  throw new Error(
    "Manifesto inválido. Use o formato nativo (endpoint/entries) ou Stremio (resources/types)."
  );
}

async function fetchManifest(url, force = false) {
  if (String(url).startsWith("local:")) {
    const data = readJSON(LOCAL_MANIFEST_KEY(url), null);
    if (!data) throw new Error("manifesto local não encontrado");
    return data;
  }

  const hit = manifestCache.get(url);
  if (!force && hit && Date.now() - hit.at < 5 * 60_000) return hit.data;

  const res = await fetchWithTimeout(url, { cache: "no-store" });
  if (!res.ok) throw new Error(`o manifesto respondeu ${res.status}`);
  const data = await res.json();
  const classified = classifyManifest(data, url);
  manifestCache.set(url, { at: Date.now(), data: classified.data, meta: classified });
  return classified.data;
}

async function inspectRemoteManifest(url) {
  const clean = String(url || "").trim();
  if (!/^https?:\/\//i.test(clean)) throw new Error("Informe uma URL http(s).");

  let tryUrls = [clean];
  if (!/manifest\.json(\?|$)/i.test(clean)) {
    tryUrls = [
      clean.replace(/\/+$/, "") + "/manifest.json",
      clean,
    ];
  }

  let lastError = null;
  for (const candidate of tryUrls) {
    try {
      const res = await fetchWithTimeout(candidate, { cache: "no-store" });
      if (!res.ok) {
        lastError = new Error(`o manifesto respondeu ${res.status}`);
        continue;
      }
      const data = await res.json();
      const classified = classifyManifest(data, candidate);
      manifestCache.set(candidate, {
        at: Date.now(),
        data: classified.data,
        meta: classified,
      });
      return { url: candidate, ...classified };
    } catch (err) {
      lastError = err;
    }
  }
  throw lastError || new Error("Não foi possível ler o manifesto.");
}

async function addAddon(url) {
  const list = getAddons();
  const inspected = await inspectRemoteManifest(url);
  if (list.some((a) => a.url === inspected.url)) {
    throw new Error("Esse addon já está na lista.");
  }

  const addon = {
    url: inspected.url,
    name: inspected.name,
    enabled: true,
    kind: inspected.kind,
    baseUrl: inspected.baseUrl,
  };
  list.push(addon);
  setAddons(list);
  return addon;
}

function addLocalAddon(manifestData, displayName) {
  const classified = classifyManifest(manifestData, displayName || "local");
  if (classified.kind === "stremio" && !classified.data.entries && !manifestData.endpoint) {
    // Stremio sem servidor remoto não resolve streams
    if (!classified.data.entries) {
      throw new Error(
        "Addon Stremio em arquivo local só funciona se o ZIP/JSON tiver 'entries' estáticos. Preferia a URL do manifesto online."
      );
    }
  }

  const id = "local:" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  writeJSON(LOCAL_MANIFEST_KEY(id), classified.data);

  const list = getAddons();
  const addon = {
    url: id,
    name: classified.name || displayName || "Addon local",
    enabled: true,
    kind: classified.kind,
    baseUrl: null,
  };
  list.push(addon);
  setAddons(list);
  return addon;
}

function stripKodiColors(text) {
  return String(text || "")
    .replace(/\[\/?(?:B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)\]/gi, "")
    .replace(/\[COLOR\s+[^\]]+\]/gi, "")
    .replace(/\[\/COLOR\]/gi, "")
    .replace(/\[CR\]/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function parseKodiAddonXml(xmlText) {
  const doc = new DOMParser().parseFromString(xmlText, "application/xml");
  const parseError = doc.querySelector("parsererror");
  if (parseError) throw new Error("addon.xml inválido.");

  const root = doc.querySelector("addon");
  if (!root) throw new Error("XML sem elemento <addon> (não parece addon Kodi).");

  const id = root.getAttribute("id") || "";
  const version = root.getAttribute("version") || "";
  const rawName = root.getAttribute("name") || id || "Addon Kodi";
  const name = stripKodiColors(rawName) || id || "Addon Kodi";

  const extensions = [...doc.querySelectorAll("extension")];
  const points = extensions.map((el) => el.getAttribute("point") || "");

  const isRepo = points.some((p) => p === "xbmc.addon.repository");
  const isVideo =
    points.some((p) => p === "xbmc.python.pluginsource") ||
    /^plugin\.video\./i.test(id);
  const isPython = points.some((p) => /xbmc\.python/i.test(p)) || isVideo;

  const infoDirs = [...doc.querySelectorAll("extension[point='xbmc.addon.repository'] dir info")]
    .map((el) => (el.textContent || "").trim())
    .filter(Boolean);

  const summary =
    stripKodiColors(
      (doc.querySelector("summary") || {}).textContent ||
        (doc.querySelector("description") || {}).textContent ||
        ""
    ) || "";

  return {
    id,
    name,
    version,
    isRepo,
    isVideo,
    isPython,
    infoDirs,
    summary,
    typeLabel: isRepo
      ? "repositório Kodi"
      : isVideo
        ? "plugin de vídeo Kodi"
        : isPython
          ? "addon Python Kodi"
          : "addon Kodi",
  };
}

function kodiNotSupportedError(info) {
  const lines = [
    `Detectado ${info.typeLabel}: "${info.name}"${info.version ? " v" + info.version : ""}.`,
    "Addons Kodi usam Python e só rodam no app Kodi — o navegador não consegue executar.",
  ];
  if (info.isRepo && info.infoDirs.length) {
    lines.push(
      "Este é só o repositório (lista de plugins). Mesmo instalado no Kodi, os plugins continuam sendo código Python."
    );
  }
  lines.push(
    "Neste site use: manifesto Stremio (manifest.json), JSON nativo com URLs, ou ZIP que contenha esses arquivos."
  );
  const err = new Error(lines.join(" "));
  err.code = "KODI_NOT_SUPPORTED";
  err.kodi = info;
  return err;
}

async function addAddonFromFile(file) {
  if (!file) throw new Error("Nenhum arquivo selecionado.");
  const name = (file.name || "").toLowerCase();

  // addon.xml solto (pasta Kodi já descompactada)
  if (name === "addon.xml" || name.endsWith(".xml")) {
    const text = await file.text();
    if (/<addon[\s>]/i.test(text) && /xbmc\./i.test(text)) {
      throw kodiNotSupportedError(parseKodiAddonXml(text));
    }
    throw new Error("XML não reconhecido. Envie addon.xml de Kodi, ou um manifesto JSON/Stremio.");
  }

  if (name.endsWith(".json") || file.type === "application/json") {
    const text = await file.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error("Arquivo JSON inválido.");
    }
    return addLocalAddon(data, file.name.replace(/\.json$/i, ""));
  }

  if (name.endsWith(".zip") || file.type === "application/zip" || file.type === "application/x-zip-compressed") {
    const JSZip = await loadJSZip();
    const zip = await JSZip.loadAsync(await file.arrayBuffer());
    const paths = Object.keys(zip.files);

    // 1) Preferir manifesto Stremio / nativo
    let jsonEntry = null;
    let jsonPath = null;
    for (const path of paths) {
      const base = path.split("/").pop().toLowerCase();
      if (base === "manifest.json" || base === "addon.json") {
        jsonEntry = zip.files[path];
        jsonPath = path;
        break;
      }
    }
    if (!jsonEntry) {
      for (const path of paths) {
        if (path.toLowerCase().endsWith(".json") && !zip.files[path].dir) {
          jsonEntry = zip.files[path];
          jsonPath = path;
          break;
        }
      }
    }

    if (jsonEntry) {
      const text = await jsonEntry.async("string");
      let data;
      try {
        data = JSON.parse(text);
      } catch {
        throw new Error(`JSON inválido em ${jsonPath}`);
      }
      return addLocalAddon(data, file.name.replace(/\.zip$/i, ""));
    }

    // 2) Detectar estrutura Kodi (addon.xml)
    let xmlEntry = null;
    for (const path of paths) {
      if (path.split("/").pop().toLowerCase() === "addon.xml" && !zip.files[path].dir) {
        xmlEntry = zip.files[path];
        break;
      }
    }
    if (xmlEntry) {
      const xmlText = await xmlEntry.async("string");
      throw kodiNotSupportedError(parseKodiAddonXml(xmlText));
    }

    throw new Error(
      "ZIP sem manifest.json / addon.json e sem addon.xml. " +
        "Para este site envie manifesto Stremio ou JSON com streams; addons Kodi (Python) não rodam no navegador."
    );
  }

  throw new Error("Use um arquivo .json, .zip ou addon.xml.");
}

let _jszipPromise = null;
function loadJSZip() {
  if (window.JSZip) return Promise.resolve(window.JSZip);
  if (_jszipPromise) return _jszipPromise;
  _jszipPromise = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = "https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js";
    script.async = true;
    script.onload = () => {
      if (window.JSZip) resolve(window.JSZip);
      else reject(new Error("JSZip não carregou"));
    };
    script.onerror = () => reject(new Error("Falha ao carregar JSZip"));
    document.head.appendChild(script);
  });
  return _jszipPromise;
}

function removeAddon(url) {
  setAddons(getAddons().filter((a) => a.url !== url));
  manifestCache.delete(url);
  if (String(url).startsWith("local:")) {
    try {
      localStorage.removeItem(LOCAL_MANIFEST_KEY(url));
    } catch {
      /* ignore */
    }
  }
}

function toggleAddon(url) {
  const list = getAddons().map((a) =>
    a.url === url ? { ...a, enabled: !a.enabled } : a
  );
  setAddons(list);
  return list;
}

function detectKind(url) {
  const value = String(url || "").trim();
  if (/^magnet:\?/i.test(value)) return "torrent";
  if (/youtu\.be|youtube\.com|youtube-nocookie\.com/i.test(value)) return "youtube";
  // Extensão antes de query/hash/fim (ex.: .../video.mp4, .../ep.mp4?token=)
  // Também aceita barra residual: .../video.mp4/
  if (/\.m3u8(?=([?#]|$|\/))/i.test(value)) return "hls";
  if (/\.mpd(?=([?#]|$|\/))/i.test(value)) return "dash";
  if (/\.(mp4|m4v|webm|ogv|mov)(?=([?#]|$|\/))/i.test(value)) return "mp4";
  // Caminho genérico usado por vários hosts: termina com /video.mp4
  if (/\/video\.mp4(?=([?#]|$|\/))/i.test(value)) return "mp4";
  return "mp4";
}

function youtubeKey(url) {
  const value = String(url || "").trim();
  if (/^[\w-]{11}$/.test(value)) return value;
  const patterns = [
    /youtu\.be\/([\w-]{11})/,
    /[?&]v=([\w-]{11})/,
    /embed\/([\w-]{11})/,
    /shorts\/([\w-]{11})/,
  ];
  for (const re of patterns) {
    const match = value.match(re);
    if (match) return match[1];
  }
  return null;
}

function qualityScore(stream) {
  const text = `${stream.quality || ""} ${stream.label || ""} ${stream.name || ""} ${stream.title || ""}`;
  if (/4k|2160/i.test(text)) return 4;
  if (/1080/i.test(text)) return 3;
  if (/720/i.test(text)) return 2;
  if (/480|360|sd/i.test(text)) return 1;
  return 2;
}

function buildEndpoint(template, media) {
  const vars = {
    type: media.type,
    id: media.id,
    season: media.season || "",
    episode: media.episode || "",
    imdb: media.imdbId || "",
    tmdb: media.id,
  };
  return template.replace(/\{(type|id|season|episode|imdb|tmdb)\}/g, (_, key) =>
    encodeURIComponent(String(vars[key] ?? ""))
  );
}

function cleanStreams(list) {
  const seen = new Set();
  return list
    .filter((s) => s && (s.url || s.ytId || s.infoHash || s.magnet))
    .map((s) => {
      let url = s.url;
      let kind = s.kind;
      let magnet = s.magnet || null;
      if (!url && s.ytId) {
        url = `https://www.youtube.com/watch?v=${s.ytId}`;
        kind = "youtube";
      }
      // Garante magnet válido a partir de infoHash / url magnet
      if (!magnet && (s.infoHash || /^magnet:/i.test(String(url || "")))) {
        magnet = torrentMagnet({ ...s, url });
      }
      if (magnet && (!url || !/^https?:/i.test(url))) {
        url = magnet;
        kind = "torrent";
      }
      if (s.infoHash && !kind) kind = "torrent";
      return {
        ...s,
        url,
        magnet,
        infoHash: s.infoHash || null,
        label: s.label || s.name || s.title || "Fonte",
        kind: kind || detectKind(url),
        quality: s.quality || "",
        subtitles: Array.isArray(s.subtitles) ? s.subtitles : [],
      };
    })
    .filter((s) => s.url || s.magnet)
    .filter((s) => {
      const key = `${s.kind}|${s.url || s.magnet}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((a, b) => {
      // Ordem no navegador: HTTPS direto > HTTP/não-web > torrent
      const webScore = (s) => {
        if (s.kind === "torrent") return 3;
        if (s.kind === "dash") return 3;
        if (s.notWebReady) return 2;
        const u = String(s.url || "");
        if (/^http:\/\//i.test(u)) return 2; // conteúdo misto em site HTTPS
        if (s.kind === "hls" || s.kind === "mp4" || /\.(m3u8|mp4)(\?|#|$)/i.test(u)) return 0;
        return 1;
      };
      const wa = webScore(a);
      const wb = webScore(b);
      if (wa !== wb) return wa - wb;
      return qualityScore(b) - qualityScore(a);
    });
}

async function resolveImdbId(media) {
  if (media.imdbId) return media.imdbId;
  const cacheKey = `${media.type}:${media.id}`;
  if (imdbCache.has(cacheKey)) return imdbCache.get(cacheKey);

  try {
    const data = await Tmdb.cached(`/${media.type}/${media.id}/external_ids`);
    const imdb = data && data.imdb_id ? data.imdb_id : null;
    imdbCache.set(cacheKey, imdb);
    return imdb;
  } catch {
    imdbCache.set(cacheKey, null);
    return null;
  }
}

function stremioType(media) {
  return media.type === "tv" ? "series" : "movie";
}

function stremioVideoIds(media, imdbId) {
  const ids = [];
  if (imdbId) {
    if (media.type === "tv") {
      ids.push(`${imdbId}:${media.season || 1}:${media.episode || 1}`);
      ids.push(imdbId);
    } else {
      ids.push(imdbId);
    }
  }
  // fallback TMDB-style (alguns addons usam)
  if (media.type === "tv") {
    ids.push(`tmdb:${media.id}:${media.season || 1}:${media.episode || 1}`);
    ids.push(`${media.id}:${media.season || 1}:${media.episode || 1}`);
  } else {
    ids.push(`tmdb:${media.id}`);
    ids.push(String(media.id));
  }
  return [...new Set(ids)];
}

/* infoHash Stremio: 40 hex ou 32 base32 (v1). WebTorrent prefere hex. */
function normalizeInfoHash(raw) {
  const h = String(raw || "")
    .trim()
    .replace(/^urn:btih:/i, "")
    .replace(/\s+/g, "");
  if (/^[a-f0-9]{40}$/i.test(h)) return h.toLowerCase();
  if (/^[a-f0-9]{64}$/i.test(h)) return h.toLowerCase(); // v2 truncated use as-is in xt
  // Base32 (alphabet RFC 4648 sem padding) → hex 40 chars
  if (/^[a-z2-7]{32}$/i.test(h)) {
    try {
      const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
      const cleaned = h.toUpperCase().replace(/=+$/, "");
      let bits = "";
      for (const ch of cleaned) {
        const val = alphabet.indexOf(ch);
        if (val < 0) return null;
        bits += val.toString(2).padStart(5, "0");
      }
      const bytes = [];
      for (let i = 0; i + 8 <= bits.length; i += 8) {
        bytes.push(parseInt(bits.slice(i, i + 8), 2));
      }
      if (bytes.length < 20) return null;
      return bytes
        .slice(0, 20)
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("");
    } catch {
      return null;
    }
  }
  return null;
}

/* Torrents: monta o magnet a partir do infoHash e das fontes que o addon
   mandou. No navegador só trackers WebSocket (ws/wss) chegam a algum peer,
   e os webseeds HTTP são aceitos como ws= (baixam sem depender de peer).
   Trackers udp:// e dht: ficam de fora: o navegador não fala UDP. */
function torrentMagnet(stream) {
  // Magnet já completo
  const rawUrl = String(stream.url || "").trim();
  if (/^magnet:\?/i.test(rawUrl)) {
    try {
      const u = new URL(rawUrl);
      const xt = u.searchParams.get("xt") || "";
      const hashPart = xt.replace(/^urn:btih:/i, "");
      const norm = normalizeInfoHash(hashPart);
      if (norm && norm !== hashPart.toLowerCase()) {
        u.searchParams.set("xt", `urn:btih:${norm}`);
      }
      // Garante trackers wss se o magnet só trouxe udp
      const trs = u.searchParams.getAll("tr");
      const hasWss = trs.some((t) => /^wss?:\/\//i.test(t));
      if (!hasWss) {
        const defaults =
          typeof TORRENT_WSS_TRACKERS !== "undefined" ? TORRENT_WSS_TRACKERS : [];
        defaults.forEach((tracker) => u.searchParams.append("tr", tracker));
      }
      return u.toString();
    } catch {
      return rawUrl;
    }
  }

  const hash = normalizeInfoHash(stream.infoHash);
  if (!hash) return null;

  const params = new URLSearchParams();
  params.set("xt", `urn:btih:${hash}`);

  const name = stream.title || stream.name || stream.dn;
  if (name && !/^\d+$/.test(name)) params.set("dn", String(name).slice(0, 90));

  const sources = Array.isArray(stream.sources) ? stream.sources : [];
  sources.forEach((source) => {
    const raw = String(source || "")
      .trim()
      .replace(/^(tracker|webseed|dht):/i, "")
      .trim();
    if (/^wss?:\/\//i.test(raw)) {
      params.append("tr", raw);
    } else if (/^https?:\/\//i.test(raw)) {
      // webseed: o WebTorrent baixa por HTTP, sem depender de peer
      params.append("ws", raw);
    }
  });

  // A maioria dos addons só manda trackers udp/http (inúteis no navegador):
  // nesse caso entram os trackers WebSocket padrão, onde pode haver peers.
  if (!params.getAll("tr").length) {
    const defaults =
      typeof TORRENT_WSS_TRACKERS !== "undefined" ? TORRENT_WSS_TRACKERS : [];
    defaults.forEach((tracker) => params.append("tr", tracker));
  }

  return `magnet:?${params.toString()}`;
}

function mapStremioStream(s, provider) {
  if (!s) return null;

  const rawUrl = String(s.url || "").trim();
  const isMagnetUrl = /^magnet:\?/i.test(rawUrl);
  const magnet = isMagnetUrl ? rawUrl : torrentMagnet(s);

  let url = rawUrl || magnet || null;
  let kind = isMagnetUrl ? "torrent" : null;
  if (s.ytId) {
    url = `https://www.youtube.com/watch?v=${s.ytId}`;
    kind = "youtube";
  }
  if (!url) return null;

  const subs = Array.isArray(s.subtitles)
    ? s.subtitles.map((sub) => ({
        label: sub.lang || sub.id || "Legenda",
        lang: sub.lang || "",
        url: sub.url,
      })).filter((sub) => sub.url)
    : [];

  const hints = s.behaviorHints || null;
  // Stremio: proxyHeaders.request (User-Agent, Referer…) — o player tenta
  // aplicar no HLS; no <video> nativo o navegador não deixa.
  const proxyHeaders =
    (hints && hints.proxyHeaders && (hints.proxyHeaders.request || hints.proxyHeaders)) ||
    s.headers ||
    null;

  return {
    label: s.name || s.title || s.description || "Stream",
    quality: s.name || s.title || "",
    url,
    kind: kind || detectKind(url),
    // Dados do torrent (usados pelo player quando kind === "torrent")
    infoHash: s.infoHash || null,
    fileIdx: Number.isInteger(s.fileIdx) ? s.fileIdx : null,
    magnet: magnet || null,
    subtitles: subs,
    provider,
    // O addon marca fontes que ele considera problemáticas no navegador.
    // O player ainda tenta, mas deixa essas por último no pulo automático.
    notWebReady: !!(hints && hints.notWebReady),
    proxyHeaders: proxyHeaders && typeof proxyHeaders === "object" ? proxyHeaders : null,
    behaviorHints: hints,
  };
}

async function resolveStremioStreams(addon, manifest, media) {
  const name = manifest.name || addon.name || hostOf(addon.url);
  const base = (addon.baseUrl || stremioBaseFromManifestUrl(addon.url) || "").replace(/\/+$/, "");
  if (!base || String(base).startsWith("local:")) {
    // só entries locais, se houver
    return [];
  }

  const imdbId = await resolveImdbId(media);
  const type = stremioType(media);
  const ids = stremioVideoIds(media, imdbId);
  const out = [];

  // Addon que declara "timeout" no manifesto ganha mais tempo de resposta.
  // A ponte de addons Kodi precisa disso: um scraper leva mais que os 7s padrão.
  const timeout = Math.min(Number(manifest.timeout) || FETCH_TIMEOUT, 60000);

  for (const videoId of ids) {
    const url = `${base}/stream/${type}/${encodeURIComponent(videoId)}.json`;
    try {
      const res = await fetchWithTimeout(url, { cache: "no-store" }, timeout);
      if (!res.ok) continue;
      const data = await res.json().catch(() => ({}));
      const streams = data.streams || [];
      if (!streams.length) continue;
      streams.forEach((s) => {
        const mapped = mapStremioStream(s, name);
        if (mapped) out.push(mapped);
      });
      if (out.length) break; // já achou com este id
    } catch (err) {
      console.warn(`[stremio] ${name}: ${err.message}`);
    }
  }
  return out;
}

async function resolveNativeStreams(addon, manifest, media) {
  const name = manifest.name || addon.name || hostOf(addon.url);
  const key = streamKey(media);
  const out = [];

  const entry = manifest.entries && manifest.entries[key];
  if (Array.isArray(entry)) {
    entry.forEach((s) => out.push({ ...s, provider: name }));
  }

  // também tenta chaves com imdb se existir
  const imdbId = media.imdbId || (await resolveImdbId(media));
  if (imdbId && manifest.entries) {
    const altKeys =
      media.type === "tv"
        ? [`tv:${imdbId}:${media.season || 1}:${media.episode || 1}`, `series:${imdbId}:${media.season || 1}:${media.episode || 1}`]
        : [`movie:${imdbId}`];
    for (const k of altKeys) {
      const list = manifest.entries[k];
      if (Array.isArray(list)) list.forEach((s) => out.push({ ...s, provider: name }));
    }
  }

  if (manifest.endpoint) {
    const url = buildEndpoint(manifest.endpoint, {
      ...media,
      imdbId: imdbId || media.imdbId || "",
    });
    try {
      const res = await fetchWithTimeout(url, { cache: "no-store" });
      if (!res.ok) throw new Error(`resposta ${res.status}`);
      const data = await res.json().catch(() => ({}));
      (data.streams || []).forEach((s) => out.push({ ...s, provider: name }));
    } catch (err) {
      console.warn(`[fontes] ${name}: ${err.message}`);
    }
  }
  return out;
}

/* Fontes já resolvidas ficam em cache curto (abrir o mesmo título de novo
   é instantâneo). Fontes manuais entram sempre frescas. */
const STREAMS_TTL = 60_000;
const streamsCache = new Map();

/* Fontes adicionadas à mão, por título/episódio */
function getManualSources(media) {
  return readJSON(SOURCE_KEY(streamKey(media)), []);
}

function addManualSource(media, stream) {
  const key = SOURCE_KEY(streamKey(media));
  const list = readJSON(key, []);
  list.push(stream);
  writeJSON(key, list);
  streamsCache.delete(streamKey(media));
  if (typeof scheduleCloudSync === "function") scheduleCloudSync();
}

function removeManualSource(media, index) {
  const key = SOURCE_KEY(streamKey(media));
  const list = readJSON(key, []);
  list.splice(index, 1);
  writeJSON(key, list);
  streamsCache.delete(streamKey(media));
  if (typeof scheduleCloudSync === "function") scheduleCloudSync();
}

/* Junta fontes manuais + todos os addons ativos.
   opts.onSources(lista): avisa assim que existe qualquer fonte, para o
   player já começar sem esperar o addon mais lento.
   opts.force: ignora o cache curto. */
async function resolveStreams(media, opts = {}) {
  const key = streamKey(media);
  const manual = getManualSources(media).map((s) => ({
    ...s,
    provider: "Minhas fontes",
  }));

  const emit = (extra) => {
    if (typeof opts.onSources !== "function") return;
    const list = applyStreamPrefs(cleanStreams([...manual, ...extra]));
    if (list.length) opts.onSources(list);
  };

  if (!opts.force) {
    const hit = streamsCache.get(key);
    if (hit && Date.now() - hit.at < STREAMS_TTL) {
      return applyStreamPrefs(cleanStreams([...manual, ...hit.streams]));
    }
  }

  // Fontes manuais não dependem de rede: dá para tocar na hora
  emit([]);

  const addons = getAddons().filter((a) => a.enabled);
  const found = [];

  await Promise.all(
    addons.map(async (addon) => {
      try {
        // manifesto e id do IMDb em paralelo: um não depende do outro
        const [manifest, imdbId] = await Promise.all([
          fetchManifest(addon.url),
          media.imdbId ? Promise.resolve(media.imdbId) : resolveImdbId(media),
        ]);
        if (imdbId && !media.imdbId) media.imdbId = imdbId;

        const isStremio = addon.kind === "stremio" || isStremioManifest(manifest);
        const [fromProtocol, fromEntries] = await Promise.all([
          isStremio ? resolveStremioStreams(addon, manifest, media) : Promise.resolve([]),
          resolveNativeStreams(addon, manifest, media),
        ]);

        found.push(...fromProtocol, ...fromEntries);
        emit(found);
      } catch (err) {
        console.warn("[fontes]", addon.name || addon.url, err && err.message);
      }
    })
  );

  const addonStreams = cleanStreams(found);
  streamsCache.set(key, { at: Date.now(), streams: addonStreams });
  return applyStreamPrefs(cleanStreams([...manual, ...addonStreams]));
}

/* ---------------- Trailers oficiais ---------------- */

async function findTrailer(media) {
  const data = await Tmdb.cached(`/${media.type}/${media.id}/videos`);
  const videos = (data.results || []).filter((v) => v.site === "YouTube" && v.key);
  return (
    videos.find((v) => v.type === "Trailer" && v.official) ||
    videos.find((v) => v.type === "Trailer") ||
    videos.find((v) => v.type === "Teaser") ||
    null
  );
}

/* ---------------- Preferências do trailer na capa ---------------- */

/* ---------------- Preferência de torrent (P2P) ---------------- */

const TORRENT_PREFS_KEY = "mf:torrent-prefs";

/* Ligado por padrão: quem quiser só links diretos pode desligar em ⚙ */
function getTorrentPrefs() {
  const saved = readJSON(TORRENT_PREFS_KEY, null) || {};
  return { enabled: saved.enabled !== false };
}

function setTorrentPrefs(patch) {
  const next = { ...getTorrentPrefs(), ...patch };
  writeJSON(TORRENT_PREFS_KEY, next);
  return next;
}

/* Remove fontes de torrent quando a opção está desligada */
function applyTorrentPref(list) {
  if (getTorrentPrefs().enabled) return list;
  return list.filter((src) => src && src.kind !== "torrent");
}

/* ---------------- Preferência de qualidade ---------------- */

const QUALITY_PREFS_KEY = "mf:quality-prefs";

function getQualityPrefs() {
  const saved = readJSON(QUALITY_PREFS_KEY, null) || {};
  const preferred = ["all", "4k", "1080", "720", "480"].includes(saved.preferred)
    ? saved.preferred
    : "all";
  return {
    preferred,
    // true = só mostra a qualidade marcada; false = prioriza, mas deixa as outras
    onlyPreferred: saved.onlyPreferred === true,
  };
}

function setQualityPrefs(patch) {
  const next = { ...getQualityPrefs(), ...patch };
  writeJSON(QUALITY_PREFS_KEY, next);
  // limpa cache de streams para a próxima abertura respeitar a preferência
  try {
    streamsCache.clear();
  } catch {
    /* noop */
  }
  return next;
}

function streamQualityLabel(stream) {
  return `${stream.quality || ""} ${stream.label || ""} ${stream.name || ""} ${stream.title || ""}`;
}

function streamMatchesQuality(stream, preferred) {
  if (!preferred || preferred === "all") return true;
  const text = streamQualityLabel(stream);
  switch (preferred) {
    case "4k":
      return /4k|2160|uhd/i.test(text);
    case "1080":
      return /1080|fhd|full\s*hd/i.test(text) && !/4k|2160/i.test(text);
    case "720":
      return /720|hd(?!\d)/i.test(text) && !/1080|2160|4k/i.test(text);
    case "480":
      return /480|360|sd|cam|ts\b|scr/i.test(text) && !/720|1080|2160|4k/i.test(text);
    default:
      return true;
  }
}

/** Aplica preferência de qualidade na lista de fontes. */
function applyQualityPref(list) {
  const prefs = getQualityPrefs();
  if (!Array.isArray(list) || !list.length || prefs.preferred === "all") return list;

  const matched = list.filter((s) => streamMatchesQuality(s, prefs.preferred));
  if (!matched.length) return list; // nenhuma bateu: mantém todas

  if (prefs.onlyPreferred) return matched;

  // Prioriza a qualidade escolhida, mantém o resto depois
  const rest = list.filter((s) => !matched.includes(s));
  return [...matched, ...rest];
}

function applyStreamPrefs(list) {
  return applyQualityPref(applyTorrentPref(list));
}

const TRAILER_PREFS_KEY = "mf:trailer-prefs";

function getTrailerPrefs() {
  const saved = readJSON(TRAILER_PREFS_KEY, null) || {};
  return {
    enabled: saved.enabled !== false,
    sound: saved.sound === true,
  };
}

function setTrailerPrefs(patch) {
  const next = { ...getTrailerPrefs(), ...patch };
  writeJSON(TRAILER_PREFS_KEY, next);
  return next;
}

/* ---------------- Próximo episódio ---------------- */

async function findNextEpisode(media) {
  if (media.type !== "tv") return null;

  const detail = await Tmdb.cached(`/tv/${media.id}`);
  const seasons = (detail.seasons || [])
    .filter((s) => s.season_number > 0 && s.episode_count > 0)
    .sort((a, b) => a.season_number - b.season_number);

  const currentSeason = media.season || 1;
  const currentEpisode = media.episode || 0;
  let start = seasons.findIndex((s) => s.season_number === currentSeason);
  if (start === -1) start = 0;

  for (let i = start; i < seasons.length; i++) {
    const number = seasons[i].season_number;
    const season = await Tmdb.cached(`/tv/${media.id}/season/${number}`).catch(() => null);
    const minEpisode = number === currentSeason ? currentEpisode : 0;
    const next = (season?.episodes || [])
      .filter((ep) => ep.episode_number > minEpisode)
      .sort((a, b) => a.episode_number - b.episode_number)[0];

    if (next) {
      return {
        season: number,
        episode: next.episode_number,
        name: next.name || `Episódio ${next.episode_number}`,
        overview: next.overview || "",
        stillPath: next.still_path || null,
      };
    }
  }
  return null;
}

/* ---------------- Perfis ---------------- */

const PROFILES_KEY = "mf:profiles";
const ACTIVE_PROFILE_KEY = "mf:active-profile";
const LEGACY_PROGRESS_KEY = "mf:progress";

const AVATARS = ["🍿", "🎬", "👾", "🚀", "🦊", "🐱", "⭐", "🎧", "🐼", "🌙"];
const AVATAR_COLORS = [
  "#e50914", "#e87c03", "#d6b417", "#46d369",
  "#2b9ee8", "#8c5cf2", "#e84a8a", "#1abc9c",
];

function readRaw(key) {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function writeRaw(key, value) {
  try {
    localStorage.setItem(key, value);
  } catch {
    /* modo privado */
  }
}

function removeRaw(key) {
  try {
    localStorage.removeItem(key);
  } catch {
    /* modo privado */
  }
}

function newProfileId() {
  return "p" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

function getProfiles() {
  const list = readJSON(PROFILES_KEY, []);
  return Array.isArray(list) ? list.filter((profile) => profile && profile.id) : [];
}

function saveProfiles(list) {
  writeJSON(PROFILES_KEY, list);
  if (typeof scheduleCloudSync === "function") scheduleCloudSync();
}

function getActiveProfileId() {
  const id = readRaw(ACTIVE_PROFILE_KEY);
  return getProfiles().some((profile) => profile.id === id) ? id : null;
}

function setActiveProfileId(id) {
  writeRaw(ACTIVE_PROFILE_KEY, id);
  if (typeof scheduleCloudSync === "function") scheduleCloudSync();
}

function clearActiveProfile() {
  removeRaw(ACTIVE_PROFILE_KEY);
}

function getActiveProfile() {
  const id = getActiveProfileId();
  return getProfiles().find((profile) => profile.id === id) || null;
}

function createProfile({ name, avatar, color, photo, cover }) {
  const profiles = getProfiles();
  const profile = {
    id: newProfileId(),
    name: String(name || "").trim().slice(0, 20) || `Perfil ${profiles.length + 1}`,
    avatar: avatar || AVATARS[profiles.length % AVATARS.length],
    color: Number.isInteger(color) ? color : profiles.length % AVATAR_COLORS.length,
    // foto redonda e capa: links de imagem (null = usa o emoji / cor do perfil)
    photo: normalizeImageUrl(photo),
    cover: normalizeImageUrl(cover),
    createdAt: Date.now(),
  };

  profiles.push(profile);
  saveProfiles(profiles);

  if (profiles.length === 1) migrateLegacyProgress(profile.id);
  return profile;
}

function updateProfile(id, patch) {
  const profiles = getProfiles().map((profile) =>
    profile.id === id ? { ...profile, ...patch } : profile
  );
  saveProfiles(profiles);
}

function deleteProfile(id) {
  saveProfiles(getProfiles().filter((profile) => profile.id !== id));
  removeRaw(progressKeyFor(id));
  removeRaw(playlistKeyFor(id));
  if (readRaw(ACTIVE_PROFILE_KEY) === id) clearActiveProfile();
}

function progressKeyFor(profileId) {
  return `mf:progress:${profileId}`;
}

/* O histórico antigo (sem perfis) vai para o primeiro perfil criado */
function migrateLegacyProgress(profileId) {
  const legacy = readJSON(LEGACY_PROGRESS_KEY, null);
  if (!Array.isArray(legacy) || !legacy.length) return;
  const key = progressKeyFor(profileId);
  if (!readJSON(key, []).length) writeJSON(key, legacy);
  removeRaw(LEGACY_PROGRESS_KEY);
}

/* ---------------- Progresso / continuar assistindo ---------------- */

function loadProgressList() {
  const profileId = getActiveProfileId();
  if (!profileId) return [];
  const list = readJSON(progressKeyFor(profileId), []);
  return Array.isArray(list) ? list : [];
}

function getProgress(media) {
  const key = streamKey(media);
  return loadProgressList().find((p) => p.key === key) || null;
}

function saveProgress(media, position, duration) {
  if (!duration || !isFinite(duration) || duration < 30) return;
  const ratio = position / duration;
  if (!(ratio > 0.02 && ratio < 0.97)) return;

  const profileId = getActiveProfileId();
  if (!profileId) return;

  const key = streamKey(media);
  const list = loadProgressList().filter((p) => p.key !== key);
  list.unshift({
    key,
    media: {
      type: media.type,
      id: media.id,
      title: media.title,
      poster: media.poster || imgUrl(media.posterPath, "w342"),
      backdrop: media.backdrop || imgUrl(media.backdropPath, "w780"),
      year: media.year || "",
      season: media.season || null,
      episode: media.episode || null,
      episodeTitle: media.episodeTitle || "",
    },
    position,
    duration,
    updatedAt: Date.now(),
  });
  writeJSON(progressKeyFor(profileId), list.slice(0, 40));
  if (typeof scheduleCloudSync === "function") scheduleCloudSync();
}

function clearProgress(media) {
  const profileId = getActiveProfileId();
  if (!profileId) return;
  const key = streamKey(media);
  writeJSON(
    progressKeyFor(profileId),
    loadProgressList().filter((p) => p.key !== key)
  );
  if (typeof scheduleCloudSync === "function") scheduleCloudSync();
}

function continueWatching() {
  return loadProgressList().filter((p) => p.position > 15);
}

function latestProgressForShow(showId) {
  return (
    loadProgressList()
      .filter((p) => p.media.type === "tv" && p.media.id === showId)
      .sort((a, b) => b.updatedAt - a.updatedAt)[0] || null
  );
}

/* ---------------- Minha playlist ---------------- */

function playlistKeyFor(profileId) {
  return `mf:playlist:${profileId}`;
}

function myListItemKey(media) {
  if (!media || media.id == null) return null;
  return `${media.type === "tv" ? "tv" : "movie"}:${media.id}`;
}

function getMyList() {
  const profileId = getActiveProfileId();
  if (!profileId) return [];
  const list = readJSON(playlistKeyFor(profileId), []);
  if (!Array.isArray(list)) return [];
  return list
    .filter((entry) => entry && entry.media && entry.media.id != null)
    .sort((a, b) => (b.addedAt || 0) - (a.addedAt || 0));
}

function isInMyList(media) {
  const key = myListItemKey(media);
  if (!key) return false;
  return getMyList().some((entry) => entry.key === key);
}

function saveMyList(list) {
  const profileId = getActiveProfileId();
  if (!profileId) return false;
  writeJSON(playlistKeyFor(profileId), list.slice(0, 200));
  if (typeof scheduleCloudSync === "function") scheduleCloudSync();
  return true;
}

function addToMyList(media) {
  const key = myListItemKey(media);
  if (!key) return false;
  if (!getActiveProfileId()) return false;

  const entry = {
    key,
    addedAt: Date.now(),
    media: {
      type: media.type === "tv" ? "tv" : "movie",
      id: media.id,
      title: media.title || "Sem título",
      overview: media.overview || "",
      posterPath: media.posterPath || null,
      backdropPath: media.backdropPath || null,
      rating: Number(media.rating) || 0,
      year: media.year || "",
      date: media.date || "",
    },
  };

  return saveMyList([entry, ...getMyList().filter((item) => item.key !== key)]);
}

function removeFromMyList(media) {
  const key = typeof media === "string" ? media : myListItemKey(media);
  if (!key) return false;
  return saveMyList(getMyList().filter((entry) => entry.key !== key));
}

function toggleMyList(media) {
  if (isInMyList(media)) {
    removeFromMyList(media);
    return false;
  }
  return addToMyList(media);
}

/* Prepara um item da playlist para o player (série retoma o último episódio) */
function playlistPlaybackMedia(entry) {
  const media = { ...(entry && entry.media) };
  if (!media.id) return null;

  if (media.type === "tv") {
    const latest = latestProgressForShow(media.id);
    media.season = latest?.media?.season || 1;
    media.episode = latest?.media?.episode || 1;
    media.episodeTitle = latest?.media?.episodeTitle || "";
  }
  return media;
}
